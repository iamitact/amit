# Client photographs go here

Drop the original, full-resolution photographs in this folder (no screenshots or messaging-app copies).
Then copy `manifest.example.json` to `manifest.json`, list each file, and run `npm run photos`.

- `slot`: a page slot from `src/data/photos.json` (home.campaign, about.interior, about.exterior, about.team, contact.storefront, lookbook.1 to lookbook.4, lookbook.wide)
- `product` + `view`: a product slug from `src/data/catalog.json` and `front`, `back` or `detail`
- `alt`: a short, factual description of the photo for screen readers

What to photograph is listed in `docs/CLIENT-CHECKLIST.md`.
