# Online checkout — architecture and status

**Status: not live.** The website shows an honest "online payment isn't available yet" state, disables the checkout button, and makes no payment or order requests. No order can be created, because every product price and the currency are still pending (`src/data/catalog.json`), and no payment provider is registered.

## Why a separate server

GitHub Pages only serves static files. A real payment integration needs secret credentials and server-to-server calls (creating a payment session, validating the result, issuing refunds). Those must never be in the browser or in the GitHub repository. So checkout runs as a **separate small service** (`server/`) on a host that supports environment secrets (e.g. a VPS, Render, Railway, Fly.io, a cPanel Node app). The storefront talks to it over HTTPS.

```
Browser (GitHub Pages)                     Checkout server (secrets in env)             Payment provider
──────────────────────                     ────────────────────────────────             ────────────────
Bag → "Checkout"  ── POST /api/orders ──▶  price lines from catalog.json                  
  {lines:[slug,size,qty], customer}        create order (pending_payment)                
                                           provider.createPayment ───────────────────▶  hosted payment page
  ◀──────────── redirectUrl ────────────                                                
customer pays on the provider's page ────────────────────────────────────────────────▶
                                           ◀── POST /api/payments/<provider>/notify ──  IPN / webhook
                                           provider.verify: signature + server-to-server
                                           validation; compare amount, currency, reference
                                           idempotent state change (paid / failed / cancelled / review)
provider redirects back ─▶ /bag/?paid=1 → GET /api/orders/:id shows the verified status only
```

## What is implemented (`server/`)

- **Server-priced orders** — the browser sends only product slug, size and quantity; the amount comes from `catalog.json`. Samples, unpriced products, unconfirmed sizes and unavailable items are refused.
- **Order state machine** — `pending_payment → paid | failed | cancelled | expired | review`, `paid → fulfilled | refunded`, `fulfilled → refunded`. Any other transition is refused.
- **Verified payment confirmation** — a provider adapter must re-validate every notification with the provider (signature and/or validation API). The amount, currency and provider reference must match the order, otherwise the order goes to `review`, never `paid`.
- **Idempotency** — each provider event id is processed once; a repeated or late notification cannot double-mark, un-pay or double-fulfil an order.
- **Admin actions** — fulfil and refund, protected by a bearer token from the environment.
- **Tests** — `npm run test:server` runs 12 tests: success, failure, cancellation, duplicate notification, late failure after payment, amount tampering, bad signature, fulfilment/refund rules, unsellable lines, the real catalogue being not yet sellable, the sandbox refusing production, and the HTTP API.
- **Sandbox provider** — `server/src/providers/sandbox.mjs` simulates a provider for local tests only. It takes no money and throws if `NODE_ENV=production`.

## What is needed to go live

1. **The merchant's provider decision** — which payment/commerce account the business holds. We do not assume Stripe or a currency; availability depends on the business's registration and account.
2. A provider adapter (`createPayment`, `verify`, `refund`) written against that provider's official API documentation, tested in its **sandbox** for success, failure, cancellation, duplicate notification, refund, and amount mismatch.
3. Confirmed prices, currency, sizes and availability in `catalog.json`.
4. Hosting for the server with HTTPS, the environment variables in `server/.env.example`, and a real database instead of the JSON file store for production volume.
5. `src/data/commerce.json` set to the provider name, the server URL and `"status": "live"`, and the Bag page's checkout button wired to `POST /api/orders` (the only remaining front-end step).
6. Legal pages the provider will ask for (terms, privacy, refund policy, contact details).
7. **The merchant's approval** before switching the provider from sandbox to production.

## If a hosted platform is chosen instead

If the business prefers a hosted commerce platform (which manages products, stock, payment and orders itself), the storefront can link each product to the platform's hosted checkout, and `server/` is not needed. The same rule applies: no "order placed" message unless the platform confirms it.
