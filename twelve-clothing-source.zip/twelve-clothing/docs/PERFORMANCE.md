# 3D story performance — measurements

Measured on 26 Sep 2026 with Microsoft Edge (headless, hardware WebGL through ANGLE / Direct3D 11) on the development laptop: **Intel HD Graphics 520, 4 GB RAM**, under heavy memory pressure (≈0.6 GB free). Numbers on a typical phone or a newer laptop will differ. The comparison is what matters: both builds were measured in the same session, interleaved.

- **Before** = the published site (`v1-live` tag + the opt-in `?perf` hook), served locally.
- **After** = this revision's `/story/` page on a GitHub-Pages-style server.

Method (`?perf` hook + a Playwright script):
- Frame intervals were sampled with `requestAnimationFrame` for 3 s idle on the hero, then during a 6 s scripted scroll through 90% of the story.
- Scroll-follow latency is the time from an instant scroll jump until the scrubbed timeline is within 0.0015 of the target. Instant jumps are used because the page's CSS smooth scrolling would otherwise add the browser's own animation time.
- Draw calls and triangles come from `renderer.info`.

## Results

| Profile | Build | Render pixel ratio | Idle frame p50 / p95 (ms) | Scroll-sweep frame p50 / p95 (ms) | Sweep frames > 33 ms | Draw calls | Triangles |
|---|---|---|---|---|---|---|---|
| Desktop 1440×900 | Before | 1.0 | 30.7 / 65.4 · 35.3 / 74.1 | 29.5 / 72.4 · 19.5 / 100.7 | 75 of 175 · 64 of 185 | 86 | 77,142 |
| Desktop 1440×900 | After | 0.85 · 0.7 (adaptive) | 10.5 / 41.5 · 19.9 / 36.5 · 7.5 / 34.4 | 13.4 / 107.6 · 6.5 / 38.5 · 14.4 / 88.1 | 26 of 192 · 18 of 343 · 37 of 223 | 31 | 43,696 |
| Mobile 390×844, CPU ×4 slower | Before | 1.25 | 16.9 / 35.9 · 14.8 / 34.8 | 17.4 / 40.7 · 15.3 / 39.3 | 42 of 296 · 44 of 319 | 86 | 77,142 |
| Mobile 390×844, CPU ×4 slower | After | 1.0 | 5.4 / 11.0 · 5.6 / 9.6 | 5.8 / 15.5 · 5.4 / 14.0 | 5 of 843 · 2 of 889 | 31 | 43,696 |

(· separates repeated runs. The headless browser is not v-synced, so more frames in the same time means cheaper frames.)

**Scroll-follow latency** (instant jumps, desktop): before ≈ 380–440 ms to settle (GSAP `scrub: 0.8`); after ≈ 190–230 ms (`scrub: 0.35`).

## What caused the lag

Both things the client felt were real:

1. **Low frame rate.** On this GPU the original story ran at about 24–35 fps while scrolling, with 35–55% of frames over 33 ms. Each frame drew 86 draw calls: the garment twice (colour pass plus a real-time shadow-map pass), 34 separately-materialed smoke sprites updated from JavaScript, and around 30 tiny emblem and button meshes. There were also per-frame layout reads (`offsetWidth` inside the callout loop) and allocations.
2. **Scroll smoothing.** `scrub: 0.8` kept the camera moving for about 0.4 s after the scroll stopped (measured settle time), which reads as lag.

## What changed

- **Shadows:** a baked contact-shadow quad replaced the real-time shadow map, which removes the second pass.
- **Mist:** the smoke became a single instanced mesh with its motion in the vertex shader (1 draw call, 3 uniform writes per frame), placed low and denser near the garment so it is actually visible.
- **Merged meshes:** the buttons, holes, threads and emblem marks were baked into one mesh per material.
- **Pixel ratio:** capped at 1.5 on capable devices (was 1.75) and 1.0 on low-power ones (was 1.25). Adaptive resolution steps between the cap and a floor at most once per 3 s, with hysteresis. Its first version resized the drawing buffer twice per step and caused a GPU out-of-memory context loss on this laptop; that was fixed and verified.
- **Warm-up and recovery:** shaders are compiled before the first frame (`compileAsync`), and a lost WebGL context is given 2.5 s to recover before falling back to the still story.
- **DOM work:** styles are written only when values change, label widths are measured once, and there are no per-frame vector allocations.
- **Scrub:** 0.8 → 0.35.
- **Pausing:** unchanged. Rendering stops when the story is off-screen or the tab is hidden.

## Caveats

- On this weak GPU part of the desktop gain comes from rendering at 0.7–0.85× resolution. The scene is soft and dark, so the difference is hard to see, but it is a trade-off.
- The new build still showed occasional single long frames (0.3–1.3 s max) during the scripted sweep on this memory-starved machine; the p50/p95 values above are the representative figures. One run logged a single console message that did not reproduce in a repeat run.
- These are lab measurements. A real-device check on the client's target phones is recommended before launch.
