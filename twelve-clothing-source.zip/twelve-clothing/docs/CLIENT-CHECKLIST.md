# What we need from Twelve Clothing

The site is built and working, but it is **not finalised** until the items below are supplied. Until then every missing fact is shown on the site as "to be confirmed", and the 3D concept renders are labelled as renders. Nothing is invented.

## 1. Photographs (put the originals in `assets-reference/`)

Send original, full-resolution files (JPEG/PNG/TIFF straight from the camera or photographer, **not** screenshots or WhatsApp copies). We will only resize them: no retouching of faces, no colour or shape changes to products.

| # | Photo | Used on | Notes |
|---|-------|---------|-------|
| 1 | **Every product, front** | Shop, Product | Plain, consistent background; the true colour of the garment; at least 2000 px on the long side; portrait 4:5 preferred |
| 2 | **Every product, back** | Product (hover on Shop) | Same set-up as the front photo |
| 3 | **Details** (collar, buttons, logo, fabric, label), 2–4 per product | Product gallery | Close and in focus |
| 4 | Worn / on-model photos (optional) | Product, Lookbook | Only with the model's consent to publish |
| 5 | **Shop interior** | About | Landscape, at least 2400 px wide |
| 6 | **Shop exterior / storefront** | About, Contact | So visitors recognise the shop |
| 7 | **One strong campaign or shop photo** | Home (full-width band) | Landscape, at least 2400 px wide |
| 8 | Lookbook photos (4–6) | Lookbook | Portrait 4:5 plus one wide landscape |
| 9 | Founder / team photo (optional) | About | With consent |
| 10 | **Brand logo** | Header, favicon | Vector (SVG, AI or PDF) if possible, plus any colour rules |

Then list each file in `assets-reference/manifest.json` (format in `scripts/import-photos.mjs`) and run `npm run photos`.

## 2. Product data — one row per product and colour

Fill in `src/data/catalog.json` (or send a spreadsheet with these columns):

- Product name and colour name
- SKU / style code
- Category (e.g. Polos, Shirts, Trousers)
- **Price** and **currency** (e.g. BDT)
- Available sizes, and whether sizes are final
- Availability policy: in stock / made to order / sold out — and whether stock should be tracked online
- Short description and details (fabric composition, weight, fit, care, country of manufacture)
- **Size chart**: measurements per size (chest, length, shoulder, sleeve), the unit (cm / inches) and a fit note

## 3. Business information — `src/data/business.json`

- Registered business name
- Shop address, and a Google Maps link
- Opening hours
- Phone, email, WhatsApp
- Instagram / Facebook / TikTok links
- The brand story (and the year founded, if you'd like it shown)
- **Shipping policy** (areas, costs, delivery times)
- **Returns / exchange policy**

## 4. Online payment — one decision first

**Which payment or commerce account does the business already have (or intend to open)?**

Examples that serve merchants in Bangladesh include SSLCOMMERZ, bKash Payment Gateway, Nagad, aamarPay, ShurjoPay, or a hosted platform. We will not assume a provider, a currency, or that an international gateway (such as Stripe) is available to the business — eligibility depends on where the business is registered and its account.

Once the provider is known we will need, **from the merchant's own account**: sandbox/test credentials, the production credentials (added only to the checkout server's environment, never to this website or GitHub), the settlement currency, and approval before switching to live payments. See `docs/CHECKOUT.md`.

## 5. Optional: an accurate 3D garment

The 3D polo in the Story is an **original concept model**, not a copy of a real product, and it is labelled that way. If you want a rotatable 3D view of a real garment, we need a production-quality **GLB/glTF model** of that garment (from the manufacturer's 3D/CLO3D files or a 3D scanning service) plus reference photos and fabric swatches. A few flat photographs are not enough to build an accurate 3D model.
