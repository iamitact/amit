import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import * as THREE from 'three';
import { Stage, type Rig, type ShotName } from './stage';
import { createAdaptiveResolution, pickQuality } from './adaptive';
import { VARIANTS, DEFAULT_VARIANT } from './variants';
import type { AnchorName } from './garment';

gsap.registerPlugin(ScrollTrigger);

export interface StoryMountOptions {
  /** Element the canvas is appended to (fills the sticky viewport). */
  host: HTMLElement;
  /** The tall scroll container whose progress drives the timeline. */
  trigger: HTMLElement;
  chapters: { el: HTMLElement; at: number; span: number }[];
  callouts: { el: HTMLElement; anchor: AnchorName }[];
  calloutWindow: [number, number];
  progressBar?: HTMLElement | null;
  onReady: () => void;
  onFail: (reason: string) => void;
}

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};


/**
 * Timeline (0–1 of the pinned story):
 *  0.00–0.06 reveal hold · 0.08–0.17 → silhouette · 0.25–0.32 → exploded view
 *  0.27–0.35 deconstruct · 0.43–0.49 reassemble · 0.45–0.52 → collar
 *  0.57–0.60 → buttons · 0.65–0.68 → emblem · 0.73–0.76 → hem · 0.81–0.88 → finale
 */
function buildTimeline(rig: Rig, shots: Record<ShotName, Rig>, explode: { v: number }, mist: { v: number }) {
  const tl = gsap.timeline({ paused: true, defaults: { ease: 'power2.inOut' } });
  const move = (from: ShotName, to: ShotName, start: number, end: number) =>
    tl.fromTo(rig, { ...shots[from] }, { ...shots[to], duration: end - start, immediateRender: false }, start);
  move('hero', 'silhouette', 0.08, 0.17);
  move('silhouette', 'exploded', 0.25, 0.32);
  move('exploded', 'collar', 0.45, 0.52);
  move('collar', 'buttons', 0.565, 0.6);
  move('buttons', 'emblem', 0.645, 0.68);
  move('emblem', 'hem', 0.725, 0.76);
  move('hem', 'finale', 0.81, 0.88);
  tl.fromTo(explode, { v: 0 }, { v: 1, duration: 0.08, immediateRender: false }, 0.27);
  tl.fromTo(explode, { v: 1 }, { v: 0, duration: 0.06, immediateRender: false }, 0.43);
  // editorial mist: a low bank rises through the silhouette → construction cut
  // and again as the story resolves into the finale
  tl.fromTo(mist, { v: 0 }, { v: 1, duration: 0.05, ease: 'sine.inOut', immediateRender: false }, 0.22);
  tl.fromTo(mist, { v: 1 }, { v: 0, duration: 0.07, ease: 'sine.inOut', immediateRender: false }, 0.28);
  tl.fromTo(mist, { v: 0 }, { v: 0.85, duration: 0.07, ease: 'sine.inOut', immediateRender: false }, 0.79);
  tl.fromTo(mist, { v: 0.85 }, { v: 0.25, duration: 0.08, ease: 'sine.inOut', immediateRender: false }, 0.88);
  tl.to({}, { duration: 0.04 }, 0.96); // pad the timeline to exactly 1.0
  return tl;
}

export function mountStory(opts: StoryMountOptions): () => void {
  let stage: Stage;
  try {
    stage = new Stage({ variant: VARIANTS[DEFAULT_VARIANT], quality: pickQuality() });
  } catch (err) {
    opts.onFail(err instanceof Error ? err.message : 'WebGL unavailable');
    return () => {
    disposed = true;};
  }

  const canvas = stage.renderer.domElement;
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.display = 'block';
  opts.host.appendChild(canvas);

  const shots = stage.computeShots();
  const rig: Rig = { ...shots.hero };
  const explode = { v: 0 };
  const mist = { v: 0 };
  const tl = buildTimeline(rig, shots, explode, mist);
  // opt-in profiling hook: ?perf exposes the renderer and timeline to the console
  if (new URLSearchParams(location.search).has('perf')) {
    (window as unknown as { __twelve?: unknown }).__twelve = { stage, tl, rig };
  }
  const st = ScrollTrigger.create({
    trigger: opts.trigger,
    start: 'top top',
    end: 'bottom bottom',
    // measured: scrub 0.8 took ~0.9 s to settle after scrolling stopped, which
    // read as lag; 0.35 keeps the camera smooth but follows the scrollbar closely
    scrub: 0.35,
    animation: tl,
  });

  // --- sizing
  const labelWidths = new Map<HTMLElement, number>();
  const resize = () => {
    const r = opts.host.getBoundingClientRect();
    stage.setSize(r.width, r.height);
    labelWidths.clear();
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(opts.host);

  // --- pointer parallax (fine pointers only; never captures events)
  const fine = window.matchMedia('(pointer: fine)').matches;
  const onPointer = (e: PointerEvent) =>
    stage.setPointer((e.clientX / window.innerWidth) * 2 - 1, (e.clientY / window.innerHeight) * 2 - 1);
  if (fine) window.addEventListener('pointermove', onPointer, { passive: true });

  // --- run only while the story is on screen and the tab is visible
  let inView = true;
  let raf = 0;
  let ready = false;
  const world = new THREE.Vector3();
  const start = performance.now();

  // last written values, so the DOM is only touched when something changes
  const chapterOpacity: number[] = opts.chapters.map((_, i) => (i === 0 ? 1 : 0));
  const calloutShown = new Map<HTMLElement, boolean>();
  let lastProgress = -1;
  let viewportWidth = 0;

  const adapt = createAdaptiveResolution(stage);
  let lastFrame = performance.now();

  const frame = () => {
    raf = 0;
    const now = performance.now();
    const dt = now - lastFrame;
    lastFrame = now;
    if (ready) adapt(now, dt);

    const p = tl.progress();
    const time = (now - start) / 1000;
    stage.apply(rig, explode.v, time, mist.v);
    stage.render();

    // chapters
    for (let i = 0; i < opts.chapters.length; i++) {
      const { el, at, span } = opts.chapters[i];
      const a = at - span / 2;
      const b = at + span / 2;
      let o = 1;
      if (i > 0) o = Math.min(o, smooth(a - 0.028, a, p));
      if (i < opts.chapters.length - 1) o = Math.min(o, 1 - smooth(b, b + 0.028, p));
      if (Math.abs(o - chapterOpacity[i]) < 0.002) continue;
      chapterOpacity[i] = o;
      el.style.opacity = o.toFixed(3);
      el.style.transform = `translate3d(0, ${((1 - o) * 18).toFixed(1)}px, 0)`;
      el.style.visibility = o < 0.01 ? 'hidden' : 'visible';
    }

    // callouts pinned to the moving pieces
    const [c0, c1] = opts.calloutWindow;
    const co = Math.min(smooth(c0 - 0.02, c0, p), 1 - smooth(c1, c1 + 0.02, p)) * explode.v;
    if (!viewportWidth) viewportWidth = canvas.clientWidth;
    for (const { el, anchor } of opts.callouts) {
      const s = co >= 0.01 ? stage.project(stage.garment.anchors[anchor].getWorldPosition(world)) : null;
      if (!s) {
        if (calloutShown.get(el) !== false) {
          el.style.visibility = 'hidden';
          calloutShown.set(el, false);
        }
        continue;
      }
      if (calloutShown.get(el) !== true) {
        el.style.visibility = 'visible';
        calloutShown.set(el, true);
      }
      el.style.opacity = co.toFixed(3);
      el.style.transform = `translate3d(${s.x.toFixed(1)}px, ${s.y.toFixed(1)}px, 0)`;
      // label widths are measured once (layout read), then cached
      let lw = labelWidths.get(el);
      if (lw === undefined) {
        lw = el.querySelector<HTMLElement>('[data-label]')?.offsetWidth ?? 200;
        labelWidths.set(el, lw);
        viewportWidth = canvas.clientWidth;
      }
      const need = lw + (viewportWidth < 768 ? 40 : 60);
      const side =
        s.x + need <= viewportWidth - 8 ? 'right' : s.x - need >= 8 ? 'left' : s.x > viewportWidth / 2 ? 'left' : 'right';
      if (el.dataset.side !== side) el.dataset.side = side;
    }

    if (opts.progressBar && Math.abs(p - lastProgress) > 0.0005) {
      opts.progressBar.style.transform = `scaleY(${p.toFixed(4)})`;
      lastProgress = p;
    }

    if (!ready) {
      ready = true;
      opts.onReady();
    }
    if (inView && !document.hidden) raf = requestAnimationFrame(frame);
  };
  const kick = () => {
    if (!raf && inView && !document.hidden) raf = requestAnimationFrame(frame);
  };

  const io = new IntersectionObserver(
    ([entry]) => {
      inView = entry.isIntersecting;
      kick();
    },
    { rootMargin: '120px 0px' },
  );
  io.observe(opts.trigger);
  const onVisibility = () => kick();
  document.addEventListener('visibilitychange', onVisibility);

  // a lost context (GPU reset, memory pressure) usually comes back; give it a
  // moment before falling back to the still story
  let lostTimer = 0;
  const onLost = (e: Event) => {
    e.preventDefault();
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    inView = false;
    lostTimer = window.setTimeout(() => opts.onFail('WebGL context lost'), 2500);
  };
  const onRestored = () => {
    window.clearTimeout(lostTimer);
    inView = true;
    kick();
  };
  canvas.addEventListener('webglcontextlost', onLost);
  canvas.addEventListener('webglcontextrestored', onRestored);

  // fonts change layout height; re-measure the trigger once they load
  document.fonts?.ready.then(() => ScrollTrigger.refresh()).catch(() => {});
  // compile every shader before the first visible frame (the poster covers the wait)
  let disposed = false;
  stage.apply(rig, 0, 0, 0);
  stage.warmUp().then(() => {
    if (!disposed) kick();
  });

  return () => {
    if (raf) cancelAnimationFrame(raf);
    io.disconnect();
    ro.disconnect();
    document.removeEventListener('visibilitychange', onVisibility);
    window.removeEventListener('pointermove', onPointer);
    canvas.removeEventListener('webglcontextlost', onLost);
    canvas.removeEventListener('webglcontextrestored', onRestored);
    window.clearTimeout(lostTimer);
    st.kill();
    tl.kill();
    stage.dispose();
  };
}
