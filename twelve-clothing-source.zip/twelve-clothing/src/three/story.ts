import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import * as THREE from 'three';
import { Stage, type Rig, type ShotName } from './stage';
import { VARIANTS, DEFAULT_VARIANT } from './variants';
import type { AnchorName } from './garment';

gsap.registerPlugin(ScrollTrigger);

export interface StoryMountOptions {
  /** Element the canvas is appended to (fills the sticky viewport). */
  host: HTMLElement;
  /** The tall scroll container whose progress drives the timeline. */
  trigger: HTMLElement;
  chapters: { el: HTMLElement; at: number; span: number }[];
  callouts: { el: HTMLElement; anchor: AnchorName }[];
  calloutWindow: [number, number];
  progressBar?: HTMLElement | null;
  onReady: () => void;
  onFail: (reason: string) => void;
}

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};

function pickQuality(): 'high' | 'low' {
  const cores = navigator.hardwareConcurrency ?? 8;
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
  const coarse = window.matchMedia('(pointer: coarse)').matches;
  if (cores <= 4 || memory <= 4 || (coarse && window.innerWidth < 900)) return 'low';
  return 'high';
}

/**
 * Timeline (0–1 of the pinned story):
 *  0.00–0.06 reveal hold · 0.08–0.17 → silhouette · 0.25–0.32 → exploded view
 *  0.27–0.35 deconstruct · 0.43–0.49 reassemble · 0.45–0.52 → collar
 *  0.57–0.60 → buttons · 0.65–0.68 → emblem · 0.73–0.76 → hem · 0.81–0.88 → finale
 */
function buildTimeline(rig: Rig, shots: Record<ShotName, Rig>, explode: { v: number }) {
  const tl = gsap.timeline({ paused: true, defaults: { ease: 'power2.inOut' } });
  const move = (from: ShotName, to: ShotName, start: number, end: number) =>
    tl.fromTo(rig, { ...shots[from] }, { ...shots[to], duration: end - start, immediateRender: false }, start);
  move('hero', 'silhouette', 0.08, 0.17);
  move('silhouette', 'exploded', 0.25, 0.32);
  move('exploded', 'collar', 0.45, 0.52);
  move('collar', 'buttons', 0.565, 0.6);
  move('buttons', 'emblem', 0.645, 0.68);
  move('emblem', 'hem', 0.725, 0.76);
  move('hem', 'finale', 0.81, 0.88);
  tl.fromTo(explode, { v: 0 }, { v: 1, duration: 0.08, immediateRender: false }, 0.27);
  tl.fromTo(explode, { v: 1 }, { v: 0, duration: 0.06, immediateRender: false }, 0.43);
  tl.to({}, { duration: 0.12 }, 0.88); // pad the timeline to exactly 1.0
  return tl;
}

export function mountStory(opts: StoryMountOptions): () => void {
  let stage: Stage;
  try {
    stage = new Stage({ variant: VARIANTS[DEFAULT_VARIANT], quality: pickQuality() });
  } catch (err) {
    opts.onFail(err instanceof Error ? err.message : 'WebGL unavailable');
    return () => {};
  }

  const canvas = stage.renderer.domElement;
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.display = 'block';
  opts.host.appendChild(canvas);

  const shots = stage.computeShots();
  const rig: Rig = { ...shots.hero };
  const explode = { v: 0 };
  const tl = buildTimeline(rig, shots, explode);
  const st = ScrollTrigger.create({
    trigger: opts.trigger,
    start: 'top top',
    end: 'bottom bottom',
    scrub: 0.8,
    animation: tl,
  });

  // --- sizing
  const resize = () => {
    const r = opts.host.getBoundingClientRect();
    stage.setSize(r.width, r.height);
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(opts.host);

  // --- pointer parallax (fine pointers only; never captures events)
  const fine = window.matchMedia('(pointer: fine)').matches;
  const onPointer = (e: PointerEvent) =>
    stage.setPointer((e.clientX / window.innerWidth) * 2 - 1, (e.clientY / window.innerHeight) * 2 - 1);
  if (fine) window.addEventListener('pointermove', onPointer, { passive: true });

  // --- run only while the story is on screen and the tab is visible
  let inView = true;
  let raf = 0;
  let ready = false;
  const world = new THREE.Vector3();
  const start = performance.now();

  const frame = () => {
    raf = 0;
    const p = tl.progress();
    const time = (performance.now() - start) / 1000;
    stage.apply(rig, explode.v, time);
    stage.render();

    // chapters
    opts.chapters.forEach(({ el, at, span }, i) => {
      const a = at - span / 2;
      const b = at + span / 2;
      let o = 1;
      if (i > 0) o = Math.min(o, smooth(a - 0.028, a, p));
      if (i < opts.chapters.length - 1) o = Math.min(o, 1 - smooth(b, b + 0.028, p));
      el.style.opacity = o.toFixed(3);
      el.style.transform = `translate3d(0, ${((1 - o) * 18).toFixed(1)}px, 0)`;
      el.style.visibility = o < 0.01 ? 'hidden' : 'visible';
    });

    // callouts pinned to the moving pieces
    const [c0, c1] = opts.calloutWindow;
    const co = Math.min(smooth(c0 - 0.02, c0, p), 1 - smooth(c1, c1 + 0.02, p)) * explode.v;
    for (const { el, anchor } of opts.callouts) {
      if (co < 0.01) {
        el.style.visibility = 'hidden';
        continue;
      }
      stage.garment.anchors[anchor].getWorldPosition(world);
      const s = stage.project(world);
      if (!s) {
        el.style.visibility = 'hidden';
        continue;
      }
      el.style.visibility = 'visible';
      el.style.opacity = co.toFixed(3);
      el.style.transform = `translate3d(${s.x.toFixed(1)}px, ${s.y.toFixed(1)}px, 0)`;
      // labels read to the right of their piece unless they would run off-screen
      const label = el.querySelector<HTMLElement>('[data-label]');
      const vw = stage.renderer.domElement.clientWidth;
      const need = (label?.offsetWidth ?? 200) + (vw < 768 ? 40 : 60);
      el.dataset.side = s.x + need <= vw - 8 ? 'right' : s.x - need >= 8 ? 'left' : s.x > vw / 2 ? 'left' : 'right';
    }

    if (opts.progressBar) opts.progressBar.style.transform = `scaleY(${p.toFixed(4)})`;

    if (!ready) {
      ready = true;
      opts.onReady();
    }
    if (inView && !document.hidden) raf = requestAnimationFrame(frame);
  };
  const kick = () => {
    if (!raf && inView && !document.hidden) raf = requestAnimationFrame(frame);
  };

  const io = new IntersectionObserver(
    ([entry]) => {
      inView = entry.isIntersecting;
      kick();
    },
    { rootMargin: '120px 0px' },
  );
  io.observe(opts.trigger);
  const onVisibility = () => kick();
  document.addEventListener('visibilitychange', onVisibility);

  const onLost = (e: Event) => {
    e.preventDefault();
    opts.onFail('WebGL context lost');
  };
  canvas.addEventListener('webglcontextlost', onLost);

  // fonts change layout height; re-measure the trigger once they load
  document.fonts?.ready.then(() => ScrollTrigger.refresh()).catch(() => {});
  kick();

  return () => {
    if (raf) cancelAnimationFrame(raf);
    io.disconnect();
    ro.disconnect();
    document.removeEventListener('visibilitychange', onVisibility);
    window.removeEventListener('pointermove', onPointer);
    canvas.removeEventListener('webglcontextlost', onLost);
    st.kill();
    tl.kill();
    stage.dispose();
  };
}
