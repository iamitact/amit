import * as THREE from 'three';
import { seeded } from './textures';

/**
 * Low, drifting studio mist rendered as ONE instanced draw call.
 *
 * Replaces the earlier per-sprite smoke (one draw call + one material per puff,
 * with positions/opacity/rotation written from JavaScript every frame). Here all
 * motion runs in the vertex shader from a single `uTime` uniform, so the CPU
 * cost per frame is three uniform writes regardless of puff count.
 */
export interface Mist {
  mesh: THREE.Mesh;
  /** amount: overall density (0..~2). lift: raises the mist during transitions (0..1). */
  update(time: number, amount: number, lift: number): void;
  dispose(): void;
}

export function createMist(map: THREE.Texture, quality: 'high' | 'low'): Mist {
  const count = quality === 'high' ? 36 : 22;
  const rand = seeded(2412);
  const base = new THREE.PlaneGeometry(1, 1);
  const geo = new THREE.InstancedBufferGeometry();
  geo.index = base.index;
  geo.setAttribute('position', base.getAttribute('position'));
  geo.setAttribute('uv', base.getAttribute('uv'));
  geo.instanceCount = count;

  const offset = new Float32Array(count * 3);
  const size = new Float32Array(count * 2);
  const seed = new Float32Array(count * 4); // phase, speed, opacity, spin
  for (let i = 0; i < count; i++) {
    // 60% form a dense bank under and around the garment, the rest a wider low layer
    const near = i < count * 0.6;
    const a = rand() * Math.PI * 2;
    const r = near ? 0.15 + rand() * 1.35 : 1.2 + rand() * 2.6;
    offset[i * 3] = Math.cos(a) * r * 1.2;
    offset[i * 3 + 1] = near ? 0.04 + rand() * 0.34 : 0.08 + rand() * 0.6;
    offset[i * 3 + 2] = Math.sin(a) * r * 0.75 - 0.15;
    // sizes are kept moderate: large translucent quads cost fill-rate on every pixel they cover
    const s = near ? 0.95 + rand() * 1.0 : 1.5 + rand() * 1.6;
    size[i * 2] = s * (1.5 + rand() * 0.6);
    size[i * 2 + 1] = s;
    seed[i * 4] = rand() * Math.PI * 2;
    seed[i * 4 + 1] = 0.04 + rand() * 0.07;
    seed[i * 4 + 2] = near ? 0.26 + rand() * 0.16 : 0.14 + rand() * 0.12;
    seed[i * 4 + 3] = (rand() - 0.5) * 0.25;
  }
  geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(offset, 3));
  geo.setAttribute('aSize', new THREE.InstancedBufferAttribute(size, 2));
  geo.setAttribute('aSeed', new THREE.InstancedBufferAttribute(seed, 4));

  const material = new THREE.ShaderMaterial({
    uniforms: {
      uMap: { value: map },
      uTime: { value: 0 },
      uAmount: { value: 1 },
      uLift: { value: 0 },
      uColor: { value: new THREE.Color('#a2a8b1') },
      uFogColor: { value: new THREE.Color('#0a0a0b') },
    },
    vertexShader: /* glsl */ `
      attribute vec3 aOffset;
      attribute vec2 aSize;
      attribute vec4 aSeed;
      uniform float uTime;
      uniform float uLift;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vDepth;
      void main() {
        float t = uTime * aSeed.y + aSeed.x;
        vec3 centre = aOffset;
        centre.x += sin(t) * 0.38;
        centre.z += cos(t * 0.8) * 0.16;
        centre.y += sin(t * 0.6) * 0.04 + uLift * (0.35 + 0.45 * fract(aSeed.x));
        // camera-facing billboard, slowly turning
        vec4 mv = modelViewMatrix * vec4(centre, 1.0);
        float a = t * aSeed.w;
        vec2 corner = mat2(cos(a), -sin(a), sin(a), cos(a)) * (position.xy * aSize);
        mv.xy += corner;
        vUv = uv;
        vDepth = -mv.z;
        // fade puffs that come very close to the camera (macro shots)
        vAlpha = aSeed.z * smoothstep(0.35, 1.6, vDepth);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap;
      uniform float uAmount;
      uniform vec3 uColor;
      uniform vec3 uFogColor;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vDepth;
      void main() {
        float d = texture2D(uMap, vUv).a;
        float fog = 1.0 - exp(-pow(vDepth * 0.05, 2.0));
        float alpha = d * vAlpha * uAmount;
        if (alpha < 0.004) discard;
        gl_FragColor = vec4(mix(uColor, uFogColor, fog), alpha);
      }`,
    transparent: true,
    depthWrite: false,
  });

  const mesh = new THREE.Mesh(geo, material);
  mesh.frustumCulled = false; // instances are displaced in the shader
  mesh.renderOrder = 2;

  return {
    mesh,
    update(time, amount, lift) {
      material.uniforms.uTime.value = time;
      material.uniforms.uAmount.value = amount;
      material.uniforms.uLift.value = lift;
      mesh.visible = amount > 0.01;
    },
    dispose() {
      base.dispose();
      geo.dispose();
      material.dispose();
    },
  };
}
