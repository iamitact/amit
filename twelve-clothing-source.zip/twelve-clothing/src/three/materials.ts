import * as THREE from 'three';
import type { GarmentPalette } from './variants';
import { tippingMap, type SharedTextures } from './textures';

/** Knit density: texture repeats per scene unit (UVs are authored in scene units). */
const PIQUE_REPEAT = 11;
const RIB_REPEAT = 7;

export interface GarmentMaterials {
  fabric: THREE.MeshPhysicalMaterial;
  rib: THREE.MeshPhysicalMaterial;
  collar: THREE.MeshPhysicalMaterial;
  stitch: THREE.MeshStandardMaterial;
  thread: THREE.MeshPhysicalMaterial;
  button: THREE.MeshPhysicalMaterial;
  buttonHole: THREE.MeshBasicMaterial;
  tape: THREE.MeshStandardMaterial;
  dispose(): void;
}

function repeated(tex: THREE.Texture, u: number, v: number) {
  const t = tex.clone();
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(u, v);
  t.needsUpdate = true;
  return t;
}

export function createGarmentMaterials(p: GarmentPalette, tex: SharedTextures): GarmentMaterials {
  const piqueN = repeated(tex.pique, PIQUE_REPEAT, PIQUE_REPEAT);
  const ribN = repeated(tex.rib, RIB_REPEAT, RIB_REPEAT);
  const collarN = repeated(tex.rib, RIB_REPEAT, 1);
  const tipping = tippingMap(p.fabric, p.tipping);

  // Black cloth on a near-black stage stays legible through sheen (grazing
  // highlights) and silver rim light, not through lifting the base colour.
  const knit = {
    roughness: 0.86,
    metalness: 0,
    sheen: 1,
    sheenRoughness: 0.42,
    sheenColor: new THREE.Color(p.sheen),
    side: THREE.DoubleSide,
  } as const;

  const fabric = new THREE.MeshPhysicalMaterial({
    ...knit,
    color: p.fabric,
    normalMap: piqueN,
    normalScale: new THREE.Vector2(0.75, 0.75),
  });
  const rib = new THREE.MeshPhysicalMaterial({
    ...knit,
    color: p.fabric,
    normalMap: ribN,
    normalScale: new THREE.Vector2(0.9, 0.9),
  });
  const collar = new THREE.MeshPhysicalMaterial({
    ...knit,
    color: '#ffffff',
    map: tipping,
    normalMap: collarN,
    normalScale: new THREE.Vector2(0.9, 0.9),
  });
  const stitch = new THREE.MeshStandardMaterial({ color: p.stitch, roughness: 0.65 });
  const thread = new THREE.MeshPhysicalMaterial({
    color: p.thread,
    roughness: 0.55,
    sheen: 1,
    sheenRoughness: 0.3,
    sheenColor: new THREE.Color(p.threadSheen),
  });
  const button = new THREE.MeshPhysicalMaterial({
    color: p.button,
    roughness: 0.32,
    clearcoat: 0.9,
    clearcoatRoughness: 0.22,
  });
  const buttonHole = new THREE.MeshBasicMaterial({ color: '#050505' });
  const tape = new THREE.MeshStandardMaterial({ color: p.tape, roughness: 0.7, side: THREE.DoubleSide });

  const all = [fabric, rib, collar, stitch, thread, button, buttonHole, tape];
  return {
    fabric,
    rib,
    collar,
    stitch,
    thread,
    button,
    buttonHole,
    tape,
    dispose() {
      all.forEach((m) => m.dispose());
      [piqueN, ribN, collarN, tipping].forEach((t) => t.dispose());
    },
  };
}
