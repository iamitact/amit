import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildGarment, type AnchorName, type Garment } from './garment';
import { createGarmentMaterials, type GarmentMaterials } from './materials';
import { createSharedTextures, seeded, type SharedTextures } from './textures';
import type { GarmentVariant } from './variants';

/** Every value the scroll timeline animates. Positions are world space. */
export interface Rig {
  cx: number; cy: number; cz: number; // camera
  tx: number; ty: number; tz: number; // look-at target
  fov: number;
  rotY: number; // garment yaw
  ox: number; // landscape: horizontal frame offset (fraction of width, + = subject right)
  poy: number; // portrait: vertical frame offset (fraction of height, + = subject up)
  ps: number; // portrait distance multiplier
  detail: number; // raking detail light intensity (0..1)
  dx: number; dy: number; dz: number; // detail light position
  float: number; // idle float / pointer parallax amount (0..1)
  smoke: number; // smoke opacity multiplier
  key: number; // overhead key light multiplier
}

export type ShotName =
  | 'hero' | 'silhouette' | 'exploded' | 'collar' | 'buttons' | 'emblem' | 'hem' | 'finale'
  | 'product' | 'portrait' | 'side' | 'back';

export const GARMENT_Y = 0.34;

export interface StageOptions {
  variant: GarmentVariant;
  quality: 'high' | 'low';
  preserveDrawingBuffer?: boolean;
  pixelRatio?: number;
}

export class Stage {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(30, 1, 0.02, 60);
  readonly garment: Garment;
  private readonly textures: SharedTextures;
  private readonly materials: GarmentMaterials;
  private readonly detailLight: THREE.PointLight;
  private readonly keyLight: THREE.SpotLight;
  private readonly smoke: { sprite: THREE.Sprite; base: THREE.Vector3; phase: number; speed: number; opacity: number }[] = [];
  private readonly disposables: { dispose(): void }[] = [];
  private width = 1;
  private height = 1;
  private pointer = new THREE.Vector2();
  private pointerSmoothed = new THREE.Vector2();

  constructor(opts: StageOptions) {
    const { quality } = opts;
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: opts.preserveDrawingBuffer ?? false,
    });
    const dprCap = quality === 'high' ? 1.75 : 1.25;
    this.renderer.setPixelRatio(opts.pixelRatio ?? Math.min(window.devicePixelRatio || 1, dprCap));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.setClearColor('#0a0a0b', 1);
    // synchronous shader-log checks stall compiles and surface harmless ANGLE
    // precision notes; keep them for development only
    this.renderer.debug.checkShaderErrors = import.meta.env.DEV;

    const scene = this.scene;
    scene.background = new THREE.Color('#0a0a0b');
    scene.fog = new THREE.FogExp2('#0a0a0b', 0.055);

    // soft studio reflections so the sheen has something to pick up
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const room = new RoomEnvironment();
    const env = pmrem.fromScene(room, 0.04).texture;
    room.dispose();
    pmrem.dispose();
    scene.environment = env;
    scene.environmentIntensity = 0.16;
    this.disposables.push(env);

    this.textures = createSharedTextures(quality);
    this.materials = createGarmentMaterials(opts.variant.palette, this.textures);
    this.garment = buildGarment(opts.variant.style, this.materials);
    this.garment.root.position.y = GARMENT_Y;
    scene.add(this.garment.root);

    // --- lights: overhead key, silver rims, faint fill, raking detail light
    const key = new THREE.SpotLight('#f4efe6', 42, 14, 0.34, 0.9, 1.6);
    key.position.set(0.25, 6.2, 1.4);
    key.target.position.set(0, 1.0, 0);
    key.castShadow = true;
    key.shadow.mapSize.set(quality === 'high' ? 1024 : 512, quality === 'high' ? 1024 : 512);
    key.shadow.bias = -0.0004;
    key.shadow.normalBias = 0.02;
    key.shadow.radius = 5;
    key.shadow.camera.near = 2;
    key.shadow.camera.far = 9;
    scene.add(key, key.target);
    this.keyLight = key;

    const rimL = new THREE.DirectionalLight('#cfd7e4', 2.6);
    rimL.position.set(-3.2, 2.6, -2.6);
    const rimR = new THREE.DirectionalLight('#dde3ec', 2.2);
    rimR.position.set(3.4, 2.1, -2.2);
    const front = new THREE.DirectionalLight('#e9e4da', 0.35);
    front.position.set(0.5, 1.4, 5);
    scene.add(rimL, rimR, front, new THREE.HemisphereLight('#2a2e35', '#050506', 0.35));

    this.detailLight = new THREE.PointLight('#ffe7c4', 0, 1.4, 2);
    scene.add(this.detailLight);

    // --- floor with a soft shadow catch
    const floorGeo = new THREE.CircleGeometry(16, 64);
    // radial map: the floor dissolves into the background, so no horizon line
    const floorMap = (() => {
      const c = document.createElement('canvas');
      c.width = c.height = 256;
      const ctx = c.getContext('2d')!;
      const grad = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
      grad.addColorStop(0, '#26262a');
      grad.addColorStop(0.16, '#131315');
      grad.addColorStop(0.42, '#080809');
      grad.addColorStop(1, '#050505');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    })();
    const floorMat = new THREE.MeshStandardMaterial({ color: '#8a8a8a', map: floorMap, roughness: 0.96 });
    this.disposables.push(floorMap);
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);
    this.disposables.push(floorGeo, floorMat);

    // --- slate haze behind the garment
    const glowGeo = new THREE.PlaneGeometry(11, 8);
    const glowMat = new THREE.MeshBasicMaterial({ map: this.textures.glow, transparent: true, depthWrite: false, fog: false });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    glow.position.set(0, 1.9, -4.2);
    scene.add(glow);
    this.disposables.push(glowGeo, glowMat);

    // --- faint light cone from the overhead spot
    const coneGeo = new THREE.ConeGeometry(1.7, 5.4, 64, 1, true);
    const coneMat = new THREE.ShaderMaterial({
      uniforms: { uOpacity: { value: 0.07 } },
      vertexShader: /* glsl */ `
        varying float vH; varying vec3 vN; varying vec3 vV;
        void main() {
          vH = (position.y + 2.7) / 5.4;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */ `
        uniform float uOpacity; varying float vH; varying vec3 vN; varying vec3 vV;
        void main() {
          float edge = pow(abs(dot(vN, vV)), 2.2);
          float fade = smoothstep(0.0, 0.55, vH) * (1.0 - smoothstep(0.85, 1.0, vH));
          gl_FragColor = vec4(vec3(0.86, 0.87, 0.9), edge * fade * uOpacity);
        }`,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });
    const cone = new THREE.Mesh(coneGeo, coneMat);
    cone.position.set(0.12, 6.2 - 2.7, 0.7);
    cone.rotation.z = 0.02;
    scene.add(cone);
    this.disposables.push(coneGeo, coneMat);

    // --- low smoke / fog near the hem and floor
    const rand = seeded(1212);
    const count = quality === 'high' ? 34 : 18;
    for (let i = 0; i < count; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.textures.smoke,
        color: '#8d939c',
        transparent: true,
        depthWrite: false,
        opacity: 0,
      });
      const s = new THREE.Sprite(mat);
      const a = rand() * Math.PI * 2;
      const r = 0.25 + rand() * 2.1;
      const base = new THREE.Vector3(Math.cos(a) * r, 0.08 + rand() * 0.55, Math.sin(a) * r * 0.7 - 0.2);
      const scale = 1.3 + rand() * 1.8;
      s.scale.set(scale * 1.6, scale, 1);
      s.position.copy(base);
      scene.add(s);
      this.smoke.push({ sprite: s, base, phase: rand() * Math.PI * 2, speed: 0.05 + rand() * 0.08, opacity: 0.1 + rand() * 0.12 });
      this.disposables.push(mat);
    }

    this.renderer.domElement.setAttribute('role', 'img');
    this.renderer.domElement.setAttribute(
      'aria-label',
      'Three-dimensional render of the Twelve Nocturne black piqué polo under a single overhead spotlight.',
    );
  }

  /** World position of a garment anchor at rest (explode 0, yaw 0). */
  anchorWorld(name: AnchorName) {
    const a = this.garment.anchors[name];
    this.garment.root.updateMatrixWorld(true);
    return {
      p: a.getWorldPosition(new THREE.Vector3()),
      n: (a.userData.normal as THREE.Vector3).clone(),
    };
  }

  /** Camera shots derived from the actual garment geometry. */
  computeShots(): Record<ShotName, Rig> {
    this.garment.setExplode(0);
    this.garment.root.rotation.set(0, 0, 0);
    const base: Rig = {
      cx: 0, cy: 1.2, cz: 5.9, tx: 0, ty: 1.08, tz: 0, fov: 30, rotY: 0,
      ox: 0, poy: 0.04, ps: 1, detail: 0, dx: 0.6, dy: 1.6, dz: 1.2, float: 1, smoke: 1, key: 1,
    };
    const macro = (name: AnchorName, dist: number, side: number, up: number, ox: number, light: [number, number, number]): Rig => {
      const { p, n } = this.anchorWorld(name);
      const dir = n.clone().normalize();
      const cam = p.clone().addScaledVector(dir, dist).add(new THREE.Vector3(side, up, 0));
      return {
        ...base, cx: cam.x, cy: cam.y, cz: cam.z, tx: p.x, ty: p.y, tz: p.z, fov: 28, ox, poy: 0.16,
        ps: 1.15, detail: 1, dx: p.x + light[0], dy: p.y + light[1], dz: p.z + light[2], float: 0.12, smoke: 0.35, key: 0.3,
      };
    };
    return {
      hero: { ...base },
      silhouette: { ...base, cx: 3.1, cy: 1.45, cz: 4.2, tx: 0, ty: 1.02, tz: 0, rotY: -0.3, ox: 0.16, poy: 0.08, fov: 29 },
      exploded: { ...base, cx: 1.3, cy: 1.7, cz: 5.7, tx: 0.08, ty: 1.05, tz: 0.1, rotY: 0.38, ox: 0.05, ps: 1.28, poy: 0.06, float: 0.5, smoke: 0.7 },
      collar: macro('collar', 0.72, 0.28, 0.16, -0.15, [0.5, 0.25, 0.05]),
      buttons: macro('buttons', 0.5, -0.2, 0.06, 0.16, [-0.35, 0.12, 0.05]),
      emblem: macro('emblem', 0.36, 0.14, 0.05, -0.15, [0.3, 0.14, -0.02]),
      hem: macro('hem', 0.62, -0.22, 0.22, 0.15, [-0.45, 0.02, 0.02]),
      finale: { ...base, cx: -0.7, cy: 1.3, cz: 6.8, rotY: 0.32, ox: 0.2, poy: 0.12, float: 1, fov: 30 },
      product: { ...base, cx: 1.25, cy: 1.35, cz: 4.35, ty: 1.04, rotY: -0.18, fov: 30, ox: 0, poy: 0 },
      portrait: { ...base, cx: 0.55, cy: 1.55, cz: 2.7, ty: 1.3, rotY: -0.12, fov: 30, ox: 0, poy: 0 },
      side: { ...base, cx: 3.6, cy: 1.3, cz: 2.4, ty: 1.02, rotY: 0, fov: 30, ox: 0, poy: 0, smoke: 0.5 },
      back: { ...base, cx: -1.4, cy: 1.4, cz: -4.3, ty: 1.04, rotY: 0, fov: 30, ox: 0, poy: 0, smoke: 0.15 },
    };
  }

  setPointer(x: number, y: number) {
    this.pointer.set(x, y);
  }

  setSize(width: number, height: number) {
    this.width = Math.max(1, width);
    this.height = Math.max(1, height);
    this.renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
  }

  get portrait() {
    return this.width / this.height < 0.9;
  }

  /** Applies rig values and advances ambient motion. `time` is in seconds. */
  apply(rig: Rig, explode: number, time: number) {
    const portrait = this.portrait;
    const g = this.garment;
    g.setExplode(explode);
    g.root.rotation.y = rig.rotY + Math.sin(time * 0.35) * 0.025 * rig.float;
    g.root.position.y = GARMENT_Y + Math.sin(time * 0.6) * 0.012 * rig.float;

    this.pointerSmoothed.lerp(this.pointer, 0.06);
    const par = rig.float;
    const target = new THREE.Vector3(rig.tx, rig.ty, rig.tz);
    const cam = new THREE.Vector3(rig.cx, rig.cy, rig.cz);
    if (portrait) {
      const aspect = this.width / this.height;
      const scale = Math.min(2.2, Math.max(1, (0.62 / aspect) * 0.95)) * rig.ps;
      cam.sub(target).multiplyScalar(scale).add(target);
    }
    cam.x += this.pointerSmoothed.x * 0.14 * par;
    cam.y += -this.pointerSmoothed.y * 0.07 * par;

    const c = this.camera;
    c.position.copy(cam);
    c.fov = portrait ? rig.fov + 6 : rig.fov;
    c.lookAt(target);
    const w = this.width;
    const h = this.height;
    if (portrait) c.setViewOffset(w, h, 0, rig.poy * h, w, h);
    else c.setViewOffset(w, h, -rig.ox * w, 0, w, h);
    c.updateProjectionMatrix();

    this.detailLight.position.set(rig.dx, rig.dy, rig.dz);
    this.detailLight.intensity = rig.detail * 0.55;
    this.keyLight.intensity = 42 * rig.key;

    for (const s of this.smoke) {
      const t = time * s.speed + s.phase;
      s.sprite.position.set(s.base.x + Math.sin(t) * 0.25, s.base.y + Math.sin(t * 0.7) * 0.05, s.base.z + Math.cos(t * 0.8) * 0.12);
      (s.sprite.material as THREE.SpriteMaterial).opacity = s.opacity * rig.smoke;
      (s.sprite.material as THREE.SpriteMaterial).rotation = t * 0.3;
    }
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }

  /** Screen position (CSS px) of a world point, or null if behind the camera. */
  project(world: THREE.Vector3) {
    const v = world.clone().project(this.camera);
    if (v.z > 1) return null;
    return { x: (v.x * 0.5 + 0.5) * this.width, y: (-v.y * 0.5 + 0.5) * this.height };
  }

  dispose() {
    this.garment.dispose();
    this.materials.dispose();
    this.textures.dispose();
    this.disposables.forEach((d) => d.dispose());
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    this.renderer.domElement.remove();
  }
}
