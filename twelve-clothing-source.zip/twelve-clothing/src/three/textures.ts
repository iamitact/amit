import * as THREE from 'three';

/**
 * Procedural textures for the garment and atmosphere.
 * Everything is generated at runtime, so there are no texture downloads and no
 * third-party image assets to license.
 */

type HeightFn = (x: number, y: number) => number;

/** Seeded PRNG (mulberry32) so studio renders are repeatable. */
export function seeded(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Converts a tileable height field into a tangent-space normal map. */
function normalMapFromHeight(size: number, height: HeightFn, strength: number) {
  const h = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) h[y * size + x] = height(x, y);
  }
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const l = h[y * size + ((x - 1 + size) % size)];
      const r = h[y * size + ((x + 1) % size)];
      const d = h[((y - 1 + size) % size) * size + x];
      const u = h[((y + 1) % size) * size + x];
      let nx = (l - r) * strength;
      let ny = (d - u) * strength;
      let nz = 1;
      const len = Math.hypot(nx, ny, nz);
      nx /= len;
      ny /= len;
      nz /= len;
      const i = (y * size + x) * 4;
      data[i] = (nx * 0.5 + 0.5) * 255;
      data[i + 1] = (ny * 0.5 + 0.5) * 255;
      data[i + 2] = (nz * 0.5 + 0.5) * 255;
      data[i + 3] = 255;
    }
  }
  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  return tex;
}

/** Piqué knit: offset rows of small raised cells with a fine yarn grain. */
function piqueHeight(size: number): HeightFn {
  const cells = 32;
  const cw = size / cells;
  const rand = seeded(12);
  const grain = new Float32Array(size * size).map(() => rand());
  return (x, y) => {
    const row = Math.floor(y / cw);
    const ox = row % 2 === 0 ? 0 : cw / 2;
    const lx = (((x + ox) % cw) + cw) % cw;
    const ly = y % cw;
    const dx = (lx - cw / 2) / (cw * 0.46);
    const dy = (ly - cw / 2) / (cw * 0.5);
    const cell = Math.max(0, 1 - (dx * dx + dy * dy));
    return Math.pow(cell, 0.7) + grain[y * size + x] * 0.12;
  };
}

/** Rib knit: soft vertical ridges (along U) with light yarn grain. */
function ribHeight(size: number): HeightFn {
  const ribs = 32;
  const rand = seeded(7);
  const grain = new Float32Array(size * size).map(() => rand());
  return (x, y) => {
    const t = (x / size) * ribs * Math.PI * 2;
    return Math.pow(0.5 + 0.5 * Math.cos(t), 0.8) + grain[y * size + x] * 0.08;
  };
}

/** Collar colour map: base knit colour with two fine tipping stripes near the outer edge (V). */
function tippingMap(base: string, tip: string) {
  const c = document.createElement('canvas');
  c.width = 4;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 4, 256);
  ctx.fillStyle = tip;
  // canvas y=0 maps to v=1 (flipY), i.e. the outer edge of the collar
  ctx.fillRect(0, Math.round(256 * 0.05), 4, Math.round(256 * 0.035));
  ctx.fillRect(0, Math.round(256 * 0.12), 4, Math.round(256 * 0.02));
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Soft irregular smoke puff for sprites. */
function smokeTexture() {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  const rand = seeded(3);
  for (let i = 0; i < 26; i++) {
    const x = size / 2 + (rand() - 0.5) * size * 0.42;
    const y = size / 2 + (rand() - 0.5) * size * 0.3;
    const r = size * (0.14 + rand() * 0.2);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(255,255,255,${0.08 + rand() * 0.08})`);
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Radial glow used for the slate backdrop haze. */
function glowTexture(inner: string, outer: string) {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface SharedTextures {
  pique: THREE.DataTexture;
  rib: THREE.DataTexture;
  smoke: THREE.CanvasTexture;
  glow: THREE.CanvasTexture;
  dispose(): void;
}

export function createSharedTextures(quality: 'high' | 'low'): SharedTextures {
  const size = quality === 'high' ? 512 : 256;
  const pique = normalMapFromHeight(size, piqueHeight(size), 2.2);
  const rib = normalMapFromHeight(size, ribHeight(size), 1.6);
  const smoke = smokeTexture();
  const glow = glowTexture('rgba(52,56,63,0.9)', 'rgba(10,10,11,0)');
  return {
    pique,
    rib,
    smoke,
    glow,
    dispose() {
      pique.dispose();
      rib.dispose();
      smoke.dispose();
      glow.dispose();
    },
  };
}

export { tippingMap };
