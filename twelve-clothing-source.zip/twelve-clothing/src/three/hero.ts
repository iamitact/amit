import { createAdaptiveResolution, pickQuality } from './adaptive';
import { Stage } from './stage';
import { VARIANTS, DEFAULT_VARIANT } from './variants';

/**
 * Home-page hero: the garment floating in its spotlight with low drifting mist,
 * no scroll timeline. Renders only while visible and while the tab is shown.
 */
export function mountHero(opts: { host: HTMLElement; onReady: () => void; onFail: () => void }): () => void {
  let stage: Stage;
  try {
    stage = new Stage({ variant: VARIANTS[DEFAULT_VARIANT], quality: pickQuality() });
  } catch {
    opts.onFail();
    return () => {};
  }
  const canvas = stage.renderer.domElement;
  canvas.style.cssText = 'width:100%;height:100%;display:block';
  opts.host.appendChild(canvas);

  const shots = stage.computeShots();
  // slightly more mist than the story's opening shot: this is the brand's first impression
  const rig = { ...shots.hero, smoke: 2 };
  const adapt = createAdaptiveResolution(stage);

  const resize = () => {
    const r = opts.host.getBoundingClientRect();
    stage.setSize(r.width, r.height);
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(opts.host);

  const fine = window.matchMedia('(pointer: fine)').matches;
  const onPointer = (e: PointerEvent) => stage.setPointer((e.clientX / innerWidth) * 2 - 1, (e.clientY / innerHeight) * 2 - 1);
  if (fine) window.addEventListener('pointermove', onPointer, { passive: true });

  let raf = 0;
  let inView = true;
  let ready = false;
  let disposed = false;
  let last = performance.now();
  const start = last;
  const frame = () => {
    raf = 0;
    const now = performance.now();
    if (ready) adapt(now, now - last);
    last = now;
    stage.apply(rig, 0, (now - start) / 1000);
    stage.render();
    if (!ready) {
      ready = true;
      opts.onReady();
    }
    if (inView && !document.hidden) raf = requestAnimationFrame(frame);
  };
  const kick = () => {
    if (!disposed && !raf && inView && !document.hidden) raf = requestAnimationFrame(frame);
  };
  const io = new IntersectionObserver(([e]) => {
    inView = e.isIntersecting;
    kick();
  });
  io.observe(opts.host);
  document.addEventListener('visibilitychange', kick);

  let lostTimer = 0;
  const onLost = (e: Event) => {
    e.preventDefault();
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    lostTimer = window.setTimeout(opts.onFail, 2500);
  };
  const onRestored = () => {
    window.clearTimeout(lostTimer);
    kick();
  };
  canvas.addEventListener('webglcontextlost', onLost);
  canvas.addEventListener('webglcontextrestored', onRestored);

  stage.apply(rig, 0, 0);
  stage.warmUp().then(kick);

  return () => {
    disposed = true;
    if (raf) cancelAnimationFrame(raf);
    io.disconnect();
    ro.disconnect();
    document.removeEventListener('visibilitychange', kick);
    window.removeEventListener('pointermove', onPointer);
    canvas.removeEventListener('webglcontextlost', onLost);
    canvas.removeEventListener('webglcontextrestored', onRestored);
    window.clearTimeout(lostTimer);
    stage.dispose();
  };
}
