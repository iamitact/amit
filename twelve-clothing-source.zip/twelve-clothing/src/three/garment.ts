import * as THREE from 'three';
import type { GarmentMaterials } from './materials';
import type { GarmentStyle } from './variants';

/**
 * An original, procedurally modelled knit polo.
 *
 * The body is two superellipse half-shells (front / back), each continuing from
 * hem to shoulder into a sloped yoke that closes at the neckline, so the
 * shoulder seam falls exactly where the halves meet. Sleeves, cuffs, hem band,
 * collar, neck tape, placket, buttons and emblem are separate meshes so the
 * garment can deconstruct into twelve pieces and reassemble without clipping.
 *
 * Units: roughly 1 scene unit = 48 cm. Origin is the hem centre.
 */

export type AnchorName = 'collar' | 'placket' | 'buttons' | 'emblem' | 'hem' | 'sleeve' | 'back';

export interface GarmentPart {
  name: string;
  group: THREE.Group;
  pivot: THREE.Vector3;
  offset: THREE.Vector3;
  rotation: THREE.Euler;
  delay: number;
}

export interface Garment {
  root: THREE.Group;
  parts: GarmentPart[];
  anchors: Record<AnchorName, THREE.Object3D>;
  setExplode(e: number): void;
  dispose(): void;
}

const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

function knots(k: [number, number][], v: number) {
  if (v <= k[0][0]) return k[0][1];
  for (let i = 1; i < k.length; i++) {
    if (v <= k[i][0]) {
      const [a, va] = k[i - 1];
      const [b, vb] = k[i];
      return va + (vb - va) * smooth(a, b, v);
    }
  }
  return k[k.length - 1][1];
}

// ---------------------------------------------------------------- body shape

const H = 1.34; // height of the shoulder line
const EXP = 2.7; // superellipse exponent: flatter front/back than an ellipse
const halfWidth = (v: number) =>
  knots([[0, 0.535], [0.3, 0.512], [0.6, 0.55], [0.8, 0.566], [0.92, 0.54], [1, 0.472]], v);
const halfDepth = (v: number) =>
  knots([[0, 0.2], [0.3, 0.19], [0.62, 0.222], [0.86, 0.208], [1, 0.176]], v);

const NRX = 0.148;
const NRZ = 0.128;
const NZ0 = -0.022;
const neckY = (th: number) => H + 0.145 - 0.075 * Math.pow(Math.max(0, Math.sin(th)), 2);
const neckPoint = (th: number) => V(NRX * Math.cos(th), neckY(th), NZ0 + NRZ * Math.sin(th));
const neckOut = (th: number) => V(Math.cos(th) / NRX, 0, Math.sin(th) / NRZ).normalize();

function superXZ(th: number, w: number, d: number) {
  const c = Math.cos(th);
  const s = Math.sin(th);
  return [w * Math.sign(c) * Math.pow(Math.abs(c), 2 / EXP), d * Math.sign(s) * Math.pow(Math.abs(s), 2 / EXP)];
}

/** Low-frequency drape: hem waves, side wrinkles, a slight waist pull. */
function bodyFold(th: number, v: number) {
  const hem = 1 - smooth(0, 0.42, v);
  const side = Math.pow(Math.abs(Math.cos(th)), 6);
  return (
    0.0035 * Math.sin(th * 13 + v * 9) * (0.4 + hem) +
    0.012 * Math.sin(th * 6 + 0.8) * hem +
    0.007 * Math.sin(v * 20 + th * 3) * side * smooth(0.35, 0.8, v) -
    0.006 * smooth(0.22, 0.42, v) * (1 - smooth(0.42, 0.6, v))
  );
}

/** Point on the body tube (hem → shoulder line) with drape applied. */
function bodyPoint(th: number, v: number, inflate = 0) {
  const w = halfWidth(v) + inflate;
  const d = halfDepth(v) + inflate;
  const [x, z] = superXZ(th, w, d);
  const n = V(x / (w * w), 0, z / (d * d)).normalize();
  const f = bodyFold(th, v);
  const backDrop = 0.045 * Math.pow(Math.max(0, -Math.sin(th)), 1.5) * Math.pow(1 - v, 3);
  return V(x + n.x * f, v * H - backDrop, z + n.z * f);
}

/** Point on the yoke between the shoulder line (s=0) and neckline (s=1). */
function yokePoint(th: number, s: number) {
  const outer = bodyPoint(th, 1);
  const inner = neckPoint(th);
  // ease the horizontal travel in and the rise out, so the chest turns into the
  // shoulder with a rounded, tangent-continuous crown instead of a crease
  const p = outer.clone().lerp(inner, Math.pow(s, 1.55));
  p.y = THREE.MathUtils.lerp(outer.y, inner.y, Math.sin((s * Math.PI) / 2)) + 0.02 * Math.sin(Math.PI * s);
  return p;
}

// ------------------------------------------------------------- mesh helpers

function gridGeometry(
  cols: number,
  rows: number,
  fn: (c: number, r: number) => THREE.Vector3,
  uvFn: (c: number, r: number, p: THREE.Vector3) => [number, number],
) {
  const pos = new Float32Array(cols * rows * 3);
  const uv = new Float32Array(cols * rows * 2);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const p = fn(c, r);
      const i = r * cols + c;
      pos.set([p.x, p.y, p.z], i * 3);
      uv.set(uvFn(c, r, p), i * 2);
    }
  }
  const idx: number[] = [];
  for (let r = 0; r < rows - 1; r++) {
    for (let c = 0; c < cols - 1; c++) {
      const a = r * cols + c;
      const b = a + 1;
      const d = a + cols;
      const e = d + 1;
      idx.push(a, b, d, b, e, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/** Thin rolled edge (fabric thickness) along a closed or open curve. */
function rolledEdge(points: THREE.Vector3[], radius: number, closed: boolean) {
  const curve = new THREE.CatmullRomCurve3(points, closed, 'centripetal');
  return new THREE.TubeGeometry(curve, Math.max(24, points.length * 2), radius, 6, closed);
}

/** Instanced stitch dashes along a polyline, lying on the surface. */
function stitches(
  points: THREE.Vector3[],
  normals: THREE.Vector3[],
  material: THREE.Material,
  spacing = 0.0105,
  dash = 0.0062,
) {
  const lengths = [0];
  for (let i = 1; i < points.length; i++) lengths.push(lengths[i - 1] + points[i].distanceTo(points[i - 1]));
  const total = lengths[lengths.length - 1];
  const count = Math.max(1, Math.floor(total / spacing));
  const geo = new THREE.BoxGeometry(dash, 0.0015, 0.0014);
  const mesh = new THREE.InstancedMesh(geo, material, count);
  const m = new THREE.Matrix4();
  const t = V();
  const n = V();
  const b = V();
  const p = V();
  let seg = 1;
  for (let k = 0; k < count; k++) {
    const target = (k + 0.5) * spacing;
    while (seg < points.length - 1 && lengths[seg] < target) seg++;
    const a = seg - 1;
    const f = (target - lengths[a]) / Math.max(1e-6, lengths[seg] - lengths[a]);
    p.copy(points[a]).lerp(points[seg], f);
    t.subVectors(points[seg], points[a]).normalize();
    n.copy(normals[a]).lerp(normals[seg], f).normalize();
    b.crossVectors(n, t).normalize();
    n.crossVectors(t, b).normalize();
    m.makeBasis(t, b, n).setPosition(p.addScaledVector(n, 0.0008));
    mesh.setMatrixAt(k, m);
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.castShadow = false;
  return mesh;
}

/** Closest vertex of a geometry to a point in the XY plane on its +Z side. */
function sampleFront(geo: THREE.BufferGeometry, x: number, y: number) {
  const pos = geo.getAttribute('position');
  const nor = geo.getAttribute('normal');
  let best = -1;
  let bd = Infinity;
  for (let i = 0; i < pos.count; i++) {
    if (pos.getZ(i) <= 0) continue;
    const d = (pos.getX(i) - x) ** 2 + (pos.getY(i) - y) ** 2;
    if (d < bd) {
      bd = d;
      best = i;
    }
  }
  const n = V(nor.getX(best), nor.getY(best), nor.getZ(best)).normalize();
  if (n.z < 0) n.negate(); // grid winding may yield inward normals; we need the outward one
  return { p: V(pos.getX(best), pos.getY(best), pos.getZ(best)), n };
}

// ------------------------------------------------------------------- build

export function buildGarment(style: GarmentStyle, mats: GarmentMaterials): Garment {
  const root = new THREE.Group();
  root.name = 'garment';
  const geometries: THREE.BufferGeometry[] = [];
  const track = <T extends THREE.BufferGeometry>(g: T) => {
    geometries.push(g);
    return g;
  };
  const mesh = (g: THREE.BufferGeometry, m: THREE.Material, shadow = true) => {
    const x = new THREE.Mesh(track(g), m);
    x.castShadow = shadow;
    return x;
  };

  const COLS = 49;
  const TUBE_ROWS = 58;
  const YOKE_ROWS = 14;
  const isPolo = style.neck === 'polo';

  // ---- body halves: tube rows followed by yoke rows in one grid (smooth normals)
  const half = (th0: number) =>
    gridGeometry(
      COLS,
      TUBE_ROWS + YOKE_ROWS,
      (c, r) => {
        const th = th0 + (c / (COLS - 1)) * Math.PI;
        if (r < TUBE_ROWS) return bodyPoint(th, r / (TUBE_ROWS - 1));
        return yokePoint(th, (r - TUBE_ROWS + 1) / YOKE_ROWS);
      },
      (c, _r, p) => [(c / (COLS - 1)) * 1.6, p.y],
    );
  const frontGeo = half(0);
  const backGeo = half(Math.PI);
  const front = mesh(frontGeo, mats.fabric);
  const back = mesh(backGeo, mats.fabric);

  // shoulder seam stitching (on the back panel, where the halves meet)
  const shoulderSeam = (side: 1 | -1) => {
    const pts: THREE.Vector3[] = [];
    const nrm: THREE.Vector3[] = [];
    const th = side === 1 ? 0 : Math.PI;
    for (let i = 0; i <= 16; i++) {
      const s = 0.04 + (i / 16) * 0.9;
      const p = yokePoint(th, s);
      pts.push(p.add(V(0, 0.001, -0.006)));
      nrm.push(V(0, 1, 0));
    }
    return stitches(pts, nrm, mats.stitch);
  };
  const backStitches = [shoulderSeam(1), shoulderSeam(-1)];

  // ---- hem band (full circle), with rolled lower edge and a stitch line
  const HEM_H = 0.05;
  const hemV = HEM_H / H;
  const hemGeo = gridGeometry(
    129,
    6,
    (c, r) => bodyPoint((c / 128) * Math.PI * 2, (r / 5) * hemV - 0.002, 0.0038),
    (c, r) => [(c / 128) * 3.2, (r / 5) * HEM_H],
  );
  const hemRing = (vv: number, inflate: number) =>
    Array.from({ length: 96 }, (_, i) => bodyPoint((i / 96) * Math.PI * 2, vv, inflate));
  const hemEdge = rolledEdge(hemRing(-0.002, 0.0038), 0.0042, true);
  const hemStitchPts = hemRing(hemV * 0.62, 0.0045);
  hemStitchPts.push(hemStitchPts[0].clone());
  const hemStitch = stitches(
    hemStitchPts,
    hemStitchPts.map((p) => V(p.x, 0, p.z).normalize()),
    mats.stitch,
  );

  // ---- sleeves and cuffs
  const buildSleeve = (side: 1 | -1) => {
    const long = style.sleeve === 'long';
    const start = V(side * 0.36, H - 0.14, -0.006);
    const dir = (long ? V(side * 0.27, -1, 0.05) : V(side * 0.7, -0.72, 0.02)).normalize();
    const L = long ? 0.92 : 0.44;
    const r0 = [0.2, 0.18];
    const r1 = long ? [0.098, 0.09] : [0.158, 0.142];
    const p1 = V(-dir.y * side, dir.x * side, 0).normalize();
    const p2 = V().crossVectors(dir, p1).normalize();
    if (p2.z < 0) p2.negate();
    const ringPoint = (t: number, phi: number, extra = 0) => {
      const e = easeInOut(clamp01(t));
      const ra = THREE.MathUtils.lerp(r0[0], r1[0], e) + extra;
      const rb = THREE.MathUtils.lerp(r0[1], r1[1], e) + extra;
      const wr =
        0.009 * Math.sin(phi * 5 + t * 8) * (1 - clamp01(t)) * Math.max(0, -Math.cos(phi)) +
        (long ? 0.007 * Math.sin(phi * 3 + t * 30) * Math.exp(-(((t - 0.55) / 0.13) ** 2)) : 0) +
        0.003 * Math.sin(phi * 9 + t * 5);
      return start
        .clone()
        .addScaledVector(dir, t * L)
        .addScaledVector(p1, Math.cos(phi) * (ra + wr))
        .addScaledVector(p2, Math.sin(phi) * (rb + wr));
    };
    const sleeveGeo = gridGeometry(
      49,
      long ? 40 : 22,
      (c, r) => ringPoint(r / ((long ? 40 : 22) - 1), (c / 48) * Math.PI * 2),
      (c, r) => [(c / 48) * 1.1, (r / ((long ? 40 : 22) - 1)) * L],
    );
    const sleeve = mesh(sleeveGeo, mats.fabric);
    // armhole seam stitching, only the visible upper arc
    const armPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 24; i++) armPts.push(ringPoint(0.1, -Math.PI * 0.55 + (i / 24) * Math.PI * 1.1, 0.002));
    const armStitch = stitches(
      armPts,
      armPts.map((p) => p.clone().sub(start.clone().addScaledVector(dir, 0.1 * L)).normalize()),
      mats.stitch,
    );

    // cuff: rib band continuing from the sleeve end
    const CUFF = long ? 0.085 : 0.05;
    const cuffStart = start.clone().addScaledVector(dir, L);
    const cuffPoint = (t: number, phi: number, extra = 0) => {
      const ra = r1[0] * (1 - 0.05 * t) + 0.003 + extra;
      const rb = r1[1] * (1 - 0.05 * t) + 0.003 + extra;
      return cuffStart
        .clone()
        .addScaledVector(dir, t * CUFF - 0.004)
        .addScaledVector(p1, Math.cos(phi) * ra)
        .addScaledVector(p2, Math.sin(phi) * rb);
    };
    const cuffGeo = gridGeometry(
      49,
      6,
      (c, r) => cuffPoint(r / 5, (c / 48) * Math.PI * 2),
      (c, r) => [(c / 48) * 1.0, (r / 5) * CUFF],
    );
    const cuff = mesh(cuffGeo, long ? mats.rib : mats.fabric);
    const edgePts = Array.from({ length: 48 }, (_, i) => cuffPoint(1, (i / 48) * Math.PI * 2));
    const cuffEdge = mesh(rolledEdge(edgePts, 0.0042, true), long ? mats.rib : mats.fabric);
    const cuffStitchPts = Array.from({ length: 49 }, (_, i) => cuffPoint(0.55, (i / 48) * Math.PI * 2, 0.0012));
    const cuffStitch = stitches(
      cuffStitchPts,
      cuffStitchPts.map((p) => p.clone().sub(cuffStart).normalize()),
      mats.stitch,
    );
    const end = start.clone().addScaledVector(dir, L + CUFF);
    return { sleeve, armStitch, cuff, cuffEdge, cuffStitch, start, dir, end, L };
  };
  const sleeveR = buildSleeve(1);
  const sleeveL = buildSleeve(-1);

  // ---- collar (polo: stand + fall with pointed fronts; crew: rib band)
  const GAP = isPolo ? 0.2 : 0;
  const th0 = Math.PI / 2 + GAP;
  const th1 = Math.PI / 2 + Math.PI * 2 - GAP;
  const profile = isPolo
    ? [V(-0.004, 0), V(-0.008, 0.05), V(0.006, 0.066), V(0.066, 0.036), V(0.128, -0.026)]
    : [V(-0.003, 0), V(-0.004, 0.024), V(0.005, 0.032), V(0.013, 0.022)];
  const prof = new THREE.CatmullRomCurve3(profile, false, 'centripetal');
  const PROFILE_ROWS = isPolo ? 22 : 10;
  const COLLAR_COLS = 121;
  const collarPoint = (c: number, s: number) => {
    const th = th0 + (c / (COLLAR_COLS - 1)) * (th1 - th0);
    const q = prof.getPoint(s);
    let o = q.x;
    let up = q.y;
    if (isPolo) {
      const dEnd = Math.min(th - th0, th1 - th);
      const pf = 1 - smooth(0, 0.95, dEnd);
      const fall = smooth(0.42, 1, s);
      o += pf * 0.055 * fall;
      up -= pf * 0.075 * fall;
      up += 0.0018 * Math.sin(th * 7) * fall;
    }
    return neckPoint(th).addScaledVector(neckOut(th), o).add(V(0, up, 0));
  };
  const collarGeo = gridGeometry(
    COLLAR_COLS,
    PROFILE_ROWS,
    (c, r) => collarPoint(c, r / (PROFILE_ROWS - 1)),
    (c, r) => [(c / (COLLAR_COLS - 1)) * 0.95, r / (PROFILE_ROWS - 1)],
  );
  const collar = mesh(collarGeo, isPolo ? mats.collar : mats.rib);
  const collarEdgePts = Array.from({ length: 61 }, (_, i) => collarPoint(i * 2, 1));
  const collarEdge = mesh(rolledEdge(collarEdgePts, 0.0036, false), isPolo ? mats.collar : mats.rib);

  // ---- neck tape: a strip inside the back neckline
  const TAPE_COLS = 40;
  const tapeGeo = gridGeometry(
    TAPE_COLS,
    3,
    (c, r) => {
      const th = Math.PI + 0.35 + (c / (TAPE_COLS - 1)) * (Math.PI - 0.7);
      return neckPoint(th)
        .addScaledVector(neckOut(th), -0.009)
        .add(V(0, -0.026 + (r / 2) * 0.03, 0));
    },
    (c, r) => [c / (TAPE_COLS - 1), r / 2],
  );
  const tape = mesh(tapeGeo, mats.tape, false);

  // ---- placket, buttons (polo only)
  const placketGroup: THREE.Object3D[] = [];
  const buttonGroup: THREE.Object3D[] = [];
  let placketTop = V();
  let buttonPos = V();
  let placketNormal = V(0, 0, 1);
  if (isPolo) {
    const centre = (COLS - 1) / 2;
    const pos = frontGeo.getAttribute('position');
    const path: THREE.Vector3[] = [];
    const topY = neckY(Math.PI / 2) - 0.004;
    const botY = H - 0.25;
    for (let r = TUBE_ROWS + YOKE_ROWS - 1; r >= 0; r--) {
      const i = r * COLS + centre;
      const p = V(0, pos.getY(i), pos.getZ(i));
      if (p.y <= topY && p.y >= botY) path.push(p);
    }
    const curve = new THREE.CatmullRomCurve3(path, false, 'centripetal');
    const samples = curve.getSpacedPoints(36);
    const X = V(1, 0, 0);
    const frames = samples.map((p, i) => {
      const t = (i < samples.length - 1 ? samples[i + 1].clone().sub(p) : p.clone().sub(samples[i - 1])).normalize();
      return { p, n: V().crossVectors(t, X).normalize(), t };
    });
    const PW = 0.031;
    const PT = 0.0075;
    const OFF = 0.0015;
    const ring: [number, number][] = [];
    const cr = 0.003;
    const corners: [number, number, number][] = [
      [PW - cr, PT - cr, 0],
      [-PW + cr, PT - cr, Math.PI / 2],
      [-PW + cr, cr, Math.PI],
      [PW - cr, cr, Math.PI * 1.5],
    ];
    for (const [cx, cy, a0] of corners) {
      for (let k = 0; k <= 4; k++) {
        const a = a0 + (k / 4) * (Math.PI / 2);
        ring.push([cx + Math.cos(a) * cr, cy + Math.sin(a) * cr]);
      }
    }
    const RC = ring.length;
    const verts: number[] = [];
    const uvs: number[] = [];
    frames.forEach(({ p, n }, i) => {
      ring.forEach(([x, y], k) => {
        const v = p.clone().addScaledVector(X, x).addScaledVector(n, OFF + y);
        verts.push(v.x, v.y, v.z);
        uvs.push((k / RC) * 0.14, (i / (frames.length - 1)) * 0.3);
      });
    });
    const index: number[] = [];
    for (let i = 0; i < frames.length - 1; i++) {
      for (let k = 0; k < RC; k++) {
        const a = i * RC + k;
        const b = i * RC + ((k + 1) % RC);
        const c = a + RC;
        const d = b + RC;
        index.push(a, c, b, b, c, d);
      }
    }
    // end caps
    const capBase = verts.length / 3;
    for (const fi of [0, frames.length - 1]) {
      const { p, n } = frames[fi];
      const cc = p.clone().addScaledVector(n, OFF + PT / 2);
      verts.push(cc.x, cc.y, cc.z);
      uvs.push(0, 0);
    }
    for (let k = 0; k < RC; k++) {
      index.push(capBase, k, (k + 1) % RC);
      const last = (frames.length - 1) * RC;
      index.push(capBase + 1, last + ((k + 1) % RC), last + k);
    }
    const placketGeo = new THREE.BufferGeometry();
    placketGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    placketGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    placketGeo.setIndex(index);
    placketGeo.computeVertexNormals();
    placketGroup.push(mesh(placketGeo, mats.fabric));

    // box-stitched outline around the placket
    const outline: THREE.Vector3[] = [];
    const outlineN: THREE.Vector3[] = [];
    const inset = PW - 0.0065;
    const surf = (f: (typeof frames)[number], x: number) =>
      f.p.clone().addScaledVector(X, x).addScaledVector(f.n, OFF + PT);
    frames.forEach((f) => {
      outline.push(surf(f, -inset));
      outlineN.push(f.n);
    });
    const lastF = frames[frames.length - 3];
    for (let k = 1; k <= 8; k++) {
      outline.push(surf(lastF, -inset + (k / 8) * inset * 2));
      outlineN.push(lastF.n);
    }
    for (let i = frames.length - 3; i >= 0; i--) {
      outline.push(surf(frames[i], inset));
      outlineN.push(frames[i].n);
    }
    placketGroup.push(stitches(outline, outlineN, mats.stitch));

    // two dished buttons with cross-stitched thread
    const lathe = [
      new THREE.Vector2(0.0001, 0.0026),
      new THREE.Vector2(0.006, 0.0034),
      new THREE.Vector2(0.0098, 0.0042),
      new THREE.Vector2(0.0113, 0.0036),
      new THREE.Vector2(0.0118, 0.0018),
      new THREE.Vector2(0.0112, 0),
      new THREE.Vector2(0.0001, 0),
    ];
    const buttonGeo = track(new THREE.LatheGeometry(lathe, 40));
    const holeGeo = track(new THREE.CircleGeometry(0.0014, 16));
    const threadGeo = track(new THREE.BoxGeometry(0.0078, 0.0012, 0.0011));
    [0.24, 0.6].forEach((f, bi) => {
      const fr = frames[Math.round(f * (frames.length - 1))];
      const b = new THREE.Group();
      const bm = new THREE.Mesh(buttonGeo, mats.button);
      bm.castShadow = true;
      b.add(bm);
      for (const [hx, hz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
        const h = new THREE.Mesh(holeGeo, mats.buttonHole);
        h.rotation.x = -Math.PI / 2;
        h.position.set(hx * 0.0027, 0.00345, hz * 0.0027);
        b.add(h);
      }
      for (const rot of [Math.PI / 4, -Math.PI / 4]) {
        const t = new THREE.Mesh(threadGeo, mats.thread);
        t.position.y = 0.0041;
        t.rotation.y = rot;
        b.add(t);
      }
      b.position.copy(fr.p).addScaledVector(fr.n, OFF + PT + 0.0002);
      b.quaternion.setFromUnitVectors(V(0, 1, 0), fr.n);
      buttonGroup.push(b);
      if (bi === 0) buttonPos = b.position.clone();
    });
    placketTop = frames[Math.round(0.12 * (frames.length - 1))].p.clone();
    placketNormal = frames[Math.round(0.4 * (frames.length - 1))].n.clone();
  }

  // ---- the Dial: twelve raised marks in a ring (the Twelve emblem)
  const emblem = new THREE.Group();
  const E = sampleFront(frontGeo, 0.215, 1.05);
  {
    const ring = new THREE.Mesh(track(new THREE.TorusGeometry(0.029, 0.0017, 8, 72)), mats.thread);
    emblem.add(ring);
    const tickGeo = track(new THREE.BoxGeometry(0.0024, 0.0085, 0.0022));
    const longTick = track(new THREE.BoxGeometry(0.0026, 0.0125, 0.0024));
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const t = new THREE.Mesh(i === 0 ? longTick : tickGeo, mats.thread);
      const r = i === 0 ? 0.0178 : 0.0198;
      t.position.set(Math.sin(a) * r, Math.cos(a) * r, 0.0006);
      t.rotation.z = -a;
      emblem.add(t);
    }
    const dot = new THREE.Mesh(track(new THREE.SphereGeometry(0.0028, 16, 10)), mats.thread);
    dot.scale.z = 0.45;
    emblem.add(dot);
    emblem.position.copy(E.p).addScaledVector(E.n, 0.0012);
    emblem.quaternion.setFromUnitVectors(V(0, 0, 1), E.n);
  }

  // ---------------------------------------------------------------- parts
  const parts: GarmentPart[] = [];
  const anchors = {} as Record<AnchorName, THREE.Object3D>;
  const addPart = (
    name: string,
    objects: THREE.Object3D[],
    pivot: THREE.Vector3,
    offset: THREE.Vector3,
    rotation: THREE.Euler,
    delay: number,
  ) => {
    const group = new THREE.Group();
    group.name = name;
    group.position.copy(pivot);
    objects.forEach((o) => {
      o.position.sub(pivot);
      group.add(o);
    });
    root.add(group);
    parts.push({ name, group, pivot: pivot.clone(), offset, rotation, delay });
    return group;
  };
  const anchor = (name: AnchorName, parent: THREE.Group, world: THREE.Vector3, normal: THREE.Vector3) => {
    const a = new THREE.Object3D();
    a.position.copy(world).sub(parent.position);
    a.userData.normal = normal.clone().normalize();
    parent.add(a);
    anchors[name] = a;
  };

  const frontPart = addPart('front', [front], V(0, 0.8, 0.12), V(0.12, -0.04, 0.3), new THREE.Euler(0.04, 0, 0), 0.06);
  const backPart = addPart('back', [back, ...backStitches], V(0, 0.8, -0.12), V(-0.3, 0.1, -0.5), new THREE.Euler(-0.05, 0, 0), 0.1);
  const collarPart = addPart('collar', [collar, collarEdge], V(0, 1.47, -0.02), V(0, 0.4, 0.05), new THREE.Euler(-0.28, 0, 0), 0);
  addPart('tape', [tape], V(0, 1.44, -0.14), V(-0.18, 0.34, -0.72), new THREE.Euler(0.2, 0, 0), 0.04);
  const hemPart = addPart('hem', [mesh(hemGeo, mats.rib), mesh(hemEdge, mats.rib), hemStitch], V(0, 0.02, 0), V(0, -0.25, 0.12), new THREE.Euler(0.08, 0, 0), 0.14);
  const sleevePartR = addPart('sleeveR', [sleeveR.sleeve, sleeveR.armStitch], sleeveR.start.clone(), V(0.62, 0.1, 0), new THREE.Euler(0, 0, -0.22), 0.08);
  addPart('sleeveL', [sleeveL.sleeve, sleeveL.armStitch], sleeveL.start.clone(), V(-0.62, 0.1, 0), new THREE.Euler(0, 0, 0.22), 0.08);
  addPart('cuffR', [sleeveR.cuff, sleeveR.cuffEdge, sleeveR.cuffStitch], sleeveR.end.clone(), V(1.0, -0.08, 0.06), new THREE.Euler(0, 0, -0.3), 0.16);
  addPart('cuffL', [sleeveL.cuff, sleeveL.cuffEdge, sleeveL.cuffStitch], sleeveL.end.clone(), V(-1.0, -0.08, 0.06), new THREE.Euler(0, 0, 0.3), 0.16);
  let placketPart: THREE.Group | null = null;
  let buttonPart: THREE.Group | null = null;
  if (isPolo) {
    placketPart = addPart('placket', placketGroup, placketTop.clone(), V(0.42, 0.12, 0.5), new THREE.Euler(0.1, 0, 0), 0.12);
    buttonPart = addPart('buttons', buttonGroup, buttonPos.clone(), V(0.46, 0.04, 0.95), new THREE.Euler(0, 0, 0), 0.18);
  }
  const emblemRest = emblem.position.clone(); // captured before re-parenting offsets it
  const emblemPart = addPart('emblem', [emblem], emblemRest.clone(), V(0.62, 0.5, 0.55), new THREE.Euler(0, 0.25, 0), 0.2);

  // anchors (world == garment-local here: parts start at rest)
  const collarFront = collarPoint(Math.round(COLLAR_COLS * 0.08), 0.8);
  anchor('collar', collarPart, collarFront, V(0.35, 0.35, 1));
  anchor('placket', placketPart ?? frontPart, isPolo ? placketTop : bodyPoint(Math.PI / 2, 0.85), placketNormal);
  anchor('buttons', buttonPart ?? frontPart, isPolo ? buttonPos : bodyPoint(Math.PI / 2, 0.8), placketNormal);
  anchor('emblem', emblemPart, emblemRest, E.n);
  anchor('hem', hemPart, bodyPoint(Math.PI / 2 + 0.55, 0.012, 0.004), V(-0.45, 0.1, 1));
  anchor('sleeve', sleevePartR, sleeveR.end, V(0.6, 0, 1));
  anchor('back', backPart, bodyPoint(-Math.PI / 2 - 0.3, 0.55), V(0, 0, -1));

  const setExplode = (e: number) => {
    for (const part of parts) {
      const k = easeInOut(clamp01((e - part.delay * 0.6) / (1 - 0.6 * 0.2)));
      part.group.position.copy(part.pivot).addScaledVector(part.offset, k);
      part.group.rotation.set(part.rotation.x * k, part.rotation.y * k, part.rotation.z * k);
    }
  };

  return {
    root,
    parts,
    anchors,
    setExplode,
    dispose() {
      geometries.forEach((g) => g.dispose());
      root.traverse((o) => {
        if (o instanceof THREE.InstancedMesh) o.geometry.dispose();
      });
    },
  };
}
