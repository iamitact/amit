/** Garment colourways and cuts. Shared by the live scene and the still renderer. */

export interface GarmentPalette {
  fabric: string;
  sheen: string;
  tipping: string;
  stitch: string;
  thread: string;
  threadSheen: string;
  button: string;
  tape: string;
}

export interface GarmentStyle {
  sleeve: 'short' | 'long';
  neck: 'polo' | 'crew';
}

export interface GarmentVariant {
  id: string;
  palette: GarmentPalette;
  style: GarmentStyle;
}

export const VARIANTS: Record<string, GarmentVariant> = {
  'nocturne-black': {
    id: 'nocturne-black',
    palette: {
      fabric: '#1e1e21',
      sheen: '#8c9199',
      tipping: '#3b3b40',
      stitch: '#34343a',
      thread: '#5b4d38',
      threadSheen: '#e3cf9f',
      button: '#161618',
      tape: '#1a1a1d',
    },
    style: { sleeve: 'short', neck: 'polo' },
  },
  'nocturne-ivory': {
    id: 'nocturne-ivory',
    palette: {
      fabric: '#d8d0c0',
      sheen: '#fff4e0',
      tipping: '#1d1d20',
      stitch: '#bfb5a2',
      thread: '#27272a',
      threadSheen: '#77777d',
      button: '#e6dccb',
      tape: '#c4b9a5',
    },
    style: { sleeve: 'short', neck: 'polo' },
  },
  'vesper-slate': {
    id: 'vesper-slate',
    palette: {
      fabric: '#3b4048',
      sheen: '#aeb7c4',
      tipping: '#1b1d21',
      stitch: '#4c525b',
      thread: '#9aa1ab',
      threadSheen: '#dfe5ee',
      button: '#24272c',
      tape: '#30343a',
    },
    style: { sleeve: 'long', neck: 'polo' },
  },
  'hour-tee': {
    id: 'hour-tee',
    palette: {
      fabric: '#1c1c1f',
      sheen: '#858a93',
      tipping: '#1c1c1f',
      stitch: '#313136',
      thread: '#5b4d38',
      threadSheen: '#e3cf9f',
      button: '#161618',
      tape: '#29292d',
    },
    style: { sleeve: 'short', neck: 'crew' },
  },
};

export const DEFAULT_VARIANT = 'nocturne-black';
