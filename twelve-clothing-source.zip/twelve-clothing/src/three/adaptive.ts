import type { Stage } from './stage';

/**
 * Adaptive resolution, evaluated once per second with hysteresis. Each change
 * reallocates the drawing buffer, so changes are rare: at most one per 3 s and
 * four per page view, stepping down after two slow seconds (>24 ms/frame) and
 * back up only after five fast ones (<12 ms/frame).
 */
export function createAdaptiveResolution(stage: Stage) {
  let windowStart = performance.now();
  let frames = 0;
  let total = 0;
  let slow = 0;
  let fast = 0;
  let lastChange = 0;
  let changes = 0;
  return (now: number, dt: number) => {
    if (dt > 250) return; // tab switches and pauses are not load
    frames++;
    total += dt;
    if (now - windowStart < 1000) return;
    const avg = total / frames;
    windowStart = now;
    frames = 0;
    total = 0;
    slow = avg > 24 ? slow + 1 : 0;
    fast = avg < 12 ? fast + 1 : 0;
    if (changes >= 4 || now - lastChange < 3000) return;
    const current = stage.renderer.getPixelRatio();
    if (slow >= 2 && current > stage.minPixelRatio) {
      stage.setPixelRatio(current - 0.15);
      lastChange = now;
      changes++;
      slow = 0;
    } else if (fast >= 5 && current < stage.maxPixelRatio) {
      stage.setPixelRatio(current + 0.15);
      lastChange = now;
      changes++;
      fast = 0;
    }
  };
}

export function pickQuality(): 'high' | 'low' {
  const cores = navigator.hardwareConcurrency ?? 8;
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
  const coarse = window.matchMedia('(pointer: coarse)').matches;
  if (cores <= 4 || memory <= 4 || (coarse && window.innerWidth < 900)) return 'low';
  return 'high';
}
