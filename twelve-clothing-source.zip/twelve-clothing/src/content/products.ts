/**
 * Demo catalogue. Prices, fabrics and garments are illustrative content for a
 * demo storefront: edit them here. Nothing is connected to real inventory.
 */

export const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'] as const;
export type Size = (typeof SIZES)[number];

export interface Product {
  id: string;
  name: string;
  colorway: string;
  price: number; // USD, demo value
  line: string;
  description: string;
  details: string[];
  image: string; // base name in public/renders (without width suffix)
  imageAlt: string;
}

export const FLAGSHIP_ID = 'nocturne-black';

export const PRODUCTS: Product[] = [
  {
    id: 'nocturne-black',
    name: 'Nocturne Polo',
    colorway: 'Black',
    price: 185,
    line: 'Short-sleeve piqué polo',
    description:
      'Our signature polo in black cotton piqué. A fully fashioned rib collar with tonal tipping, a two-button placket and the embroidered Dial on the chest.',
    details: ['Cotton piqué, mid-weight', 'Rib collar with tonal tipping', 'Two dished buttons', 'Embroidered Dial emblem', 'Regular fit, longer back hem'],
    image: 'product-nocturne-black',
    imageAlt: 'The Nocturne polo in black, three-quarter front view.',
  },
  {
    id: 'nocturne-ivory',
    name: 'Nocturne Polo',
    colorway: 'Ivory',
    price: 185,
    line: 'Short-sleeve piqué polo',
    description:
      'The same pattern as the black Nocturne in an undyed ivory piqué, with black tipping, black thread and pale buttons.',
    details: ['Cotton piqué, mid-weight', 'Black collar tipping', 'Pale dished buttons', 'Black Dial emblem', 'Regular fit, longer back hem'],
    image: 'product-nocturne-ivory',
    imageAlt: 'The Nocturne polo in ivory, three-quarter front view.',
  },
  {
    id: 'vesper-slate',
    name: 'Vesper Long-Sleeve Polo',
    colorway: 'Slate',
    price: 210,
    line: 'Long-sleeve piqué polo',
    description:
      'A long-sleeve polo in cool slate piqué, with rib cuffs, a silver-grey Dial and dark buttons. Made for the colder hours.',
    details: ['Cotton piqué, mid-weight', 'Rib cuffs', 'Silver-grey Dial emblem', 'Two dark dished buttons', 'Regular fit'],
    image: 'product-vesper-slate',
    imageAlt: 'The Vesper long-sleeve polo in slate grey, three-quarter front view.',
  },
  {
    id: 'hour-tee',
    name: 'Hour Tee',
    colorway: 'Black',
    price: 95,
    line: 'Crew-neck piqué tee',
    description:
      'The Nocturne body without a collar: a crew-neck tee in black piqué with a narrow rib neckband and the bronze Dial.',
    details: ['Cotton piqué, mid-weight', 'Narrow rib neckband', 'Embroidered Dial emblem', 'Regular fit, longer back hem'],
    image: 'product-hour-tee',
    imageAlt: 'The Hour crew-neck tee in black, three-quarter front view.',
  },
];

export const productById = (id: string) => PRODUCTS.find((p) => p.id === id);

export const formatPrice = (value: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);

/** Responsive image sources for a render (see scripts/render-stills.mjs). */
export function renderSrc(name: string, kind: 'landscape' | 'portrait') {
  const base = `${import.meta.env.BASE_URL}renders/${name}`;
  const [large, small] = kind === 'landscape' ? [1600, 800] : [1000, 500];
  return {
    src: `${base}-${large}.webp`,
    srcSet: `${base}-${small}.webp ${small}w, ${base}-${large}.webp ${large}w`,
    width: large,
    height: kind === 'landscape' ? 1000 : 1250,
  };
}
