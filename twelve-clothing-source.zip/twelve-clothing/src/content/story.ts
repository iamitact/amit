import type { AnchorName } from '../three/garment';

/**
 * The scroll narrative. `at` is the progress (0–1) through the pinned story
 * where a chapter is fully visible; `span` is how long it stays. The same
 * values place the in-story anchor targets used by the navigation.
 */
export type ChapterLayout = 'hero' | 'left' | 'right' | 'finale';

export interface Chapter {
  id: string;
  at: number;
  span: number;
  layout: ChapterLayout;
  kicker: string;
  title: string;
  body?: string;
  still: string;
  stillAlt: string;
}

export const CHAPTERS: Chapter[] = [
  {
    id: 'reveal',
    at: 0,
    span: 0.07,
    layout: 'hero',
    kicker: 'Collection XII',
    title: 'Nocturne',
    body: 'Dressed for the twelfth hour.',
    still: 'story-hero',
    stillAlt: 'The Nocturne black piqué polo floating under a single overhead spotlight, with low grey smoke beneath it.',
  },
  {
    id: 'silhouette',
    at: 0.19,
    span: 0.06,
    layout: 'left',
    kicker: 'I — Silhouette',
    title: 'A line drawn close to the body.',
    body: 'Set-in shoulders, a quietly tapered waist and a hem cut a little longer at the back. Nothing oversized. Nothing tight.',
    still: 'story-silhouette',
    stillAlt: 'Three-quarter view of the polo showing its tapered side profile.',
  },
  {
    id: 'construction',
    at: 0.385,
    span: 0.08,
    layout: 'left',
    kicker: 'II — Construction',
    title: 'Twelve pieces. One quiet object.',
    body: 'Body panels, collar, neck tape, placket, buttons, emblem, sleeves, cuffs and hem are cut and finished apart, then joined with flat tonal seams.',
    still: 'story-exploded',
    stillAlt: 'Exploded view of the polo: collar, placket, buttons, emblem, sleeves, cuffs, hem band and body panels separated in space.',
  },
  {
    id: 'collar',
    at: 0.535,
    span: 0.035,
    layout: 'right',
    kicker: 'III — Collar',
    title: 'Knit to shape, never cut.',
    body: 'A fully fashioned rib collar with two fine tonal tipping lines, set on a stand so it frames the face without wilting.',
    still: 'detail-collar',
    stillAlt: 'Close-up of the ribbed polo collar with two fine tonal tipping lines.',
  },
  {
    id: 'buttons',
    at: 0.615,
    span: 0.035,
    layout: 'left',
    kicker: 'IV — Placket',
    title: 'Two buttons. Cross-stitched.',
    body: 'Dished, low-shine buttons on a box-stitched placket. Tonal thread on black, only visible when the light rakes across it.',
    still: 'detail-buttons',
    stillAlt: 'Close-up of the placket with two dark dished buttons and box stitching.',
  },
  {
    id: 'emblem',
    at: 0.695,
    span: 0.035,
    layout: 'right',
    kicker: 'V — The Dial',
    title: 'Twelve marks. No letters.',
    body: 'Our emblem is a raised ring of twelve embroidered marks in dark bronze thread — the only signature the garment carries.',
    still: 'detail-emblem',
    stillAlt: 'Macro of the embroidered emblem: a ring of twelve raised bronze marks on black piqué.',
  },
  {
    id: 'hem',
    at: 0.775,
    span: 0.035,
    layout: 'left',
    kicker: 'VI — Piqué',
    title: 'A honeycomb knit that holds the dark.',
    body: 'Cotton piqué, a textured weave that breathes and throws tiny shadows, finished with a rib hem band and a single line of stitching.',
    still: 'detail-hem',
    stillAlt: 'Close-up of the hem band, its line of stitching and the textured piqué above it.',
  },
  {
    id: 'finale',
    at: 0.9,
    span: 0.1,
    layout: 'finale',
    kicker: 'Nocturne Polo',
    title: 'Nothing loud. Everything considered.',
    still: 'story-hero',
    stillAlt: 'The Nocturne polo, complete, under the spotlight.',
  },
];

/** Anchor links into the pinned story (progress positions). */
export const STORY_ANCHORS: { id: string; at: number }[] = [
  { id: 'silhouette', at: 0.19 },
  { id: 'construction', at: 0.385 },
  { id: 'details', at: 0.535 },
];

/** Callouts shown while the garment is deconstructed. */
export const CALLOUTS: { anchor: AnchorName; label: string; mobile: boolean }[] = [
  { anchor: 'collar', label: 'Rib collar, tonal tipping', mobile: true },
  { anchor: 'placket', label: 'Box-stitched placket', mobile: false },
  { anchor: 'buttons', label: 'Two dished buttons', mobile: true },
  { anchor: 'emblem', label: 'The Dial emblem', mobile: true },
  { anchor: 'sleeve', label: 'Set-in sleeve, turned cuff', mobile: false },
  { anchor: 'back', label: 'Back panel, cut longer', mobile: false },
  { anchor: 'hem', label: 'Hem band, single stitch', mobile: true },
];

export const CALLOUT_WINDOW: [number, number] = [0.33, 0.44];
