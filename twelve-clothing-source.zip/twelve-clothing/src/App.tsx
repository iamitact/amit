import { lazy, Suspense, useCallback, useState } from 'react';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { hasWebGL, useMotion } from './hooks/useMotion';
import type { PageDef } from './site/pages';
import { CartProvider } from './state/cart';

// each page is its own chunk: a visitor to /contact/ never downloads the 3D code
const Home = lazy(() => import('./pages/Home'));
const Shop = lazy(() => import('./pages/Shop'));
const ProductPage = lazy(() => import('./pages/Product'));
const StoryPage = lazy(() => import('./pages/StoryPage'));
const Lookbook = lazy(() => import('./pages/Lookbook'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const Bag = lazy(() => import('./pages/Bag'));
const NotFound = lazy(() => import('./pages/NotFound'));

export default function App({ page }: { page: PageDef }) {
  const { reduced, choice, setChoice } = useMotion();
  const [webglFailed, setWebglFailed] = useState(false);
  const webgl = hasWebGL() && !webglFailed;
  const live = webgl && !reduced;
  const onWebGLFail = useCallback(() => setWebglFailed(true), []);
  const enableMotion = webgl && reduced ? () => setChoice('full') : undefined;

  let content;
  switch (page.route) {
    case 'home':
      content = <Home live={live} onWebGLFail={onWebGLFail} />;
      break;
    case 'shop':
      content = <Shop />;
      break;
    case 'product':
      content = <ProductPage slug={page.slug} />;
      break;
    case 'story':
      content = <StoryPage live={live} onWebGLFail={onWebGLFail} onEnableMotion={enableMotion} />;
      break;
    case 'lookbook':
      content = <Lookbook />;
      break;
    case 'about':
      content = <About />;
      break;
    case 'contact':
      content = <Contact />;
      break;
    case 'bag':
      content = <Bag />;
      break;
    default:
      content = <NotFound />;
  }

  return (
    <CartProvider>
      <Header route={page.route} overlay={page.route === 'home' || page.route === 'story'} />
      <main id="main" tabIndex={-1} className="page-enter outline-none">
        <Suspense fallback={<div className="min-h-svh" aria-busy="true" />}>{content}</Suspense>
      </main>
      <Footer motion={choice} onMotion={setChoice} webgl={webgl} />
      <CartDrawer />
    </CartProvider>
  );
}
