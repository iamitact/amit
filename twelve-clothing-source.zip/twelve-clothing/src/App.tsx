import { useCallback, useState } from 'react';
import { Campaign } from './components/Campaign';
import { CartDrawer } from './components/CartDrawer';
import { Collection } from './components/Collection';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { House, Letters } from './components/House';
import { ProductDialog } from './components/ProductDialog';
import { Reserve } from './components/Reserve';
import { Story } from './components/Story';
import { hasWebGL, useMotion } from './hooks/useMotion';
import { CartProvider } from './state/cart';

export default function App() {
  const { reduced, choice, setChoice } = useMotion();
  const [webglFailed, setWebglFailed] = useState(false);
  const [productId, setProductId] = useState<string | null>(null);
  const webgl = hasWebGL() && !webglFailed;
  const mode = webgl && !reduced ? 'live' : 'still';

  const onWebGLFail = useCallback(() => setWebglFailed(true), []);
  const closeProduct = useCallback(() => setProductId(null), []);

  return (
    <CartProvider>
      <div id="top" />
      <Header />
      <main>
        <Story
          key={mode}
          mode={mode}
          onWebGLFail={onWebGLFail}
          onEnableMotion={webgl && reduced ? () => setChoice('full') : undefined}
        />
        <Campaign onOpenProduct={setProductId} />
        <Collection onOpenProduct={setProductId} />
        <Reserve />
        <House />
        <Letters />
      </main>
      <Footer motion={choice} onMotion={setChoice} webgl={webgl} />
      <ProductDialog productId={productId} onClose={closeProduct} />
      <CartDrawer />
    </CartProvider>
  );
}
