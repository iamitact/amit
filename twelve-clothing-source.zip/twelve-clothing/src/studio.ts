/**
 * Development-only still renderer (studio.html is not part of the production build).
 * Renders one garment variant from one named shot so `npm run render:stills`
 * can capture the fallback, lookbook and product images from the real 3D model.
 *
 *   /studio.html?variant=nocturne-black&shot=hero&w=1600&h=1000&explode=0
 */
import { Stage, type ShotName } from './three/stage';
import { VARIANTS, DEFAULT_VARIANT } from './three/variants';

declare global {
  interface Window {
    __ready?: boolean;
    __capture?: (widths: number[]) => string[];
  }
}

const q = new URLSearchParams(location.search);
const variant = VARIANTS[q.get('variant') ?? DEFAULT_VARIANT] ?? VARIANTS[DEFAULT_VARIANT];
const shot = (q.get('shot') ?? 'hero') as ShotName;
const w = Number(q.get('w') ?? 1600);
const h = Number(q.get('h') ?? 1000);
const explode = Number(q.get('explode') ?? (shot === 'exploded' ? 1 : 0));
const time = Number(q.get('t') ?? 2.2);

const stage = new Stage({ variant, quality: 'high', preserveDrawingBuffer: true, pixelRatio: 1 });
const host = document.getElementById('stage')!;
host.appendChild(stage.renderer.domElement);
stage.setSize(w, h);
stage.renderer.domElement.style.width = `${w}px`;
stage.renderer.domElement.style.height = `${h}px`;
const shots = stage.computeShots();
const rig = { ...shots[shot] };
if (q.has('rotY')) rig.rotY = Number(q.get('rotY'));
for (let i = 0; i < 3; i++) {
  stage.apply(rig, explode, time);
  stage.render();
}

window.__capture = (widths) =>
  widths.map((wd) => {
    const c = document.createElement('canvas');
    c.width = wd;
    c.height = Math.round((wd * h) / w);
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(stage.renderer.domElement, 0, 0, c.width, c.height);
    return c.toDataURL('image/webp', 0.86);
  });
window.__ready = true;
