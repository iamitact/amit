import { matchPath, type PageDef } from './pages';

/**
 * The site root as a URL path: '/amit/' on GitHub Pages, '/' in development.
 *
 * Each generated page carries <meta name="twelve-root" content="../../"> — its
 * relative distance to the root — so the same build works under any repository
 * name or custom domain. The 404 page, which GitHub serves at arbitrary depths,
 * carries an absolute root in <html data-root="/amit/"> instead.
 */
let cachedRoot: string | null = null;
export function siteRoot(): string {
  if (cachedRoot) return cachedRoot;
  const meta = document.querySelector<HTMLMetaElement>('meta[name="twelve-root"]');
  if (document.documentElement.dataset.root) cachedRoot = document.documentElement.dataset.root;
  else if (meta) cachedRoot = new URL(meta.content, location.href).pathname;
  else cachedRoot = import.meta.env.BASE_URL.startsWith('/') ? import.meta.env.BASE_URL : '/';
  if (!cachedRoot.endsWith('/')) cachedRoot += '/';
  return cachedRoot;
}

/** Link to a page: href('shop/') → '/amit/shop/'. */
export const href = (path = '') => siteRoot() + path;

/** URL of a file in public/: publicUrl('renders/x.webp'). */
export const publicUrl = (path: string) => siteRoot() + path;

/** The page for the current URL. */
export function currentPage(): PageDef {
  if (document.documentElement.dataset.page === '404') return matchPath('__not-found__/');
  const root = siteRoot();
  const path = location.pathname.startsWith(root) ? location.pathname.slice(root.length) : location.pathname;
  return matchPath(decodeURIComponent(path));
}
