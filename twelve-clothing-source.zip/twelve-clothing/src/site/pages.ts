/**
 * The page map. Pure data (no DOM), so it is shared by the browser router and
 * by the build step in vite.config.ts that writes one static index.html per
 * page — which is what makes deep links load and refresh on GitHub Pages.
 */
import catalog from '../data/catalog.json';

export type RouteName = 'home' | 'shop' | 'product' | 'story' | 'lookbook' | 'about' | 'contact' | 'bag' | 'notfound';

export interface PageDef {
  /** Path relative to the site root: '' for home, otherwise always ending in '/'. */
  path: string;
  route: RouteName;
  slug?: string;
  title: string;
  description: string;
}

const BRAND = 'Twelve Clothing';

export function allPages(): PageDef[] {
  const pages: PageDef[] = [
    {
      path: '',
      route: 'home',
      title: `${BRAND} — Dressed for the twelfth hour`,
      description: 'Twelve Clothing: black clothing, cut close and finished quietly. Shop the collection and explore the story.',
    },
    { path: 'shop/', route: 'shop', title: `Shop — ${BRAND}`, description: 'Browse the Twelve Clothing collection by category and colour.' },
    {
      path: 'story/',
      route: 'story',
      title: `The Story — ${BRAND}`,
      description: 'An interactive 3D study of how a Twelve polo is built, from silhouette to stitch.',
    },
    { path: 'lookbook/', route: 'lookbook', title: `Lookbook — ${BRAND}`, description: 'The Twelve Clothing lookbook.' },
    { path: 'about/', route: 'about', title: `About the Store — ${BRAND}`, description: 'About Twelve Clothing and our shop.' },
    { path: 'contact/', route: 'contact', title: `Contact & Visit — ${BRAND}`, description: 'How to reach and visit Twelve Clothing.' },
    { path: 'bag/', route: 'bag', title: `Your Bag — ${BRAND}`, description: 'Your Twelve Clothing bag.' },
  ];
  for (const p of catalog.products) {
    pages.push({
      path: `shop/${p.slug}/`,
      route: 'product',
      slug: p.slug,
      title: `${p.name}, ${p.colour} — ${BRAND}`,
      description: p.summary,
    });
  }
  return pages;
}

/** Resolves a root-relative path ('shop/x/') to a page, or the not-found page. */
export function matchPath(rel: string): PageDef {
  const clean = rel.replace(/index\.html$/, '').replace(/^\/+/, '');
  const normalised = clean === '' || clean.endsWith('/') ? clean : `${clean}/`;
  return (
    allPages().find((p) => p.path === normalised) ?? {
      path: normalised,
      route: 'notfound',
      title: `Page not found — ${BRAND}`,
      description: 'This page does not exist.',
    }
  );
}
