import catalogJson from '../data/catalog.json';
import businessJson from '../data/business.json';
import commerceJson from '../data/commerce.json';
import photosJson from '../data/photos.json';
import { publicUrl } from './paths';

export type Availability = 'in_stock' | 'made_to_order' | 'sold_out' | 'pending';

export interface Product {
  slug: string;
  sku: string | null;
  sample: boolean;
  name: string;
  colour: string;
  category: string;
  price: number | null;
  sizes: string[];
  sizesConfirmed: boolean;
  availability: Availability | string;
  summary: string;
  details: string[];
  images: { front: string; back: string | null; details: string[] };
}

export interface SizeGuide {
  unit: string;
  columns: string[];
  rows: { size: string; values: (string | number)[] }[];
  note?: string;
}

export const catalog = catalogJson as unknown as {
  currency: string | null;
  categories: { id: string; label: string }[];
  products: Product[];
  sizeGuide: SizeGuide | null;
};
export interface Business {
  legalName: string | null;
  tagline: string;
  story: string | null;
  foundedYear: number | null;
  address: { line1: string | null; line2: string | null; city: string | null; postcode: string | null; country: string | null };
  mapUrl: string | null;
  hours: string | null;
  phone: string | null;
  email: string | null;
  whatsapp: string | null;
  social: Record<string, string | null>;
  shippingPolicy: string | null;
  returnsPolicy: string | null;
}
export const business = businessJson as unknown as Business;
export const commerce = commerceJson as { provider: string | null; apiBase: string | null; status: string };

export const products = catalog.products;
export const productBySlug = (slug: string | undefined) => products.find((p) => p.slug === slug);
export const categoryLabel = (id: string) => catalog.categories.find((c) => c.id === id)?.label ?? id;
export const isSampleCatalogue = products.some((p) => p.sample);

/** Formatted price, or null while the price or the currency is still pending. */
export function formatPrice(value: number | null) {
  if (value === null || !catalog.currency) return null;
  return new Intl.NumberFormat('en', { style: 'currency', currency: catalog.currency, maximumFractionDigits: 0 }).format(value);
}
export const priceLabel = (value: number | null) => formatPrice(value) ?? 'Price to be confirmed';

export const availabilityLabel: Record<string, string> = {
  in_stock: 'In stock',
  made_to_order: 'Made to order',
  sold_out: 'Sold out',
  pending: 'Availability to be confirmed',
};

// ------------------------------------------------------------------- images

export interface ImageSource {
  src: string;
  srcSet: string;
  sources: { type: string; srcSet: string }[];
  width: number;
  height: number;
  /** true for a 3D concept render — never a photograph of a product the client sells */
  concept: boolean;
}

type PhotoEntry = { widths: number[]; width: number; height: number; formats: string[]; alt?: string };
const photoIndex = photosJson.images as Record<string, PhotoEntry>;

/**
 * Resolves an image reference:
 *   'render:<name>' → 3D concept still in public/renders (always captioned as a render)
 *   'photo:<id>'    → a client photograph processed by `npm run photos`
 */
export function imageSource(ref: string | null | undefined): ImageSource | null {
  if (!ref) return null;
  if (ref.startsWith('render:')) {
    const name = ref.slice(7);
    const portrait = name.startsWith('product-') || name.startsWith('look-');
    const [large, small] = portrait ? [1000, 500] : [1600, 800];
    const base = publicUrl(`renders/${name}`);
    return {
      src: `${base}-${large}.webp`,
      srcSet: `${base}-${small}.webp ${small}w, ${base}-${large}.webp ${large}w`,
      sources: [],
      width: large,
      height: portrait ? 1250 : 1000,
      concept: true,
    };
  }
  if (ref.startsWith('photo:')) {
    const id = ref.slice(6);
    const p = photoIndex[id];
    if (!p) return null;
    const set = (ext: string) => p.widths.map((w) => `${publicUrl(`photos/${id}-${w}.${ext}`)} ${w}w`).join(', ');
    const fallback = p.formats.includes('jpg') ? 'jpg' : p.formats[p.formats.length - 1];
    return {
      src: publicUrl(`photos/${id}-${p.widths[p.widths.length - 1]}.${fallback}`),
      srcSet: set(fallback),
      sources: p.formats.filter((f) => f !== fallback).map((f) => ({ type: `image/${f}`, srcSet: set(f) })),
      width: p.width,
      height: p.height,
      concept: false,
    };
  }
  return null;
}

export const photoSlots = photosJson.slots as Record<string, { image: string | null; concept: string | null; need: string }>;
export const photoAlt = (ref: string) => (ref.startsWith('photo:') ? photoIndex[ref.slice(6)]?.alt : undefined);
