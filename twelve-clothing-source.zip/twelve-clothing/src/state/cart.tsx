import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { productById, SIZES, type Size } from '../content/products';

export interface CartLine {
  key: string;
  productId: string;
  size: Size;
  qty: number;
}

interface CartContextValue {
  lines: CartLine[];
  count: number;
  subtotal: number;
  isOpen: boolean;
  open: () => void;
  close: () => void;
  add: (productId: string, size: Size) => void;
  setQty: (key: string, qty: number) => void;
  remove: (key: string) => void;
  clear: () => void;
}

const STORAGE_KEY = 'twelve-cart-v1';
const MAX_QTY = 9;
const CartContext = createContext<CartContextValue | null>(null);

/** Reads the saved cart, dropping anything that no longer matches the catalogue. */
function load(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((l) => {
      if (!l || typeof l !== 'object') return [];
      const { productId, size, qty } = l as Record<string, unknown>;
      if (typeof productId !== 'string' || !productById(productId)) return [];
      if (typeof size !== 'string' || !(SIZES as readonly string[]).includes(size)) return [];
      const q = typeof qty === 'number' ? Math.min(MAX_QTY, Math.max(1, Math.round(qty))) : 1;
      return [{ key: `${productId}:${size}`, productId, size: size as Size, qty: q }];
    });
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(load);
  const [isOpen, setOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* storage unavailable (private mode) — the cart still works for this visit */
    }
  }, [lines]);

  // keep multiple tabs in sync
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setLines(load());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const add = useCallback((productId: string, size: Size) => {
    setLines((prev) => {
      const key = `${productId}:${size}`;
      const existing = prev.find((l) => l.key === key);
      if (existing) return prev.map((l) => (l.key === key ? { ...l, qty: Math.min(MAX_QTY, l.qty + 1) } : l));
      return [...prev, { key, productId, size, qty: 1 }];
    });
  }, []);
  const setQty = useCallback((key: string, qty: number) => {
    setLines((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty: Math.min(MAX_QTY, qty) } : l)),
    );
  }, []);
  const remove = useCallback((key: string) => setLines((prev) => prev.filter((l) => l.key !== key)), []);
  const clear = useCallback(() => setLines([]), []);
  const open = useCallback(() => setOpen(true), []);
  const close = useCallback(() => setOpen(false), []);

  const value = useMemo<CartContextValue>(() => {
    const count = lines.reduce((n, l) => n + l.qty, 0);
    const subtotal = lines.reduce((n, l) => n + (productById(l.productId)?.price ?? 0) * l.qty, 0);
    return { lines, count, subtotal, isOpen, open, close, add, setQty, remove, clear };
  }, [lines, isOpen, open, close, add, setQty, remove, clear]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
