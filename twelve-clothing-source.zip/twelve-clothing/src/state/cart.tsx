import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { productBySlug } from '../site/catalog';

export interface CartLine {
  key: string;
  slug: string;
  size: string;
  qty: number;
}

interface CartContextValue {
  lines: CartLine[];
  count: number;
  /** Sum of known prices, or null if any line's price is still pending. */
  subtotal: number | null;
  isOpen: boolean;
  open: () => void;
  close: () => void;
  add: (slug: string, size: string) => void;
  setQty: (key: string, qty: number) => void;
  remove: (key: string) => void;
  clear: () => void;
}

// v2: lines are keyed by product slug (v1 used demo product ids, which no longer exist)
const STORAGE_KEY = 'twelve-cart-v2';
const MAX_QTY = 9;
const CartContext = createContext<CartContextValue | null>(null);

/** Reads the saved bag, dropping anything that no longer matches the catalogue. */
function load(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((l) => {
      if (!l || typeof l !== 'object') return [];
      const { slug, size, qty } = l as Record<string, unknown>;
      const product = typeof slug === 'string' ? productBySlug(slug) : undefined;
      if (!product || typeof size !== 'string' || !product.sizes.includes(size)) return [];
      const q = typeof qty === 'number' ? Math.min(MAX_QTY, Math.max(1, Math.round(qty))) : 1;
      return [{ key: `${product.slug}:${size}`, slug: product.slug, size, qty: q }];
    });
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(load);
  const [isOpen, setOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* storage unavailable (private mode): the bag still works for this page */
    }
  }, [lines]);

  // keep tabs and pages in sync
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setLines(load());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const add = useCallback((slug: string, size: string) => {
    setLines((prev) => {
      const key = `${slug}:${size}`;
      if (prev.some((l) => l.key === key)) return prev.map((l) => (l.key === key ? { ...l, qty: Math.min(MAX_QTY, l.qty + 1) } : l));
      return [...prev, { key, slug, size, qty: 1 }];
    });
  }, []);
  const setQty = useCallback((key: string, qty: number) => {
    setLines((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty: Math.min(MAX_QTY, qty) } : l)),
    );
  }, []);
  const remove = useCallback((key: string) => setLines((prev) => prev.filter((l) => l.key !== key)), []);
  const clear = useCallback(() => setLines([]), []);
  const open = useCallback(() => setOpen(true), []);
  const close = useCallback(() => setOpen(false), []);

  const value = useMemo<CartContextValue>(() => {
    const count = lines.reduce((n, l) => n + l.qty, 0);
    let subtotal: number | null = 0;
    for (const l of lines) {
      const price = productBySlug(l.slug)?.price ?? null;
      subtotal = price === null || subtotal === null ? null : subtotal + price * l.qty;
    }
    return { lines, count, subtotal, isOpen, open, close, add, setQty, remove, clear };
  }, [lines, isOpen, open, close, add, setQty, remove, clear]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
