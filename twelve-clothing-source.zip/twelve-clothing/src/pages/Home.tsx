import { useEffect, useRef, useState } from 'react';
import { ArrowRightIcon } from '../components/Icons';
import { Mist } from '../components/Mist';
import { Fact, PreviewNotice } from '../components/Pending';
import { Photo } from '../components/Photo';
import { ProductCard } from '../components/ProductCard';
import { Reveal } from '../components/Reveal';
import { business, imageSource, isSampleCatalogue, products } from '../site/catalog';
import { href } from '../site/paths';

export default function Home({ live, onWebGLFail }: { live: boolean; onWebGLFail: () => void }) {
  const featured = products.slice(0, 3);
  return (
    <>
      <HomeHero live={live} onFail={onWebGLFail} />

      <section aria-labelledby="featured-title" className="px-4 py-24 sm:px-8 md:py-32">
        <div className="mx-auto max-w-[1500px]">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="label text-gold">The collection</p>
              <h2 id="featured-title" className="display mt-5 text-[clamp(2.8rem,5.4vw,5.2rem)]">
                Cut close. <em className="font-normal italic text-ivory/75">Finished quietly.</em>
              </h2>
            </div>
            <a href={href('shop/')} className="btn-ghost">
              View the shop <ArrowRightIcon size={16} />
            </a>
          </Reveal>
          {isSampleCatalogue && (
            <div className="mt-8 max-w-2xl">
              <PreviewNotice>These pieces are 3D concept renders standing in for the real range. Product photographs, names and prices will replace them.</PreviewNotice>
            </div>
          )}
          <div className="mt-12 grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="campaign-title" className="relative">
        <Photo slot="home.campaign" alt="Twelve Clothing campaign photograph" ratio="16 / 9" sizes="100vw" parallax captionPosition="top-right" className="max-h-[88svh] w-full" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
        <Reveal className="absolute inset-x-0 bottom-0 mx-auto max-w-[1500px] px-4 pb-10 sm:px-8 md:pb-16">
          <p className="label text-gold">After hours</p>
          <h2 id="campaign-title" className="display mt-4 max-w-[16ch] text-[clamp(2.6rem,6vw,6rem)]">
            Black, in <em className="font-normal italic text-ivory/75">every</em> light.
          </h2>
          <a href={href('lookbook/')} className="btn-ghost pointer-events-auto mt-7 bg-ink/40 backdrop-blur-sm">
            See the lookbook
          </a>
        </Reveal>
      </section>

      <StoryTeaser />

      <section aria-labelledby="visit-title" className="border-t border-line px-4 py-24 sm:px-8 md:py-32">
        <div className="mx-auto grid max-w-[1500px] items-end gap-10 md:grid-cols-2">
          <Reveal>
            <p className="label text-gold">Visit</p>
            <h2 id="visit-title" className="display mt-5 text-[clamp(2.6rem,4.8vw,4.6rem)]">
              Try it on in the shop.
            </h2>
          </Reveal>
          <Reveal delay={120} className="space-y-3 text-muted">
            <p>
              <Fact value={business.address.line1} pending="Shop address to be confirmed by the client" />
            </p>
            <p>
              <Fact value={business.hours} pending="Opening hours to be confirmed" />
            </p>
            <a href={href('contact/')} className="btn-ghost mt-4">
              Contact &amp; directions
            </a>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function HomeHero({ live, onFail }: { live: boolean; onFail: () => void }) {
  const host = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const poster = imageSource('render:story-hero')!;

  useEffect(() => {
    if (!live) return;
    let dispose: (() => void) | undefined;
    let cancelled = false;
    import('../three/hero')
      .then(({ mountHero }) => {
        if (!cancelled && host.current) dispose = mountHero({ host: host.current, onReady: () => setReady(true), onFail });
      })
      .catch(onFail);
    return () => {
      cancelled = true;
      dispose?.();
    };
  }, [live, onFail]);

  return (
    <section aria-labelledby="home-title" className="relative flex h-svh min-h-[36rem] flex-col justify-between overflow-hidden pb-[7svh] pt-[16svh]">
      <img
        src={poster.src}
        srcSet={poster.srcSet}
        sizes="100vw"
        width={poster.width}
        height={poster.height}
        alt=""
        aria-hidden
        fetchPriority="high"
        className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${live && ready ? 'opacity-0' : 'opacity-100'}`}
      />
      {live && <div ref={host} className="pointer-events-none absolute inset-0" />}
      {!live && <Mist />}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-ink via-ink/40 to-transparent" />

      <div className="relative px-6 text-center">
        <p className="label text-smoke">Twelve Clothing</p>
        <h1 id="home-title" className="display mx-auto mt-5 max-w-[14ch] text-[clamp(3.4rem,9.5vw,9rem)] text-ivory [text-shadow:0_2px_40px_rgba(0,0,0,0.6)]">
          Dressed for the twelfth hour.
        </h1>
      </div>
      <div className="relative flex flex-col items-center gap-5 px-6 text-center">
        <div className="flex flex-wrap justify-center gap-3">
          <a href={href('shop/')} className="btn-gold">
            Shop the collection
          </a>
          <a href={href('story/')} className="btn-ghost bg-ink/30 backdrop-blur-sm">
            Watch the story
          </a>
        </div>
        <p className="label text-[0.5625rem] text-smoke">3D concept study · not a product photograph</p>
      </div>
    </section>
  );
}

function StoryTeaser() {
  return (
    <section aria-labelledby="story-teaser-title" className="px-4 py-24 sm:px-8 md:py-36">
      <div className="mx-auto grid max-w-[1500px] items-center gap-12 lg:grid-cols-12">
        <Reveal variant="image" className="lg:col-span-7">
          <Photo src="render:story-exploded" alt="The concept polo separated into its twelve pieces" ratio="16 / 10" sizes="(min-width: 1024px) 58vw, 100vw" parallax />
        </Reveal>
        <Reveal delay={120} className="lg:col-span-4 lg:col-start-9">
          <p className="label text-gold">The story</p>
          <h2 id="story-teaser-title" className="display mt-5 text-[clamp(2.6rem,4.6vw,4.4rem)]">
            Twelve pieces. One quiet object.
          </h2>
          <p className="mt-5 text-muted">Scroll through a 3D study of how a Twelve polo is put together — from silhouette to the last stitch.</p>
          <a href={href('story/')} className="btn-gold mt-8">
            Watch the story <ArrowRightIcon size={16} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
