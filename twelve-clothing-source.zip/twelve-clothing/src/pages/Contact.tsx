import { useState, type FormEvent } from 'react';
import { Fact } from '../components/Pending';
import { Photo } from '../components/Photo';
import { Reveal } from '../components/Reveal';
import { business } from '../site/catalog';

export default function Contact() {
  const a = business.address;
  const addressLines = [a.line1, a.line2, [a.postcode, a.city].filter(Boolean).join(' '), a.country].filter(Boolean) as string[];
  const social = Object.entries(business.social).filter((e): e is [string, string] => !!e[1]);

  return (
    <div className="px-4 pb-24 pt-32 sm:px-8 md:pt-40">
      <div className="mx-auto max-w-[1500px]">
        <Reveal>
          <p className="label text-gold">Contact &amp; visit</p>
          <h1 className="display mt-6 text-[clamp(3.2rem,7vw,7rem)]">Come by, or write.</h1>
        </Reveal>

        <div className="mt-16 grid gap-14 lg:grid-cols-12">
          <div className="grid content-start gap-10 sm:grid-cols-2 lg:col-span-6">
            <section aria-labelledby="address-title">
              <h2 id="address-title" className="label text-[0.625rem] text-smoke">
                Address
              </h2>
              <address className="mt-3 not-italic leading-relaxed">
                {addressLines.length ? addressLines.map((l) => <div key={l}>{l}</div>) : <Fact value={null} pending="Address to be confirmed by the client" />}
              </address>
              {business.mapUrl && (
                <a href={business.mapUrl} className="label link-line mt-4 inline-block py-2 text-[0.625rem] text-gold" rel="noopener">
                  Open in maps
                </a>
              )}
            </section>
            <section aria-labelledby="hours-title">
              <h2 id="hours-title" className="label text-[0.625rem] text-smoke">
                Opening hours
              </h2>
              <p className="mt-3 whitespace-pre-line leading-relaxed">
                <Fact value={business.hours} pending="Hours to be confirmed" />
              </p>
            </section>
            <section aria-labelledby="reach-title">
              <h2 id="reach-title" className="label text-[0.625rem] text-smoke">
                Phone &amp; email
              </h2>
              <div className="mt-3 space-y-2">
                <p>
                  {business.phone ? (
                    <a className="link-line" href={`tel:${business.phone}`}>
                      {business.phone}
                    </a>
                  ) : (
                    <Fact value={null} pending="Phone to be confirmed" />
                  )}
                </p>
                <p>
                  {business.email ? (
                    <a className="link-line" href={`mailto:${business.email}`}>
                      {business.email}
                    </a>
                  ) : (
                    <Fact value={null} pending="Email to be confirmed" />
                  )}
                </p>
                {business.whatsapp && (
                  <p>
                    <a className="link-line" href={`https://wa.me/${business.whatsapp.replace(/\D/g, '')}`} rel="noopener">
                      WhatsApp
                    </a>
                  </p>
                )}
              </div>
            </section>
            <section aria-labelledby="social-title">
              <h2 id="social-title" className="label text-[0.625rem] text-smoke">
                Social
              </h2>
              <div className="mt-3 flex flex-col gap-2">
                {social.length ? (
                  social.map(([name, url]) => (
                    <a key={name} className="link-line capitalize" href={url} rel="noopener">
                      {name}
                    </a>
                  ))
                ) : (
                  <Fact value={null} pending="Social links to be confirmed" />
                )}
              </div>
            </section>
          </div>
          <Reveal variant="image" className="lg:col-span-5 lg:col-start-8">
            <Photo slot="contact.storefront" alt="The Twelve Clothing storefront" ratio="4 / 5" sizes="(min-width: 1024px) 40vw, 100vw" />
          </Reveal>
        </div>

        <Letters />
      </div>
    </div>
  );
}

type Status = { kind: 'idle' } | { kind: 'error'; msg: string } | { kind: 'demo'; email: string };

/** Newsletter form. No mailing service is connected, and it says so. */
function Letters() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>({ kind: 'idle' });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const v = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
      setStatus({ kind: 'error', msg: 'Enter an email address like name@example.com.' });
      return;
    }
    setStatus({ kind: 'demo', email: v });
  };
  return (
    <section aria-labelledby="letters-title" className="mt-28 grid gap-10 border-t border-line pt-16 lg:grid-cols-12">
      <div className="lg:col-span-5">
        <h2 id="letters-title" className="display text-[clamp(2.4rem,4vw,3.8rem)]">
          Letters
        </h2>
        <p className="mt-4 max-w-md text-muted">Occasional notes about new pieces — once a mailing service is connected.</p>
      </div>
      <form noValidate onSubmit={submit} className="lg:col-span-6 lg:col-start-7 lg:self-end">
        <label htmlFor="letters-email" className="label text-ivory">
          Email address
        </label>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          <input
            id="letters-email"
            type="email"
            autoComplete="email"
            inputMode="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (status.kind !== 'idle') setStatus({ kind: 'idle' });
            }}
            aria-invalid={status.kind === 'error' || undefined}
            aria-describedby="letters-status"
            placeholder="name@example.com"
            className="h-12 flex-1 border border-line-strong bg-transparent px-4 text-base text-ivory placeholder:text-smoke focus:border-gold focus:outline-none"
          />
          <button type="submit" className="btn-ghost">
            Sign up
          </button>
        </div>
        <p id="letters-status" role="status" className={`mt-4 min-h-12 text-sm ${status.kind === 'error' ? 'text-error' : 'text-muted'}`}>
          {status.kind === 'error' && status.msg}
          {status.kind === 'demo' && `No mailing service is connected yet, so ${status.email} was not sent anywhere or stored. Nobody has been subscribed.`}
          {status.kind === 'idle' && 'Not connected yet — nothing is sent until a mailing service is set up.'}
        </p>
      </form>
    </section>
  );
}
