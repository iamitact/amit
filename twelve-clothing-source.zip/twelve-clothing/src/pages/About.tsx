import { Dial } from '../components/Icons';
import { Fact, Pending } from '../components/Pending';
import { Photo } from '../components/Photo';
import { Reveal } from '../components/Reveal';
import { business } from '../site/catalog';
import { href } from '../site/paths';

export default function About() {
  return (
    <div className="pb-24 pt-32 md:pt-40">
      <section className="px-4 sm:px-8">
        <div className="mx-auto max-w-[1500px]">
          <Reveal>
            <p className="label text-gold">About the store</p>
            <h1 className="display mt-6 max-w-[16ch] text-[clamp(3.2rem,8vw,8rem)]">Made for the hour after everyone else has gone home.</h1>
          </Reveal>
        </div>
      </section>

      <section className="mt-16 px-4 sm:px-8 md:mt-24">
        <div className="mx-auto grid max-w-[1500px] gap-10 lg:grid-cols-12">
          <Reveal variant="image" className="lg:col-span-8">
            <Photo slot="about.interior" alt="Inside the Twelve Clothing shop" ratio="3 / 2" sizes="(min-width: 1024px) 64vw, 100vw" parallax eager />
          </Reveal>
          <Reveal variant="image" delay={120} className="lg:col-span-4 lg:mt-24">
            <Photo slot="about.exterior" alt="The Twelve Clothing shopfront" ratio="4 / 5" sizes="(min-width: 1024px) 30vw, 100vw" />
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="story-title" className="mt-24 px-4 sm:px-8 md:mt-32">
        <div className="mx-auto grid max-w-[1500px] gap-12 lg:grid-cols-12">
          <Reveal className="lg:col-span-5">
            <Dial size={40} className="text-gold" />
            <h2 id="story-title" className="display mt-8 text-[clamp(2.4rem,4vw,3.8rem)]">
              Our story
            </h2>
          </Reveal>
          <Reveal delay={120} className="space-y-5 text-muted lg:col-span-6 lg:col-start-7">
            {business.story ? (
              business.story.split('\n\n').map((p) => <p key={p.slice(0, 24)}>{p}</p>)
            ) : (
              <>
                <p className="text-ivory/85">
                  Twelve is a study in black: a short list of garments, each revised until nothing on it is decorative. Our only mark is the Dial —
                  twelve raised stitches in a ring.
                </p>
                <p className="text-sm">
                  <Pending>Draft brand copy — the client’s own story, founding details and team will replace this paragraph.</Pending>
                </p>
              </>
            )}
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="facts-title" className="mt-24 border-t border-line px-4 pt-16 sm:px-8">
        <div className="mx-auto max-w-[1500px]">
          <h2 id="facts-title" className="label text-gold">
            The shop
          </h2>
          <dl className="mt-8 grid gap-8 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="label text-[0.625rem] text-smoke">Business name</dt>
              <dd className="mt-2">
                <Fact value={business.legalName} />
              </dd>
            </div>
            <div>
              <dt className="label text-[0.625rem] text-smoke">Established</dt>
              <dd className="mt-2">
                <Fact value={business.foundedYear} />
              </dd>
            </div>
            <div>
              <dt className="label text-[0.625rem] text-smoke">Address</dt>
              <dd className="mt-2">
                <Fact value={business.address.line1} />
              </dd>
            </div>
            <div>
              <dt className="label text-[0.625rem] text-smoke">Hours</dt>
              <dd className="mt-2">
                <Fact value={business.hours} />
              </dd>
            </div>
          </dl>
          <a href={href('contact/')} className="btn-ghost mt-12">
            Contact &amp; visit
          </a>
        </div>
      </section>
    </div>
  );
}
