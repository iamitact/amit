import { Story } from '../components/Story';

/** The pinned 3D editorial story (or its still sequence). */
export default function StoryPage({ live, onWebGLFail, onEnableMotion }: { live: boolean; onWebGLFail: () => void; onEnableMotion?: () => void }) {
  return <Story key={live ? 'live' : 'still'} mode={live ? 'live' : 'still'} onWebGLFail={onWebGLFail} onEnableMotion={onEnableMotion} />;
}
