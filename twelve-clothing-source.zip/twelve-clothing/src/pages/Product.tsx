import { useState } from 'react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Gallery } from '../components/Gallery';
import { Fact, PreviewNotice } from '../components/Pending';
import { ProductCard } from '../components/ProductCard';
import { SizeGuide } from '../components/SizeGuide';
import { SizeSelector } from '../components/SizeSelector';
import { availabilityLabel, business, categoryLabel, priceLabel, productBySlug, products } from '../site/catalog';
import { href } from '../site/paths';
import { useCart } from '../state/cart';
import NotFound from './NotFound';

export default function ProductPage({ slug }: { slug?: string }) {
  const product = productBySlug(slug);
  const { add, open } = useCart();
  const [size, setSize] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [added, setAdded] = useState<string | null>(null);
  const [guide, setGuide] = useState(false);
  if (!product) return <NotFound />;

  const images = [
    { ref: product.images.front, name: 'Front' },
    ...(product.images.back ? [{ ref: product.images.back, name: 'Back' }] : []),
    ...product.images.details.map((ref, i) => ({ ref, name: `Detail ${i + 1}` })),
  ];
  const related = products.filter((p) => p.slug !== product.slug).slice(0, 3);

  const requireSize = () => {
    if (!size) {
      setError('Choose a size first.');
      setAdded(null);
      return false;
    }
    return true;
  };

  return (
    <div className="px-4 pb-24 pt-28 sm:px-8 md:pt-32">
      <div className="mx-auto max-w-[1500px]">
        <Breadcrumbs
          trail={[
            { label: 'Home', path: '' },
            { label: 'Shop', path: 'shop/' },
            { label: categoryLabel(product.category), path: `shop/?category=${product.category}` },
            { label: `${product.name}, ${product.colour}` },
          ]}
        />

        <div className="mt-8 grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <Gallery images={images} label={`${product.name}, ${product.colour}`} />
          </div>

          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <p className="label text-gold">{categoryLabel(product.category)}</p>
              <h1 className="display mt-4 text-[clamp(2.8rem,4.8vw,4.6rem)]">{product.name}</h1>
              <p className="label mt-3 text-smoke">
                {product.colour}
                {product.sku && <> · SKU {product.sku}</>}
              </p>
              <p className={`mt-7 font-serif text-3xl ${product.price === null ? 'text-muted' : ''}`}>{priceLabel(product.price)}</p>
              <p className="mt-2 text-sm text-muted">{availabilityLabel[product.availability] ?? product.availability}</p>

              {product.sample && (
                <div className="mt-6">
                  <PreviewNotice>
                    Concept piece shown as a 3D render. It is not yet a product for sale: price, sizes and availability await the client’s real product
                    data.
                  </PreviewNotice>
                </div>
              )}

              <p className="mt-6 text-muted">{product.summary}</p>

              <form
                className="mt-8"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!requireSize()) return;
                  add(product.slug, size!);
                  setAdded(`Size ${size} added to your bag.`);
                  open();
                }}
              >
                <SizeSelector
                  sizes={product.sizes}
                  value={size}
                  onChange={(s) => {
                    setSize(s);
                    setError(null);
                  }}
                  error={error}
                  name={`size-${product.slug}`}
                  hint={product.sizesConfirmed ? undefined : 'Size range to be confirmed'}
                />
                <button type="button" onClick={() => setGuide(true)} className="label link-line mb-5 py-2 text-[0.625rem] text-muted hover:text-ivory">
                  Size guide
                </button>
                <div className="grid gap-3 sm:grid-cols-2">
                  <button type="submit" className="btn-gold w-full">
                    Add to bag
                  </button>
                  <button
                    type="button"
                    className="btn-ghost w-full"
                    onClick={() => {
                      if (!requireSize()) return;
                      add(product.slug, size!);
                      location.href = href('bag/');
                    }}
                  >
                    Buy now
                  </button>
                </div>
                <p className="mt-4 min-h-5 text-sm text-muted" aria-live="polite">
                  {added ?? 'Online payment is not active yet — see your bag for how ordering will work.'}
                </p>
              </form>

              <div className="mt-8 divide-y divide-line border-y border-line">
                <details className="group" open>
                  <summary className="label flex min-h-14 list-none items-center justify-between text-ivory [&::-webkit-details-marker]:hidden">
                    Details
                    <span aria-hidden className="text-lg text-gold transition-transform duration-300 group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <ul className="space-y-1.5 pb-6 text-sm text-muted">
                    {product.details.map((d) => (
                      <li key={d} className="flex gap-3">
                        <span aria-hidden className="mt-2.5 h-px w-3 shrink-0 bg-gold" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </details>
                <details className="group">
                  <summary className="label flex min-h-14 list-none items-center justify-between text-ivory [&::-webkit-details-marker]:hidden">
                    Shipping &amp; returns
                    <span aria-hidden className="text-lg text-gold transition-transform duration-300 group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <div className="space-y-2 pb-6 text-sm text-muted">
                    <p>
                      <Fact value={business.shippingPolicy} pending="Shipping policy to be confirmed by the client" />
                    </p>
                    <p>
                      <Fact value={business.returnsPolicy} pending="Returns policy to be confirmed by the client" />
                    </p>
                  </div>
                </details>
              </div>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section aria-labelledby="related-title" className="mt-28 border-t border-line pt-16">
            <h2 id="related-title" className="display text-[clamp(2.2rem,3.6vw,3.4rem)]">
              Also in the collection
            </h2>
            <div className="mt-10 grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p, i) => (
                <ProductCard key={p.slug} product={p} index={i} />
              ))}
            </div>
          </section>
        )}
      </div>
      <SizeGuide open={guide} onClose={() => setGuide(false)} />
    </div>
  );
}
