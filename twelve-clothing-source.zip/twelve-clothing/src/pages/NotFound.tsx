import { href } from '../site/paths';

export default function NotFound() {
  return (
    <div className="flex min-h-[80svh] flex-col items-center justify-center gap-6 px-6 pt-24 text-center">
      <p className="label text-gold">404</p>
      <h1 className="display text-[clamp(3rem,7vw,6rem)]">This page doesn’t exist.</h1>
      <p className="max-w-md text-muted">The link may be old, or the piece may have moved.</p>
      <div className="flex flex-wrap justify-center gap-3">
        <a href={href('shop/')} className="btn-gold">
          Go to the shop
        </a>
        <a href={href()} className="btn-ghost">
          Home
        </a>
      </div>
    </div>
  );
}
