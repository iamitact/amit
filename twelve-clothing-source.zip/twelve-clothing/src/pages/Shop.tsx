import { useMemo, useState } from 'react';
import { CloseIcon } from '../components/Icons';
import { PreviewNotice } from '../components/Pending';
import { ProductCard } from '../components/ProductCard';
import { Reveal } from '../components/Reveal';
import { catalog, isSampleCatalogue, products, type Product } from '../site/catalog';

type Sort = 'featured' | 'name' | 'price-asc' | 'price-desc';

/** Price sorting is offered only when every product has a confirmed price. */
const pricesKnown = products.every((p) => p.price !== null) && !!catalog.currency;
const SORTS: { value: Sort; label: string }[] = [
  { value: 'featured', label: 'Featured' },
  { value: 'name', label: 'Name A–Z' },
  ...(pricesKnown
    ? ([
        { value: 'price-asc', label: 'Price, low to high' },
        { value: 'price-desc', label: 'Price, high to low' },
      ] as const)
    : []),
];
const COLOURS = [...new Set(products.map((p) => p.colour))];

interface Filters {
  category: string | null;
  colours: string[];
  sort: Sort;
}

function readFilters(): Filters {
  const q = new URLSearchParams(location.search);
  const category = q.get('category');
  const sort = q.get('sort') as Sort | null;
  return {
    category: catalog.categories.some((c) => c.id === category) ? category : null,
    colours: (q.get('colour') ?? '').split(',').filter((c) => COLOURS.includes(c)),
    sort: SORTS.some((s) => s.value === sort) ? sort! : 'featured',
  };
}

/** Filters live in the query string so a filtered view can be shared or bookmarked. */
function writeFilters(f: Filters) {
  const q = new URLSearchParams();
  if (f.category) q.set('category', f.category);
  if (f.colours.length) q.set('colour', f.colours.join(','));
  if (f.sort !== 'featured') q.set('sort', f.sort);
  const qs = q.toString();
  history.replaceState(null, '', `${location.pathname}${qs ? `?${qs}` : ''}`);
}

const matches = (p: Product, f: Filters, ignore?: 'category' | 'colour') =>
  (ignore === 'category' || !f.category || p.category === f.category) &&
  (ignore === 'colour' || f.colours.length === 0 || f.colours.includes(p.colour));

/**
 * Shop page. Layout adapted from the 21st.dev "Ecommerce Category Page"
 * (hirael, MIT): per-option counts, removable active-filter chips, a sort
 * control and an empty state — limited to the facets the real data supports.
 */
export default function Shop() {
  const [filters, setFilters] = useState<Filters>(readFilters);
  const update = (next: Filters) => {
    setFilters(next);
    writeFilters(next);
  };

  const results = useMemo(() => {
    const list = products.filter((p) => matches(p, filters));
    if (filters.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    if (filters.sort === 'price-asc') list.sort((a, b) => (a.price ?? 0) - (b.price ?? 0));
    if (filters.sort === 'price-desc') list.sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
    return list;
  }, [filters]);

  const active = [
    ...(filters.category
      ? [{ key: 'cat', label: catalog.categories.find((c) => c.id === filters.category)?.label ?? '', clear: () => update({ ...filters, category: null }) }]
      : []),
    ...filters.colours.map((c) => ({ key: `col-${c}`, label: c, clear: () => update({ ...filters, colours: filters.colours.filter((x) => x !== c) }) })),
  ];

  const chip = (selected: boolean) =>
    `label inline-flex min-h-11 items-center gap-2 border px-4 text-[0.625rem] transition-colors duration-200 ${
      selected ? 'border-gold bg-gold text-on-gold' : 'border-line-strong text-ivory hover:border-ivory'
    }`;

  return (
    <div className="px-4 pb-28 pt-32 sm:px-8 md:pt-40">
      <div className="mx-auto max-w-[1500px]">
        <Reveal>
          <p className="label text-gold">Shop</p>
          <h1 className="display mt-5 text-[clamp(3.2rem,7vw,7rem)]">The collection</h1>
        </Reveal>
        {isSampleCatalogue && (
          <div className="mt-8 max-w-3xl">
            <PreviewNotice>
              Preview catalogue: the pieces below are 3D concept renders with placeholder details. The client’s real products, photographs, sizes
              and prices will replace them before launch.
            </PreviewNotice>
          </div>
        )}

        <div className="mt-12 flex flex-col gap-6 border-y border-line py-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-center sm:gap-8">
            <fieldset className="flex flex-wrap items-center gap-2">
              <legend className="label mb-2 text-[0.625rem] text-smoke sm:float-left sm:mb-0 sm:mr-3">Category</legend>
              <button type="button" aria-pressed={!filters.category} className={chip(!filters.category)} onClick={() => update({ ...filters, category: null })}>
                All <span className="tabular-nums opacity-70">{products.filter((p) => matches(p, filters, 'category')).length}</span>
              </button>
              {catalog.categories.map((c) => {
                const count = products.filter((p) => p.category === c.id && matches(p, filters, 'category')).length;
                const selected = filters.category === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    aria-pressed={selected}
                    disabled={count === 0 && !selected}
                    className={`${chip(selected)} disabled:cursor-not-allowed disabled:opacity-40`}
                    onClick={() => update({ ...filters, category: selected ? null : c.id })}
                  >
                    {c.label} <span className="tabular-nums opacity-70">{count}</span>
                  </button>
                );
              })}
            </fieldset>
            <fieldset className="flex flex-wrap items-center gap-2">
              <legend className="label mb-2 text-[0.625rem] text-smoke sm:float-left sm:mb-0 sm:mr-3">Colour</legend>
              {COLOURS.map((c) => {
                const selected = filters.colours.includes(c);
                const count = products.filter((p) => p.colour === c && matches(p, filters, 'colour')).length;
                return (
                  <button
                    key={c}
                    type="button"
                    aria-pressed={selected}
                    disabled={count === 0 && !selected}
                    className={`${chip(selected)} disabled:cursor-not-allowed disabled:opacity-40`}
                    onClick={() => update({ ...filters, colours: selected ? filters.colours.filter((x) => x !== c) : [...filters.colours, c] })}
                  >
                    {c} <span className="tabular-nums opacity-70">{count}</span>
                  </button>
                );
              })}
            </fieldset>
          </div>
          <label className="flex items-center gap-3">
            <span className="label text-[0.625rem] text-smoke">Sort</span>
            <select
              value={filters.sort}
              onChange={(e) => update({ ...filters, sort: e.target.value as Sort })}
              className="h-11 border border-line-strong bg-ink px-3 text-sm text-ivory focus:border-gold"
            >
              {SORTS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-6 flex min-h-11 flex-wrap items-center gap-3">
          <p className="text-sm text-muted" role="status" aria-live="polite">
            {results.length} {results.length === 1 ? 'piece' : 'pieces'}
          </p>
          {active.map((a) => (
            <button key={a.key} type="button" onClick={a.clear} className="label inline-flex min-h-9 items-center gap-2 border border-line px-3 text-[0.625rem] text-ivory hover:border-ivory">
              {a.label}
              <CloseIcon size={12} />
              <span className="sr-only">Remove filter</span>
            </button>
          ))}
          {active.length > 1 && (
            <button type="button" onClick={() => update({ ...filters, category: null, colours: [] })} className="label link-line py-2 text-[0.625rem] text-muted">
              Clear all
            </button>
          )}
        </div>

        {results.length === 0 ? (
          <div className="mt-16 flex flex-col items-center gap-5 py-20 text-center">
            <p className="display text-4xl">Nothing matches those filters.</p>
            <button type="button" onClick={() => update({ category: null, colours: [], sort: filters.sort })} className="btn-ghost">
              Clear filters
            </button>
          </div>
        ) : (
          <div key={`${filters.category}-${filters.colours.join()}-${filters.sort}`} className="mt-10 grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
            {results.map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
