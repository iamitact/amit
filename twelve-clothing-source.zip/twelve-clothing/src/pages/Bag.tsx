import { BagLine } from '../components/CartDrawer';
import { Fact } from '../components/Pending';
import { business, commerce, formatPrice } from '../site/catalog';
import { href } from '../site/paths';
import { useCart } from '../state/cart';

/**
 * Bag and checkout status. There is no payment integration yet, so this page
 * never takes an order or reports a payment: it shows the bag and explains the
 * current state honestly. When commerce.json gains a verified provider and a
 * checkout server URL, the checkout button will call that server instead.
 */
export default function Bag() {
  const { lines, count, subtotal, clear } = useCart();
  const checkoutLive = commerce.status === 'live' && !!commerce.apiBase && !!commerce.provider;

  return (
    <div className="px-4 pb-24 pt-32 sm:px-8 md:pt-40">
      <div className="mx-auto max-w-[1200px]">
        <h1 className="display text-[clamp(3rem,6vw,6rem)]">Your bag</h1>
        <p className="label mt-3 text-smoke">
          {count} {count === 1 ? 'piece' : 'pieces'}
        </p>

        {lines.length === 0 ? (
          <div className="mt-16 flex flex-col items-start gap-6">
            <p className="text-muted">Your bag is empty. Pieces you add are kept on this device.</p>
            <a href={href('shop/')} className="btn-gold">
              Browse the shop
            </a>
          </div>
        ) : (
          <div className="mt-12 grid gap-14 lg:grid-cols-12">
            <ul className="divide-y divide-line border-y border-line lg:col-span-7">
              {lines.map((l) => (
                <BagLine key={l.key} lineKey={l.key} slug={l.slug} size={l.size} qty={l.qty} />
              ))}
            </ul>
            <aside aria-labelledby="summary-title" className="lg:col-span-5">
              <div className="border border-line bg-coal p-6 sm:p-8">
                <h2 id="summary-title" className="label text-ivory">
                  Order summary
                </h2>
                <div className="mt-6 flex items-baseline justify-between gap-4">
                  <span className="text-muted">Subtotal</span>
                  <span className="font-serif text-3xl">{formatPrice(subtotal) ?? 'To be confirmed'}</span>
                </div>
                <p className="mt-2 text-xs text-smoke">Shipping and taxes: {business.shippingPolicy ? 'calculated at checkout' : 'policy to be confirmed'}.</p>

                {checkoutLive ? (
                  <p className="mt-6 text-sm text-muted">Checkout server configured — integration pending verification.</p>
                ) : (
                  <div className="mt-8 border-t border-line pt-6">
                    <p className="label text-gold">Checkout</p>
                    <h3 className="mt-3 font-serif text-2xl">Online payment isn’t available yet.</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted">
                      Twelve Clothing is setting up secure online payment. Until it is verified, this site does not take orders or payments — nothing
                      you do here will charge you. Your bag stays saved on this device.
                    </p>
                    <p className="mt-4 text-sm text-muted">
                      To order in the meantime, contact the shop:{' '}
                      {business.phone || business.email ? (
                        <a className="link-line text-ivory" href={business.phone ? `tel:${business.phone}` : `mailto:${business.email}`}>
                          {business.phone ?? business.email}
                        </a>
                      ) : (
                        <Fact value={null} pending="contact details to be confirmed" />
                      )}
                    </p>
                    <button type="button" disabled className="btn-gold mt-6 w-full cursor-not-allowed opacity-50" aria-describedby="checkout-state">
                      Checkout unavailable
                    </button>
                    <p id="checkout-state" className="mt-3 text-xs text-smoke">
                      Status: payment provider not yet connected.
                    </p>
                  </div>
                )}
                <button type="button" onClick={clear} className="label link-line mt-6 block py-2 text-[0.625rem] text-smoke hover:text-ivory">
                  Empty bag
                </button>
              </div>
              <a href={href('shop/')} className="label link-line mt-6 inline-block py-2 text-[0.625rem] text-muted">
                Continue shopping
              </a>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
