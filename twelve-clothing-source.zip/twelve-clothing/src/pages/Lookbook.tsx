import { PreviewNotice } from '../components/Pending';
import { Photo } from '../components/Photo';
import { Reveal } from '../components/Reveal';
import { photoSlots } from '../site/catalog';
import { href } from '../site/paths';

const LOOKS = ['lookbook.1', 'lookbook.2', 'lookbook.3', 'lookbook.4'];

/** Editorial lookbook: an asymmetric composition, not a card grid. */
export default function Lookbook() {
  const usingConcepts = LOOKS.some((s) => !photoSlots[s]?.image);
  const [a, b, c, d] = LOOKS;
  return (
    <div className="px-4 pb-28 pt-32 sm:px-8 md:pt-40">
      <div className="mx-auto max-w-[1500px]">
        <Reveal>
          <p className="label text-gold">Lookbook</p>
          <h1 className="display mt-6 max-w-[14ch] text-[clamp(3.4rem,10vw,10rem)]">
            Black, in <em className="font-normal italic text-ivory/75">every</em> light.
          </h1>
        </Reveal>
        {usingConcepts && (
          <div className="mt-8 max-w-2xl">
            <PreviewNotice>Concept renders hold these frames until the client’s lookbook photography is supplied.</PreviewNotice>
          </div>
        )}

        <div className="mt-20 grid grid-cols-12 gap-x-4 gap-y-14 md:mt-28 md:gap-x-8">
          <Reveal variant="image" className="col-span-12 md:col-span-6 md:row-span-2">
            <Photo slot={a} alt="Lookbook image one" sizes="(min-width: 768px) 48vw, 100vw" parallax eager />
            <p className="label mt-4 text-[0.625rem] text-smoke">Look 01</p>
          </Reveal>
          <Reveal className="col-span-12 flex flex-col justify-end md:col-span-5 md:col-start-8">
            <p className="max-w-sm font-serif text-2xl leading-snug text-ivory/90 md:text-[1.75rem]">
              A single lamp overhead, nothing else to hide behind.
            </p>
          </Reveal>
          <Reveal variant="image" delay={80} className="col-span-7 md:col-span-4 md:col-start-8">
            <Photo slot={b} alt="Lookbook image two" sizes="(min-width: 768px) 32vw, 60vw" />
            <p className="label mt-4 text-[0.625rem] text-smoke">Look 02</p>
          </Reveal>
          <Reveal variant="image" delay={160} className="col-span-5 mt-24 md:col-span-3 md:mt-40">
            <Photo slot={c} alt="Lookbook image three" sizes="(min-width: 768px) 24vw, 40vw" />
            <p className="label mt-4 text-[0.625rem] text-smoke">Look 03</p>
          </Reveal>
          <Reveal variant="image" className="col-span-12 md:col-span-5 md:col-start-5 md:mt-16">
            <Photo slot="lookbook.wide" alt="Wide lookbook detail" ratio="16 / 10" sizes="(min-width: 768px) 42vw, 100vw" parallax />
          </Reveal>
          <Reveal variant="image" delay={80} className="col-span-8 col-start-5 md:col-span-3 md:col-start-10 md:-mt-24">
            <Photo slot={d} alt="Lookbook image four" sizes="(min-width: 768px) 24vw, 60vw" />
            <p className="label mt-4 text-[0.625rem] text-smoke">Look 04</p>
          </Reveal>
        </div>

        <div className="mt-28 flex flex-wrap items-center justify-between gap-6 border-t border-line pt-12">
          <p className="display text-[clamp(2rem,3.4vw,3.2rem)]">Seen something?</p>
          <a href={href('shop/')} className="btn-gold">
            Shop the collection
          </a>
        </div>
      </div>
    </div>
  );
}
