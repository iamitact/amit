import { href } from '../site/paths';

export function Breadcrumbs({ trail }: { trail: { label: string; path?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className="label flex flex-wrap items-center gap-x-3 gap-y-1 text-[0.625rem] text-smoke">
        {trail.map((t, i) => (
          <li key={t.label} className="flex items-center gap-3">
            {i > 0 && <span aria-hidden>/</span>}
            {t.path !== undefined && i < trail.length - 1 ? (
              <a href={href(t.path)} className="link-line py-1 hover:text-ivory">
                {t.label}
              </a>
            ) : (
              <span aria-current="page" className="text-muted">
                {t.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
