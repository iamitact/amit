import { useState } from 'react';
import { formatPrice, productById } from '../content/products';
import { useCart } from '../state/cart';
import { CloseIcon, MinusIcon, PlusIcon } from './Icons';
import { Modal } from './Modal';

export function CartDrawer() {
  const { lines, count, subtotal, isOpen, close, setQty, remove, clear } = useCart();
  const [checkout, setCheckout] = useState(false);

  return (
    <>
      <Modal open={isOpen && !checkout} onClose={close} labelledBy="cart-title" variant="sheet">
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b border-line px-6 py-5">
            <h2 id="cart-title" className="label text-ivory">
              Your bag <span className="text-smoke">({count})</span>
            </h2>
            <button
              type="button"
              onClick={close}
              className="flex h-11 w-11 items-center justify-center text-muted hover:text-ivory"
              aria-label="Close bag"
            >
              <CloseIcon />
            </button>
          </div>

          {lines.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-6 px-8 text-center">
              <p className="display text-4xl">Your bag is empty.</p>
              <p className="text-sm text-muted">Pieces you add are kept on this device.</p>
              <a href="#reserve" onClick={close} className="btn-ghost">
                See the Nocturne
              </a>
            </div>
          ) : (
            <>
              <ul className="flex-1 divide-y divide-line overflow-y-auto px-6">
                {lines.map((l) => {
                  const p = productById(l.productId)!;
                  return (
                    <li key={l.key} className="flex gap-4 py-5">
                      <img
                        src={`${import.meta.env.BASE_URL}renders/${p.image}-500.webp`}
                        width={96}
                        height={120}
                        alt=""
                        className="h-[7.5rem] w-24 shrink-0 bg-ink object-cover"
                      />
                      <div className="flex min-w-0 flex-1 flex-col">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-serif text-xl leading-tight">{p.name}</p>
                            <p className="label mt-1 text-[0.625rem] text-smoke">
                              {p.colorway} · Size {l.size}
                            </p>
                          </div>
                          <p className="text-sm">{formatPrice(p.price * l.qty)}</p>
                        </div>
                        <div className="mt-auto flex items-center justify-between pt-3">
                          <div
                            className="flex items-center border border-line-strong"
                            role="group"
                            aria-label={`Quantity for ${p.name}, ${p.colorway}, size ${l.size}`}
                          >
                            <button
                              type="button"
                              onClick={() => setQty(l.key, l.qty - 1)}
                              className="flex h-11 w-11 items-center justify-center hover:text-gold"
                              aria-label={l.qty === 1 ? 'Remove item' : 'Decrease quantity'}
                            >
                              <MinusIcon size={16} />
                            </button>
                            <span className="w-8 text-center text-sm" aria-live="polite">
                              {l.qty}
                            </span>
                            <button
                              type="button"
                              onClick={() => setQty(l.key, l.qty + 1)}
                              disabled={l.qty >= 9}
                              className="flex h-11 w-11 items-center justify-center hover:text-gold disabled:cursor-not-allowed disabled:opacity-40"
                              aria-label="Increase quantity"
                            >
                              <PlusIcon size={16} />
                            </button>
                          </div>
                          <button
                            type="button"
                            onClick={() => remove(l.key)}
                            className="label link-line py-2 text-[0.625rem] text-muted hover:text-ivory"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
              <div className="border-t border-line px-6 py-6">
                <div className="flex items-baseline justify-between">
                  <span className="label text-muted">Subtotal</span>
                  <span className="font-serif text-3xl">{formatPrice(subtotal)}</span>
                </div>
                <p className="mt-2 text-xs text-smoke">Demo prices. Shipping and taxes are not calculated.</p>
                <button type="button" onClick={() => setCheckout(true)} className="btn-gold mt-5 w-full">
                  Checkout
                </button>
                <button
                  type="button"
                  onClick={clear}
                  className="label link-line mx-auto mt-4 block py-2 text-[0.625rem] text-smoke hover:text-ivory"
                >
                  Empty bag
                </button>
              </div>
            </>
          )}
        </div>
      </Modal>

      <Modal open={isOpen && checkout} onClose={() => setCheckout(false)} labelledBy="checkout-title" variant="center">
        <div className="mx-auto max-w-lg p-8 text-center sm:p-12">
          <p className="label text-gold">Demo storefront</p>
          <h2 id="checkout-title" className="display mt-4 text-5xl">
            Checkout isn’t connected.
          </h2>
          <p className="mt-5 text-muted">
            This is a demonstration site. There is no payment provider, so no order has been placed and nothing has been
            charged. Your bag stays saved on this device.
          </p>
          <p className="mt-3 text-sm text-smoke">
            To sell for real, connect a commerce backend (for example Shopify or Stripe Checkout) at this step.
          </p>
          <button type="button" onClick={() => setCheckout(false)} className="btn-ghost mt-8">
            Back to bag
          </button>
        </div>
      </Modal>
    </>
  );
}
