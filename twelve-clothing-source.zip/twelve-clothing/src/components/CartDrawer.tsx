import { imageSource, priceLabel, productBySlug, formatPrice } from '../site/catalog';
import { href } from '../site/paths';
import { useCart } from '../state/cart';
import { CloseIcon, MinusIcon, PlusIcon } from './Icons';
import { Modal } from './Modal';

/** Quick-view bag. The full bag and checkout status live on the Bag page. */
export function CartDrawer() {
  const { lines, count, subtotal, isOpen, close } = useCart();
  return (
    <Modal open={isOpen} onClose={close} labelledBy="cart-title" variant="sheet">
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between border-b border-line px-6 py-5">
          <h2 id="cart-title" className="label text-ivory">
            Your bag <span className="text-smoke">({count})</span>
          </h2>
          <button type="button" onClick={close} className="flex h-11 w-11 items-center justify-center text-muted hover:text-ivory" aria-label="Close bag">
            <CloseIcon />
          </button>
        </div>
        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-6 px-8 text-center">
            <p className="display text-4xl">Your bag is empty.</p>
            <p className="text-sm text-muted">Pieces you add are kept on this device.</p>
            <a href={href('shop/')} className="btn-ghost">
              Browse the shop
            </a>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-line overflow-y-auto px-6">
              {lines.map((l) => (
                <BagLine key={l.key} lineKey={l.key} slug={l.slug} size={l.size} qty={l.qty} compact />
              ))}
            </ul>
            <div className="border-t border-line px-6 py-6">
              <div className="flex items-baseline justify-between gap-4">
                <span className="label text-muted">Subtotal</span>
                <span className="font-serif text-2xl">{formatPrice(subtotal) ?? 'To be confirmed'}</span>
              </div>
              <a href={href('bag/')} className="btn-gold mt-5 w-full">
                View bag &amp; checkout
              </a>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

export function BagLine({ lineKey, slug, size, qty, compact }: { lineKey: string; slug: string; size: string; qty: number; compact?: boolean }) {
  const { setQty, remove } = useCart();
  const p = productBySlug(slug);
  if (!p) return null;
  const img = imageSource(p.images.front);
  const lineTotal = p.price === null ? null : p.price * qty;
  return (
    <li className="flex gap-4 py-5">
      <a href={href(`shop/${p.slug}/`)} className="block shrink-0" tabIndex={-1} aria-hidden>
        {img && <img src={img.srcSet.split(' ')[0]} width={96} height={120} alt="" className={`${compact ? 'h-[7.5rem] w-24' : 'h-40 w-32'} bg-ink object-cover`} />}
      </a>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-3">
          <div>
            <a href={href(`shop/${p.slug}/`)} className="font-serif text-xl leading-tight hover:text-gold">
              {p.name}
            </a>
            <p className="label mt-1 text-[0.625rem] text-smoke">
              {p.colour} · Size {size}
            </p>
          </div>
          <p className="text-right text-sm">{formatPrice(lineTotal) ?? priceLabel(null)}</p>
        </div>
        <div className="mt-auto flex items-center justify-between pt-3">
          <div className="flex items-center border border-line-strong" role="group" aria-label={`Quantity for ${p.name}, ${p.colour}, size ${size}`}>
            <button type="button" onClick={() => setQty(lineKey, qty - 1)} className="flex h-11 w-11 items-center justify-center hover:text-gold" aria-label={qty === 1 ? 'Remove item' : 'Decrease quantity'}>
              <MinusIcon size={16} />
            </button>
            <span className="w-8 text-center text-sm" aria-live="polite">
              {qty}
            </span>
            <button
              type="button"
              onClick={() => setQty(lineKey, qty + 1)}
              disabled={qty >= 9}
              className="flex h-11 w-11 items-center justify-center hover:text-gold disabled:cursor-not-allowed disabled:opacity-40"
              aria-label="Increase quantity"
            >
              <PlusIcon size={16} />
            </button>
          </div>
          <button type="button" onClick={() => remove(lineKey)} className="label link-line py-2 text-[0.625rem] text-muted hover:text-ivory">
            Remove
          </button>
        </div>
      </div>
    </li>
  );
}
