import { useState } from 'react';
import { formatPrice, PRODUCTS, renderSrc } from '../content/products';
import { ArrowRightIcon } from './Icons';
import { Reveal } from './Reveal';

/**
 * Numbered collection index whose hover/focus drives a large preview.
 * Pattern adapted from the 21st.dev "lumina-interactive-list" component
 * (numbered 01–06 list + featured preview), rebuilt without its CDN scripts
 * or shader so it stays accessible, keyboard-driven and lightweight.
 */
export function Collection({ onOpenProduct }: { onOpenProduct: (id: string) => void }) {
  const [active, setActive] = useState(0);
  const product = PRODUCTS[active];

  return (
    <section id="collection" aria-labelledby="collection-title" className="border-t border-line px-4 py-28 sm:px-8 md:py-36">
      <div className="mx-auto grid max-w-[1500px] gap-14 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-6">
          <Reveal>
            <p className="label text-gold">The collection</p>
            <h2 id="collection-title" className="display mt-6 text-[clamp(3rem,6vw,5.8rem)]">
              One pattern,
              <br />
              <em className="font-normal italic text-ivory/75">four pieces.</em>
            </h2>
            <p className="mt-6 max-w-md text-muted">Demo collection. Prices are illustrative and the pieces are rendered from our 3D pattern.</p>
          </Reveal>

          <ol className="mt-14 border-t border-line">
            {PRODUCTS.map((p, i) => (
              <li key={p.id} className="border-b border-line">
                <button
                  type="button"
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  onClick={() => onOpenProduct(p.id)}
                  aria-label={`${p.name}, ${p.colorway}, ${formatPrice(p.price)}. View details`}
                  className="group grid w-full grid-cols-[2.5rem_1fr_auto] items-baseline gap-4 py-6 text-left md:grid-cols-[3.5rem_1fr_auto_auto] md:py-7"
                >
                  <span className={`label transition-colors ${active === i ? 'text-gold' : 'text-smoke'}`}>{String(i + 1).padStart(2, '0')}</span>
                  <span>
                    <span className={`block font-serif text-3xl transition-colors duration-300 md:text-4xl ${active === i ? 'text-ivory' : 'text-ivory/55 group-hover:text-ivory'}`}>
                      {p.name}
                    </span>
                    <span className="label mt-2 block text-[0.625rem] text-smoke">
                      {p.colorway} · {p.line}
                    </span>
                  </span>
                  <span className="text-sm text-muted">{formatPrice(p.price)}</span>
                  <ArrowRightIcon
                    size={18}
                    className={`hidden transition-all duration-300 md:block ${active === i ? 'translate-x-0 text-gold opacity-100' : '-translate-x-2 opacity-0'}`}
                  />
                </button>
              </li>
            ))}
          </ol>
        </div>

        <div className="lg:col-span-5 lg:col-start-8">
          <div className="lg:sticky lg:top-28">
            <div className="relative aspect-[4/5] overflow-hidden bg-coal">
              {PRODUCTS.map((p, i) => {
                const img = renderSrc(p.image, 'portrait');
                return (
                  <img
                    key={p.id}
                    src={img.src}
                    srcSet={img.srcSet}
                    sizes="(min-width: 1024px) 38vw, 100vw"
                    width={img.width}
                    height={img.height}
                    loading="lazy"
                    alt={i === active ? p.imageAlt : ''}
                    aria-hidden={i !== active}
                    className={`absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-700 ease-[var(--ease-cinema)] ${
                      i === active ? 'scale-100 opacity-100' : 'scale-[1.04] opacity-0'
                    }`}
                  />
                );
              })}
              <span className="label absolute left-5 top-5 text-[0.625rem] text-smoke">{String(active + 1).padStart(2, '0')} / {String(PRODUCTS.length).padStart(2, '0')}</span>
            </div>
            <div className="mt-6 flex items-start justify-between gap-6">
              <p className="max-w-sm text-sm text-muted">{product.description}</p>
              <button type="button" onClick={() => onOpenProduct(product.id)} className="btn-ghost shrink-0">
                View
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
