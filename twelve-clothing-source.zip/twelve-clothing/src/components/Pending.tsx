import type { ReactNode } from 'react';

/** Inline marker for business facts the client has not supplied yet. */
export function Pending({ children = 'To be confirmed' }: { children?: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-smoke">
      <span aria-hidden className="h-1.5 w-1.5 rounded-full border border-gold" />
      <span>{children}</span>
    </span>
  );
}

/** A value or its pending marker. */
export function Fact({ value, pending }: { value: ReactNode | null | undefined; pending?: string }) {
  return value === null || value === undefined || value === '' ? <Pending>{pending}</Pending> : <>{value}</>;
}

/** Banner for pages whose content is still a preview. */
export function PreviewNotice({ children }: { children: ReactNode }) {
  return (
    <p className="flex items-start gap-3 border border-line bg-coal px-4 py-3 text-sm leading-relaxed text-muted">
      <span aria-hidden className="label mt-0.5 shrink-0 text-[0.5625rem] text-gold">
        Preview
      </span>
      <span>{children}</span>
    </p>
  );
}
