import { renderSrc } from '../content/products';
import { Reveal } from './Reveal';

const LOOKS = [
  { img: 'look-nocturne-portrait', alt: 'The black Nocturne polo, close crop of the collar and shoulders.', caption: 'Look 01 — Nocturne, black', productId: 'nocturne-black' },
  { img: 'look-vesper-portrait', alt: 'The slate Vesper long-sleeve polo, close crop of the collar and shoulders.', caption: 'Look 02 — Vesper, slate', productId: 'vesper-slate' },
  { img: 'look-ivory-side', alt: 'The ivory Nocturne polo seen in profile.', caption: 'Look 03 — Nocturne, ivory', productId: 'nocturne-ivory' },
  { img: 'look-nocturne-back', alt: 'The black Nocturne polo from behind, showing the longer back hem.', caption: 'Look 04 — Nocturne, from behind', productId: 'nocturne-black' },
];

/** Art-directed interlude: an asymmetric composition, not a card grid. */
export function Campaign({ onOpenProduct }: { onOpenProduct: (id: string) => void }) {
  const [a, b, c, d] = LOOKS;
  const collar = renderSrc('detail-collar', 'landscape');
  return (
    <section id="campaign" aria-labelledby="campaign-title" className="relative overflow-hidden px-4 py-28 sm:px-8 md:py-40">
      <div className="mx-auto max-w-[1500px]">
        <Reveal>
          <p className="label text-gold">Collection XII · After Hours</p>
          <h2 id="campaign-title" className="display mt-6 max-w-[14ch] text-[clamp(3.4rem,10vw,10.5rem)]">
            Black, in <em className="font-normal italic text-ivory/75">every</em> light.
          </h2>
        </Reveal>

        <div className="mt-20 grid grid-cols-12 gap-x-4 gap-y-14 md:mt-28 md:gap-x-8">
          <Look look={a} className="col-span-12 md:col-span-6 md:row-span-2" onOpen={onOpenProduct} eager />
          <div className="col-span-12 flex flex-col justify-end md:col-span-5 md:col-start-8">
            <Reveal>
              <p className="max-w-sm font-serif text-2xl leading-snug text-ivory/90 md:text-[1.75rem]">
                Four pieces cut from one pattern. Each one lit the same way: a single lamp overhead, nothing else to hide behind.
              </p>
            </Reveal>
          </div>
          <Look look={b} className="col-span-7 md:col-span-4 md:col-start-8" onOpen={onOpenProduct} />
          <Look look={c} className="col-span-5 mt-24 md:col-span-3 md:mt-40" onOpen={onOpenProduct} />
          <figure className="col-span-12 md:col-span-5 md:col-start-5 md:mt-16">
            <img
              src={collar.src}
              srcSet={collar.srcSet}
              sizes="(min-width: 768px) 42vw, 100vw"
              width={collar.width}
              height={collar.height}
              loading="lazy"
              alt="Macro of the ribbed collar with its two tonal tipping lines."
              className="w-full"
            />
            <figcaption className="label mt-4 text-[0.625rem] text-smoke">Detail — rib collar, tonal tipping</figcaption>
          </figure>
          <Look look={d} className="col-span-8 col-start-5 md:col-span-3 md:col-start-10 md:-mt-24" onOpen={onOpenProduct} />
        </div>
      </div>
    </section>
  );
}

function Look({
  look,
  className,
  onOpen,
  eager,
}: {
  look: (typeof LOOKS)[number];
  className: string;
  onOpen: (id: string) => void;
  eager?: boolean;
}) {
  const img = renderSrc(look.img, 'portrait');
  return (
    <figure className={className}>
      <button type="button" onClick={() => onOpen(look.productId)} className="group block w-full overflow-hidden text-left" aria-label={`${look.caption}. View piece`}>
        <img
          src={img.src}
          srcSet={img.srcSet}
          sizes="(min-width: 768px) 40vw, 60vw"
          width={img.width}
          height={img.height}
          loading={eager ? undefined : 'lazy'}
          alt={look.alt}
          className="w-full transition-transform duration-700 ease-[var(--ease-cinema)] group-hover:scale-[1.03]"
        />
      </button>
      <figcaption className="label mt-4 flex items-center justify-between gap-4 text-[0.625rem] text-smoke">
        {look.caption}
        <span aria-hidden className="text-gold">View</span>
      </figcaption>
    </figure>
  );
}
