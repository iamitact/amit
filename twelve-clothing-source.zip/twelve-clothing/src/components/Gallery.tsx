import { useState } from 'react';
import { imageSource } from '../site/catalog';

/**
 * Product gallery: a large view that crossfades between front / back / detail
 * images, with a thumbnail strip (pattern adapted from the 21st.dev
 * "Thumbnail Slider"). Thumbnails are buttons with aria-pressed; arrow keys move
 * between them.
 */
export function Gallery({ images, label }: { images: { ref: string; name: string }[]; label: string }) {
  const [index, setIndex] = useState(0);
  const views = images.map((i) => ({ ...i, img: imageSource(i.ref) })).filter((v) => v.img);
  if (views.length === 0) return null;
  const current = views[Math.min(index, views.length - 1)];

  return (
    <div>
      <div className="relative aspect-[4/5] overflow-hidden bg-coal">
        {views.map((v, i) => (
          <img
            key={v.ref}
            src={v.img!.src}
            srcSet={v.img!.srcSet}
            sizes="(min-width: 1024px) 55vw, 100vw"
            width={v.img!.width}
            height={v.img!.height}
            loading={i === 0 ? 'eager' : 'lazy'}
            fetchPriority={i === 0 ? 'high' : undefined}
            decoding="async"
            alt={i === index ? `${label} — ${v.name}${v.img!.concept ? ' (3D concept render)' : ''}` : ''}
            aria-hidden={i !== index}
            className={`absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-600 ease-[var(--ease-cinema)] ${
              i === index ? 'scale-100 opacity-100' : 'scale-[1.02] opacity-0'
            }`}
          />
        ))}
        {current.img!.concept && (
          <span className="label pointer-events-none absolute bottom-3 left-3 bg-ink/70 px-2 py-1 text-[0.5625rem] text-smoke backdrop-blur-sm">
            Concept render
          </span>
        )}
      </div>
      {views.length > 1 && (
        <div
          className="mt-3 grid gap-2"
          style={{ gridTemplateColumns: `repeat(${Math.min(views.length, 5)}, minmax(0, 1fr))` }}
          role="group"
          aria-label="Product images"
          onKeyDown={(e) => {
            if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
            e.preventDefault();
            const next = (index + (e.key === 'ArrowRight' ? 1 : views.length - 1)) % views.length;
            setIndex(next);
            (e.currentTarget.children[next] as HTMLElement | undefined)?.focus();
          }}
        >
          {views.map((v, i) => (
            <button
              key={v.ref}
              type="button"
              onClick={() => setIndex(i)}
              aria-pressed={i === index}
              aria-label={`Show ${v.name.toLowerCase()} image`}
              className={`relative overflow-hidden border transition-colors ${i === index ? 'border-gold' : 'border-transparent hover:border-line-strong'}`}
            >
              <img src={v.img!.srcSet.split(' ')[0]} alt="" width={120} height={150} loading="lazy" className="aspect-[4/5] w-full object-cover" />
              <span className="label absolute bottom-1.5 left-2 text-[0.5625rem] text-ivory/90">{v.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
