import { useState, type FormEvent } from 'react';
import { renderSrc } from '../content/products';
import { Dial } from './Icons';
import { Reveal } from './Reveal';

export function House() {
  const img = renderSrc('detail-emblem', 'landscape');
  return (
    <section id="house" aria-labelledby="house-title" className="px-4 py-28 sm:px-8 md:py-40">
      <div className="mx-auto grid max-w-[1500px] items-center gap-14 lg:grid-cols-12">
        <Reveal className="lg:col-span-6">
          <img
            src={img.src}
            srcSet={img.srcSet}
            sizes="(min-width: 1024px) 48vw, 100vw"
            width={img.width}
            height={img.height}
            loading="lazy"
            alt="The Twelve Dial embroidered on black piqué: twelve raised marks in a ring."
            className="w-full"
          />
        </Reveal>
        <div className="lg:col-span-5 lg:col-start-8">
          <Reveal>
            <Dial size={40} className="text-gold" />
            <p className="label mt-8 text-gold">The house</p>
            <h2 id="house-title" className="display mt-5 text-[clamp(2.8rem,5vw,4.8rem)]">
              Made for the hour after everyone else has gone home.
            </h2>
            <div className="mt-8 space-y-5 text-muted">
              <p>
                Twelve is a study in black. We make a short list of garments and revise each one until nothing on it is
                decorative: a collar that keeps its line, a button you notice only when the light turns.
              </p>
              <p>
                Our only mark is the Dial — twelve raised stitches in a ring. No letters, no slogans. If you know, you
                know the hour.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

type Status = { kind: 'idle' } | { kind: 'error'; msg: string } | { kind: 'demo'; email: string };

export function Letters() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>({ kind: 'idle' });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const v = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
      setStatus({ kind: 'error', msg: 'Enter an email address like name@example.com.' });
      return;
    }
    setStatus({ kind: 'demo', email: v });
  };

  return (
    <section id="letters" aria-labelledby="letters-title" className="border-t border-line px-4 py-24 sm:px-8 md:py-32">
      <div className="mx-auto grid max-w-[1500px] gap-10 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="label text-gold">Letters</p>
          <h2 id="letters-title" className="display mt-5 text-[clamp(2.6rem,4.6vw,4.4rem)]">
            Notes from the twelfth hour.
          </h2>
          <p className="mt-5 max-w-md text-muted">Occasional letters about new pieces and how they are made.</p>
        </div>
        <form noValidate onSubmit={submit} className="lg:col-span-6 lg:col-start-7 lg:self-end">
          <label htmlFor="letters-email" className="label text-ivory">
            Email address
          </label>
          <div className="mt-4 flex flex-col gap-3 sm:flex-row">
            <input
              id="letters-email"
              type="email"
              autoComplete="email"
              inputMode="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (status.kind !== 'idle') setStatus({ kind: 'idle' });
              }}
              aria-invalid={status.kind === 'error' || undefined}
              aria-describedby="letters-status"
              placeholder="name@example.com"
              className="h-12 flex-1 border border-line-strong bg-transparent px-4 text-base text-ivory placeholder:text-smoke focus:border-gold focus:outline-none"
            />
            <button type="submit" className="btn-ghost">
              Sign up
            </button>
          </div>
          <p id="letters-status" role="status" className={`mt-4 min-h-12 text-sm ${status.kind === 'error' ? 'text-error' : 'text-muted'}`}>
            {status.kind === 'error' && status.msg}
            {status.kind === 'demo' &&
              `Demo only: no mailing service is connected, so ${status.email} was not sent anywhere or stored. Nobody has been subscribed.`}
            {status.kind === 'idle' && 'Demo form — nothing is sent until a mailing service is connected.'}
          </p>
        </form>
      </div>
    </section>
  );
}
