import { useEffect, useRef, useState } from 'react';
import type { RouteName } from '../site/pages';
import { href } from '../site/paths';
import { useCart } from '../state/cart';
import { BagIcon, CloseIcon, Dial, MenuIcon } from './Icons';

export const NAV: { path: string; label: string; routes: RouteName[] }[] = [
  { path: 'shop/', label: 'Shop', routes: ['shop', 'product'] },
  { path: 'story/', label: 'Story', routes: ['story'] },
  { path: 'lookbook/', label: 'Lookbook', routes: ['lookbook'] },
  { path: 'about/', label: 'About', routes: ['about'] },
  { path: 'contact/', label: 'Contact', routes: ['contact'] },
];

export function Header({ route, overlay }: { route: RouteName; overlay: boolean }) {
  const { count, open } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [solid, setSolid] = useState(!overlay);
  const menuButton = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!overlay) return;
    const onScroll = () => setSolid(window.scrollY > window.innerHeight * 0.5);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [overlay]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMenuOpen(false);
        menuButton.current?.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    document.documentElement.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.documentElement.style.overflow = '';
    };
  }, [menuOpen]);

  return (
    <>
      <a href="#main" className="sr-only-focusable fixed left-4 top-3 z-[60] bg-gold px-4 py-3 text-sm font-semibold text-on-gold">
        Skip to content
      </a>
      <header
        className={`site-header fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
          solid || menuOpen ? 'bg-ink/88 backdrop-blur-md' : 'bg-gradient-to-b from-ink/80 to-transparent'
        }`}
      >
        <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between px-4 sm:px-8 md:h-20">
          <a href={href()} className="flex items-center gap-3 text-ivory" aria-label="Twelve Clothing, home">
            <Dial size={26} className="text-gold" />
            <span className="font-serif text-[1.35rem] font-medium tracking-[0.34em]">TWELVE</span>
          </a>

          <nav aria-label="Primary" className="hidden lg:block">
            <ul className="flex items-center gap-9">
              {NAV.map((n) => {
                const active = n.routes.includes(route);
                return (
                  <li key={n.path}>
                    <a
                      href={href(n.path)}
                      aria-current={active ? 'page' : undefined}
                      className={`label py-2 transition-colors ${active ? 'nav-active text-ivory' : 'link-line text-muted hover:text-ivory'}`}
                    >
                      {n.label}
                    </a>
                  </li>
                );
              })}
            </ul>
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              onClick={open}
              className="relative flex h-11 min-w-11 items-center justify-center gap-2 px-2 text-ivory transition-colors hover:text-gold"
              aria-label={`Open bag, ${count} ${count === 1 ? 'item' : 'items'}`}
            >
              <BagIcon />
              <span className="label hidden sm:inline">Bag</span>
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[0.6875rem] font-semibold text-on-gold" aria-hidden>
                {count}
              </span>
            </button>
            <button
              ref={menuButton}
              type="button"
              className="flex h-11 w-11 items-center justify-center text-ivory lg:hidden"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              onClick={() => setMenuOpen((v) => !v)}
            >
              {menuOpen ? <CloseIcon size={22} /> : <MenuIcon size={22} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav id="mobile-menu" aria-label="Mobile" className="h-[calc(100svh-4rem)] overflow-y-auto border-t border-line bg-ink px-6 pb-10 pt-6 lg:hidden">
            <ul className="flex flex-col">
              {[{ path: '', label: 'Home', routes: ['home'] as RouteName[] }, ...NAV].map((n, i) => {
                const active = n.routes.includes(route);
                return (
                  <li key={n.path} className="border-b border-line">
                    <a
                      href={href(n.path)}
                      aria-current={active ? 'page' : undefined}
                      className={`flex items-baseline gap-5 py-5 font-serif text-4xl ${active ? 'text-gold' : 'text-ivory'}`}
                    >
                      <span className="label text-smoke">{String(i + 1).padStart(2, '0')}</span>
                      {n.label}
                    </a>
                  </li>
                );
              })}
            </ul>
            <a href={href('bag/')} className="label mt-8 inline-block py-2 text-muted">
              View bag ({count})
            </a>
          </nav>
        )}
      </header>
    </>
  );
}
