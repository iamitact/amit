import { catalog } from '../site/catalog';
import { CloseIcon } from './Icons';
import { Modal } from './Modal';

/**
 * Size guide dialog (measurement-table pattern adapted from the 21st.dev
 * "Size Guide Table" component). Measurements come only from
 * catalog.json → sizeGuide; until the client supplies them it says so.
 */
export function SizeGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const guide = catalog.sizeGuide;
  return (
    <Modal open={open} onClose={onClose} labelledBy="size-guide-title" variant="center">
      <div className="relative p-6 sm:p-10">
        <button type="button" onClick={onClose} className="absolute right-3 top-3 flex h-11 w-11 items-center justify-center text-muted hover:text-ivory" aria-label="Close size guide">
          <CloseIcon />
        </button>
        <p className="label text-gold">Fit</p>
        <h2 id="size-guide-title" className="display mt-3 text-5xl">
          Size guide
        </h2>
        {guide ? (
          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[28rem] text-left text-sm">
              <caption className="sr-only">Garment measurements in {guide.unit}</caption>
              <thead>
                <tr className="border-b border-line-strong">
                  <th scope="col" className="label py-3 pr-4 text-[0.625rem] text-smoke">
                    Size
                  </th>
                  {guide.columns.map((c) => (
                    <th key={c} scope="col" className="label py-3 pr-4 text-[0.625rem] text-smoke">
                      {c} ({guide.unit})
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {guide.rows.map((r) => (
                  <tr key={r.size} className="border-b border-line">
                    <th scope="row" className="py-3 pr-4 font-medium">
                      {r.size}
                    </th>
                    {r.values.map((v, i) => (
                      <td key={i} className="py-3 pr-4 tabular-nums text-muted">
                        {v}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {guide.note && <p className="mt-4 text-sm text-muted">{guide.note}</p>}
          </div>
        ) : (
          <div className="mt-8 max-w-lg space-y-4 text-muted">
            <p>Garment measurements have not been supplied yet, so we can’t show a size chart.</p>
            <p className="text-sm text-smoke">
              Pending from the client: chest, length, shoulder and sleeve measurements for each size, the unit (cm or inches) and a fit
              note.
            </p>
          </div>
        )}
      </div>
    </Modal>
  );
}
