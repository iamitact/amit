import { useState } from 'react';
import { FLAGSHIP_ID, formatPrice, productById, renderSrc, type Size } from '../content/products';
import { useCart } from '../state/cart';
import { SizeSelector } from './SizeSelector';

const flagship = productById(FLAGSHIP_ID)!;

const GALLERY = [
  { name: flagship.image, kind: 'portrait' as const, alt: flagship.imageAlt, label: 'Front' },
  { name: 'detail-collar', kind: 'landscape' as const, alt: 'Close-up of the rib collar with tonal tipping.', label: 'Collar' },
  { name: 'detail-buttons', kind: 'landscape' as const, alt: 'Close-up of the placket and its two dished buttons.', label: 'Placket' },
  { name: 'detail-emblem', kind: 'landscape' as const, alt: 'Macro of the embroidered Dial emblem on black piqué.', label: 'Dial' },
  { name: 'detail-hem', kind: 'landscape' as const, alt: 'Close-up of the hem band and piqué texture.', label: 'Hem' },
];

export function Reserve() {
  const { add, open } = useCart();
  const [view, setView] = useState(0);
  const [size, setSize] = useState<Size | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [added, setAdded] = useState<string | null>(null);

  return (
    <section id="reserve" aria-labelledby="reserve-title" className="scroll-mt-16 border-t border-line bg-coal px-4 py-24 sm:px-8 md:py-32">
      <div className="mx-auto grid max-w-[1500px] gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-7">
          <div className="relative aspect-[4/5] overflow-hidden bg-ink md:aspect-[5/4]">
            {GALLERY.map((g, i) => {
              const img = renderSrc(g.name, g.kind);
              return (
                <img
                  key={g.name}
                  src={img.src}
                  srcSet={img.srcSet}
                  sizes="(min-width: 1024px) 55vw, 100vw"
                  width={img.width}
                  height={img.height}
                  loading="lazy"
                  alt={i === view ? g.alt : ''}
                  aria-hidden={i !== view}
                  className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${i === view ? 'opacity-100' : 'opacity-0'}`}
                />
              );
            })}
          </div>
          <div className="mt-3 grid grid-cols-5 gap-2" role="group" aria-label="Product images">
            {GALLERY.map((g, i) => (
              <button
                key={g.name}
                type="button"
                onClick={() => setView(i)}
                aria-pressed={view === i}
                aria-label={`Show ${g.label.toLowerCase()} image`}
                className={`group relative overflow-hidden border transition-colors ${view === i ? 'border-gold' : 'border-transparent hover:border-line-strong'}`}
              >
                <img
                  src={`${import.meta.env.BASE_URL}renders/${g.name}-${g.kind === 'portrait' ? 500 : 800}.webp`}
                  alt=""
                  width={160}
                  height={120}
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover"
                />
                <span className="label absolute bottom-1.5 left-2 text-[0.5625rem] text-ivory/90">{g.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5">
          <p className="label text-gold">Reserve · Collection XII</p>
          <h2 id="reserve-title" className="display mt-5 text-[clamp(3rem,5.4vw,5.2rem)]">
            The Nocturne Polo
          </h2>
          <p className="label mt-4 text-smoke">Black · {flagship.line}</p>
          <p className="mt-8 flex items-baseline gap-3 font-serif text-4xl">
            {formatPrice(flagship.price)}
            <span className="label text-[0.625rem] text-smoke">Demo price</span>
          </p>
          <p className="mt-6 max-w-lg text-muted">{flagship.description}</p>

          <form
            className="mt-10"
            onSubmit={(e) => {
              e.preventDefault();
              if (!size) {
                setError('Choose a size to reserve the Nocturne.');
                setAdded(null);
                return;
              }
              add(flagship.id, size);
              setAdded(`Size ${size} added to your bag.`);
              open();
            }}
          >
            <SizeSelector
              value={size}
              onChange={(s) => {
                setSize(s);
                setError(null);
              }}
              error={error}
              name="reserve-size"
            />
            <button type="submit" className="btn-gold mt-2 w-full">
              Reserve — add to bag
            </button>
            <p className="mt-4 text-sm text-muted" aria-live="polite">
              {added ?? 'Availability: this is a demo storefront, so stock isn’t tracked and nothing ships.'}
            </p>
          </form>

          <div className="mt-10 divide-y divide-line border-y border-line">
            {[
              { t: 'Fabric & care', b: 'Cotton piqué, mid-weight, with a rib-knit collar and hem band. Wash cold, inside out, and dry flat to keep the black deep. (Demo product copy.)' },
              { t: 'Fit', b: 'Regular fit with set-in shoulders and a slightly longer back hem. Take your usual size; size down for a closer line.' },
              { t: 'Shipping & returns', b: 'Not available: this storefront is a demo and does not take real orders.' },
            ].map((d) => (
              <details key={d.t} className="group">
                <summary className="label flex min-h-14 list-none items-center justify-between text-ivory [&::-webkit-details-marker]:hidden">
                  {d.t}
                  <span aria-hidden className="text-lg text-gold transition-transform duration-300 group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="pb-6 text-sm leading-relaxed text-muted">{d.b}</p>
              </details>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
