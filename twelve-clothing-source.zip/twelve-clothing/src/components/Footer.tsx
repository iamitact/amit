import type { MotionChoice } from '../hooks/useMotion';
import { NAV } from './Header';

/**
 * Footer adapted from the 21st.dev "Footer with Suite" pattern: small
 * uppercase link columns over an oversized full-width wordmark.
 */
export function Footer({ motion, onMotion, webgl }: { motion: MotionChoice; onMotion: (c: MotionChoice) => void; webgl: boolean }) {
  const year = new Date().getFullYear();
  const linkCls = 'label link-line py-1.5 text-[0.6875rem] text-ivory hover:text-gold';
  return (
    <footer id="contact" className="relative overflow-hidden border-t border-line bg-ink">
      <div className="mx-auto grid max-w-[1600px] gap-12 px-6 pb-8 pt-20 sm:px-10 md:grid-cols-4">
        <nav aria-label="Footer" className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">Explore</p>
          {NAV.map((n) => (
            <a key={n.href} href={n.href} className={linkCls}>
              {n.label}
            </a>
          ))}
        </nav>
        <div className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">House</p>
          <a href="#campaign" className={linkCls}>
            Lookbook
          </a>
          <a href="#house" className={linkCls}>
            About Twelve
          </a>
          <a href="#letters" className={linkCls}>
            Letters
          </a>
        </div>
        <div className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">Contact</p>
          <a href="mailto:studio@twelve-clothing.example" className={`${linkCls} normal-case tracking-[0.08em]`}>
            studio@twelve-clothing.example
          </a>
          <p className="mt-2 text-xs text-smoke">Placeholder address — replace before launch.</p>
        </div>
        <div className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">Motion</p>
          <div role="group" aria-label="Motion preference" className="flex flex-wrap gap-2">
            {(['system', 'full', 'reduced'] as const).map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={motion === c}
                onClick={() => onMotion(c)}
                className={`label min-h-11 border px-3 text-[0.625rem] transition-colors ${
                  motion === c ? 'border-gold text-gold' : 'border-line-strong text-muted hover:text-ivory'
                }`}
              >
                {c === 'system' ? 'Auto' : c === 'full' ? '3D motion' : 'Still'}
              </button>
            ))}
          </div>
          {!webgl && <p className="mt-3 text-xs text-smoke">3D is unavailable in this browser; still images are shown.</p>}
        </div>
      </div>

      <p
        aria-hidden
        className="display select-none whitespace-nowrap px-2 text-center font-medium leading-[0.8] tracking-[-0.02em] text-ivory"
        style={{ fontSize: 'clamp(1.5rem, 10.4vw, 12.5rem)' }}
      >
        TWELVE CLOTHING
      </p>

      <div className="mx-auto mt-6 flex max-w-[1600px] flex-col gap-2 border-t border-line px-6 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-10">
        <p className="label text-[0.625rem] text-smoke">© {year} Twelve Clothing · Dressed for the twelfth hour</p>
        <p className="label text-[0.625rem] text-smoke">Demo storefront · Illustrative products and prices</p>
      </div>
    </footer>
  );
}
