import type { MotionChoice } from '../hooks/useMotion';
import { business, isSampleCatalogue } from '../site/catalog';
import { href } from '../site/paths';
import { NAV } from './Header';
import { Fact } from './Pending';

/**
 * Footer adapted from the 21st.dev "Footer with Suite" pattern: small
 * uppercase link columns over an oversized full-width wordmark. Business facts
 * come only from src/data/business.json — nothing is shown that the client has
 * not supplied.
 */
export function Footer({ motion, onMotion, webgl }: { motion: MotionChoice; onMotion: (c: MotionChoice) => void; webgl: boolean }) {
  const year = new Date().getFullYear();
  const linkCls = 'label link-line py-1.5 text-[0.6875rem] text-ivory hover:text-gold';
  const social = Object.entries(business.social).filter((e): e is [string, string] => !!e[1]);
  return (
    <footer className="relative overflow-hidden border-t border-line bg-ink">
      <div className="mx-auto grid max-w-[1600px] gap-12 px-6 pb-8 pt-20 sm:px-10 md:grid-cols-4">
        <nav aria-label="Footer" className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">Explore</p>
          <a href={href()} className={linkCls}>
            Home
          </a>
          {NAV.map((n) => (
            <a key={n.path} href={href(n.path)} className={linkCls}>
              {n.label}
            </a>
          ))}
        </nav>
        <div className="flex flex-col items-start gap-1 text-sm">
          <p className="label mb-3 text-[0.625rem] text-smoke">Visit</p>
          <Fact value={business.address.line1} pending="Address to be confirmed" />
          <Fact value={business.hours} pending="Opening hours to be confirmed" />
        </div>
        <div className="flex flex-col items-start gap-1 text-sm">
          <p className="label mb-3 text-[0.625rem] text-smoke">Contact</p>
          {business.email ? (
            <a href={`mailto:${business.email}`} className="link-line text-ivory">
              {business.email}
            </a>
          ) : (
            <Fact value={null} pending="Email to be confirmed" />
          )}
          {business.phone ? (
            <a href={`tel:${business.phone}`} className="link-line text-ivory">
              {business.phone}
            </a>
          ) : (
            <Fact value={null} pending="Phone to be confirmed" />
          )}
          {social.map(([name, url]) => (
            <a key={name} href={url} className="label link-line mt-2 text-[0.625rem] text-ivory" rel="noopener">
              {name}
            </a>
          ))}
        </div>
        <div className="flex flex-col items-start">
          <p className="label mb-4 text-[0.625rem] text-smoke">Motion</p>
          <div role="group" aria-label="Motion preference" className="flex flex-wrap gap-2">
            {(['system', 'full', 'reduced'] as const).map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={motion === c}
                onClick={() => onMotion(c)}
                className={`label min-h-11 border px-3 text-[0.625rem] transition-colors ${
                  motion === c ? 'border-gold text-gold' : 'border-line-strong text-muted hover:text-ivory'
                }`}
              >
                {c === 'system' ? 'Auto' : c === 'full' ? 'Full motion' : 'Reduced'}
              </button>
            ))}
          </div>
          {!webgl && <p className="mt-3 text-xs text-smoke">3D is unavailable in this browser; still images are shown.</p>}
        </div>
      </div>

      <p
        aria-hidden
        className="display select-none whitespace-nowrap px-2 text-center font-medium leading-[0.8] tracking-[-0.02em] text-ivory"
        style={{ fontSize: 'clamp(1.5rem, 10.4vw, 12.5rem)' }}
      >
        TWELVE CLOTHING
      </p>

      <div className="mx-auto mt-6 flex max-w-[1600px] flex-col gap-2 border-t border-line px-6 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-10">
        <p className="label text-[0.625rem] text-smoke">© {year} Twelve Clothing</p>
        <p className="label text-[0.625rem] text-smoke">
          {isSampleCatalogue ? 'Preview site · Products shown are concept renders · Online payment not yet active' : 'Online payment not yet active'}
        </p>
      </div>
    </footer>
  );
}
