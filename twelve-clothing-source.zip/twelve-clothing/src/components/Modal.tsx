import { useEffect, useRef, type ReactNode } from 'react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  labelledBy: string;
  variant: 'sheet' | 'center';
  children: ReactNode;
}

let openCount = 0;
const lockScroll = (lock: boolean) => {
  openCount = Math.max(0, openCount + (lock ? 1 : -1));
  document.documentElement.style.overflow = openCount > 0 ? 'hidden' : '';
};

/**
 * Native <dialog> wrapper: Escape, focus containment, focus return and an
 * inert background are handled by the browser. Clicking the backdrop closes it.
 */
export function Modal({ open, onClose, labelledBy, variant, children }: ModalProps) {
  const ref = useRef<HTMLDialogElement>(null);
  // closes we trigger ourselves must not be reported as the visitor dismissing it
  const programmatic = useRef(false);

  useEffect(() => {
    const d = ref.current;
    if (!d || !open) return;
    if (!d.open) d.showModal();
    lockScroll(true);
    return () => {
      lockScroll(false);
      if (d.open) {
        programmatic.current = true;
        d.close();
      }
    };
  }, [open]);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    // fired by Escape or d.close(); keep React state in sync
    const onNativeClose = () => {
      if (programmatic.current) {
        programmatic.current = false;
        return;
      }
      onClose();
    };
    d.addEventListener('close', onNativeClose);
    return () => d.removeEventListener('close', onNativeClose);
  }, [onClose]);

  const shell =
    variant === 'sheet'
      ? 'ml-auto mr-0 h-dvh max-h-dvh w-full max-w-md open:animate-[sheet-in_420ms_var(--ease-cinema)]'
      : 'm-auto max-h-[92dvh] w-[calc(100%-2rem)] max-w-5xl overflow-y-auto open:animate-[fade-up_360ms_var(--ease-cinema)]';

  return (
    <dialog
      ref={ref}
      aria-labelledby={labelledBy}
      className={`${shell} border border-line bg-coal p-0 text-ivory`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {children}
    </dialog>
  );
}
