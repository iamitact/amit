import { imageSource, priceLabel, type Product } from '../site/catalog';
import { href } from '../site/paths';

/**
 * Shop card. Hover or keyboard focus crossfades to the back view (when one
 * exists) with a slight zoom; the whole card is one link with a visible focus ring.
 */
export function ProductCard({ product, index = 0, sizes = '(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 90vw' }: { product: Product; index?: number; sizes?: string }) {
  const front = imageSource(product.images.front);
  const back = imageSource(product.images.back);
  return (
    <article className="card-enter" style={{ animationDelay: `${Math.min(index, 8) * 70}ms` }}>
      <a href={href(`shop/${product.slug}/`)} className="product-card group block focus-visible:outline-offset-4">
        <div className="relative aspect-[4/5] overflow-hidden bg-coal">
          {front && (
            <img
              src={front.src}
              srcSet={front.srcSet}
              sizes={sizes}
              width={front.width}
              height={front.height}
              loading={index < 3 ? 'eager' : 'lazy'}
              decoding="async"
              alt={`${product.name}, ${product.colour}${front.concept ? ' (3D concept render)' : ''}`}
              className="absolute inset-0 h-full w-full object-cover transition-[transform,opacity] duration-700 ease-[var(--ease-cinema)] group-hover:scale-[1.035] group-focus-visible:scale-[1.035]"
            />
          )}
          {back && (
            <img
              src={back.src}
              srcSet={back.srcSet}
              sizes={sizes}
              width={back.width}
              height={back.height}
              loading="lazy"
              decoding="async"
              alt=""
              aria-hidden
              className="absolute inset-0 h-full w-full object-cover opacity-0 transition-[transform,opacity] duration-700 ease-[var(--ease-cinema)] group-hover:scale-[1.035] group-hover:opacity-100 group-focus-visible:opacity-100"
            />
          )}
          {product.sample && (
            <span className="label absolute left-3 top-3 bg-ink/75 px-2 py-1 text-[0.5625rem] text-smoke backdrop-blur-sm">Concept piece</span>
          )}
          <span
            aria-hidden
            className="label absolute inset-x-3 bottom-3 translate-y-2 bg-ivory/95 py-3 text-center text-[0.625rem] text-on-gold opacity-0 transition-[opacity,transform] duration-300 group-hover:translate-y-0 group-hover:opacity-100 group-focus-visible:translate-y-0 group-focus-visible:opacity-100"
          >
            View piece
          </span>
        </div>
        <div className="mt-4 flex items-start justify-between gap-4">
          <div>
            <h3 className="font-serif text-2xl leading-tight transition-colors group-hover:text-gold">{product.name}</h3>
            <p className="label mt-1.5 text-[0.625rem] text-smoke">{product.colour}</p>
          </div>
          <p className={`shrink-0 pt-1 text-sm ${product.price === null ? 'text-smoke' : 'text-ivory'}`}>{priceLabel(product.price)}</p>
        </div>
      </a>
    </article>
  );
}
