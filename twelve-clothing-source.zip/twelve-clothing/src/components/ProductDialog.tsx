import { useState } from 'react';
import { formatPrice, productById, renderSrc, type Product, type Size } from '../content/products';
import { useCart } from '../state/cart';
import { CloseIcon } from './Icons';
import { Modal } from './Modal';
import { SizeSelector } from './SizeSelector';

export function ProductDialog({ productId, onClose }: { productId: string | null; onClose: () => void }) {
  const product = productId ? productById(productId) : undefined;
  return (
    <Modal open={!!product} onClose={onClose} labelledBy="product-dialog-title" variant="center">
      {/* keyed so size and error state reset per product */}
      {product && <ProductDetail key={product.id} product={product} onClose={onClose} />}
    </Modal>
  );
}

function ProductDetail({ product, onClose }: { product: Product; onClose: () => void }) {
  const { add, open } = useCart();
  const [size, setSize] = useState<Size | null>(null);
  const [error, setError] = useState<string | null>(null);
  const img = renderSrc(product.image, 'portrait');

  return (
    <div className="grid md:grid-cols-2">
      <img
        src={img.src}
        srcSet={img.srcSet}
        sizes="(min-width: 768px) 32rem, 100vw"
        width={img.width}
        height={img.height}
        alt={product.imageAlt}
        className="aspect-[4/5] w-full bg-ink object-cover"
      />
      <div className="relative flex flex-col p-6 sm:p-10">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 flex h-11 w-11 items-center justify-center text-muted hover:text-ivory"
          aria-label="Close product details"
        >
          <CloseIcon />
        </button>
        <p className="label text-gold">{product.line}</p>
        <h2 id="product-dialog-title" className="display mt-3 pr-10 text-5xl">
          {product.name}
        </h2>
        <p className="label mt-3 text-smoke">{product.colorway}</p>
        <p className="mt-6 font-serif text-3xl">
          {formatPrice(product.price)}{' '}
          <span className="label ml-2 align-middle text-[0.625rem] text-smoke">Demo price</span>
        </p>
        <p className="mt-5 text-muted">{product.description}</p>
        <ul className="mt-5 space-y-1.5 text-sm text-muted">
          {product.details.map((d) => (
            <li key={d} className="flex gap-3">
              <span aria-hidden className="mt-2.5 h-px w-3 shrink-0 bg-gold" />
              {d}
            </li>
          ))}
        </ul>
        <form
          className="mt-8"
          onSubmit={(e) => {
            e.preventDefault();
            if (!size) {
              setError('Choose a size to add this piece to your bag.');
              return;
            }
            add(product.id, size);
            onClose();
            open();
          }}
        >
          <SizeSelector
            value={size}
            onChange={(s) => {
              setSize(s);
              setError(null);
            }}
            error={error}
            name={`size-${product.id}`}
          />
          <button type="submit" className="btn-gold mt-2 w-full">
            Add to bag · {formatPrice(product.price)}
          </button>
          <p className="mt-4 text-xs leading-relaxed text-smoke">Demo storefront: stock is not tracked and no order is placed.</p>
        </form>
      </div>
    </div>
  );
}
