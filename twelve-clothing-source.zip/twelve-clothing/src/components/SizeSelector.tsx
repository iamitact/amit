import { useId } from 'react';

interface Props {
  sizes: string[];
  value: string | null;
  onChange: (s: string) => void;
  error?: string | null;
  name?: string;
  hint?: string;
}

/** Native radio group styled as size tiles: arrow keys, labels and focus come for free. */
export function SizeSelector({ sizes, value, onChange, error, name, hint }: Props) {
  const id = useId();
  const errId = `${id}-err`;
  return (
    <fieldset aria-describedby={error ? errId : undefined}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <legend className="label text-ivory">Size</legend>
        {hint && <span className="label text-[0.625rem] text-smoke">{hint}</span>}
      </div>
      <div className="mt-4 grid gap-2" style={{ gridTemplateColumns: `repeat(${Math.min(sizes.length, 6)}, minmax(0, 1fr))` }}>
        {sizes.map((s) => (
          <label key={s} className="relative">
            <input
              type="radio"
              name={name ?? id}
              value={s}
              checked={value === s}
              onChange={() => onChange(s)}
              aria-invalid={error ? true : undefined}
              className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0"
            />
            <span className="flex h-12 items-center justify-center border border-line-strong text-sm font-medium text-ivory transition-colors duration-200 peer-hover:border-ivory peer-checked:border-gold peer-checked:bg-gold peer-checked:text-on-gold peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-gold">
              {s}
            </span>
          </label>
        ))}
      </div>
      <p id={errId} role="alert" className="mt-3 min-h-5 text-sm text-error">
        {error ?? ''}
      </p>
    </fieldset>
  );
}
