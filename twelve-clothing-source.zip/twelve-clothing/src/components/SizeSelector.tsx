import { useId } from 'react';
import { SIZES, type Size } from '../content/products';

interface Props {
  value: Size | null;
  onChange: (s: Size) => void;
  error?: string | null;
  name?: string;
}

/** Native radio group styled as size tiles: arrow keys, labels and focus come for free. */
export function SizeSelector({ value, onChange, error, name }: Props) {
  const id = useId();
  const errId = `${id}-err`;
  return (
    <fieldset aria-describedby={error ? errId : undefined}>
      <div className="flex items-baseline justify-between">
        <legend className="label text-ivory">Size</legend>
        <span className="label text-[0.625rem] text-smoke">Regular fit · take your usual size</span>
      </div>
      <div className="mt-4 grid grid-cols-6 gap-2">
        {SIZES.map((s) => (
          <label key={s} className="relative">
            <input
              type="radio"
              name={name ?? id}
              value={s}
              checked={value === s}
              onChange={() => onChange(s)}
              aria-invalid={error ? true : undefined}
              className="peer absolute inset-0 h-full w-full cursor-pointer opacity-0"
            />
            <span className="flex h-12 items-center justify-center border border-line-strong text-sm font-medium text-ivory transition-colors duration-200 peer-hover:border-ivory peer-checked:border-gold peer-checked:bg-gold peer-checked:text-on-gold peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-gold">
              {s}
            </span>
          </label>
        ))}
      </div>
      <p id={errId} role="alert" className="mt-3 min-h-5 text-sm text-error">
        {error ?? ''}
      </p>
    </fieldset>
  );
}
