import { useEffect, useRef, useState, type ReactNode } from 'react';

/**
 * Entrance when a block scrolls into view: 'fade' (fade + 12px rise) or
 * 'image' (a clip-path unveil from the bottom). Shown immediately under
 * reduced motion — the global motion rules in index.css also neutralise it.
 */
export function Reveal({
  children,
  className = '',
  delay = 0,
  variant = 'fade',
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  variant?: 'fade' | 'image';
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (document.documentElement.dataset.motion === 'reduced') {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: '0px 0px -8% 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const hidden = variant === 'image' ? 'reveal-image' : 'translate-y-3 opacity-0';
  const visible = variant === 'image' ? 'reveal-image is-shown' : 'translate-y-0 opacity-100';
  return (
    <div
      ref={ref}
      className={`transition-[opacity,transform,clip-path] duration-[1000ms] ease-[var(--ease-cinema)] ${shown ? visible : hidden} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}
