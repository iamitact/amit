import type { CSSProperties } from 'react';
import { imageSource, photoAlt, photoSlots } from '../site/catalog';

interface PhotoProps {
  /** A slot id from src/data/photos.json, or a direct image reference ('photo:…' / 'render:…'). */
  slot?: string;
  src?: string | null;
  alt: string;
  /** Aspect ratio reserved before the image loads (prevents layout shift). */
  ratio?: string;
  sizes?: string;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
  /** Subtle scroll parallax (CSS scroll-driven; off under reduced motion). */
  parallax?: boolean;
  /** Show the "Concept render" caption when a render stands in for a photo. */
  captionConcept?: boolean;
  /** Where the "Concept render" caption sits (keep it clear of overlaid text). */
  captionPosition?: 'bottom-left' | 'top-right';
  style?: CSSProperties;
}

/**
 * Renders a real photograph when the client has supplied one, otherwise a
 * clearly captioned 3D concept render, otherwise a labelled placeholder with
 * the same proportions — so pages never shift when photos arrive.
 */
export function Photo({
  slot,
  src,
  alt,
  ratio = '4 / 5',
  sizes = '100vw',
  className = '',
  imgClassName = '',
  eager,
  parallax,
  captionConcept = true,
  captionPosition = 'bottom-left',
  style,
}: PhotoProps) {
  const slotDef = slot ? photoSlots[slot] : undefined;
  const ref = src ?? slotDef?.image ?? slotDef?.concept ?? null;
  const img = imageSource(ref);

  if (!img) {
    return (
      <figure className={`relative overflow-hidden border border-dashed border-line-strong bg-coal ${className}`} style={{ aspectRatio: ratio, ...style }}>
        <figcaption className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-6 text-center">
          <span className="label text-[0.625rem] text-gold">Client photo pending</span>
          <span className="max-w-xs text-xs leading-relaxed text-smoke">{slotDef?.need ?? alt}</span>
        </figcaption>
      </figure>
    );
  }

  const altText = (ref && photoAlt(ref)) || alt;
  return (
    <figure className={`relative overflow-hidden bg-coal ${className}`} style={{ aspectRatio: ratio, ...style }}>
      <picture>
        {img.sources.map((s) => (
          <source key={s.type} type={s.type} srcSet={s.srcSet} sizes={sizes} />
        ))}
        <img
          src={img.src}
          srcSet={img.srcSet}
          sizes={sizes}
          width={img.width}
          height={img.height}
          alt={img.concept ? `${altText} (3D concept render)` : altText}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          fetchPriority={eager ? 'high' : undefined}
          className={`h-full w-full object-cover ${parallax ? 'parallax-img' : ''} ${imgClassName}`}
        />
      </picture>
      {img.concept && captionConcept && (
        <figcaption className={`label pointer-events-none absolute z-10 ${captionPosition === 'top-right' ? 'right-3 top-20' : 'bottom-3 left-3'} bg-ink/70 px-2 py-1 text-[0.5625rem] text-smoke backdrop-blur-sm`}>
          Concept render
        </figcaption>
      )}
    </figure>
  );
}
