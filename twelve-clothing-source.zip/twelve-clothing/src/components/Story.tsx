import { useEffect, useRef, useState } from 'react';
import { CALLOUTS, CALLOUT_WINDOW, CHAPTERS, STORY_ANCHORS, type Chapter } from '../content/story';
import { FLAGSHIP_ID, formatPrice, productById, renderSrc } from '../content/products';
import { ArrowDownIcon, ArrowRightIcon } from './Icons';

const flagship = productById(FLAGSHIP_ID)!;

interface StoryProps {
  mode: 'live' | 'still';
  onWebGLFail: () => void;
  onEnableMotion?: () => void;
}

export function Story({ mode, onWebGLFail, onEnableMotion }: StoryProps) {
  return mode === 'live' ? <LiveStory onFail={onWebGLFail} /> : <StillStory onEnableMotion={onEnableMotion} />;
}

// ------------------------------------------------------------------- live

function LiveStory({ onFail }: { onFail: () => void }) {
  const trigger = useRef<HTMLElement>(null);
  const host = useRef<HTMLDivElement>(null);
  const chapterRefs = useRef<(HTMLDivElement | null)[]>([]);
  const calloutRefs = useRef<(HTMLDivElement | null)[]>([]);
  const progress = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let dispose: (() => void) | undefined;
    let cancelled = false;
    import('../three/story')
      .then(({ mountStory }) => {
        if (cancelled || !host.current || !trigger.current) return;
        dispose = mountStory({
          host: host.current,
          trigger: trigger.current,
          chapters: CHAPTERS.map((c, i) => ({ el: chapterRefs.current[i]!, at: c.at, span: c.span })),
          callouts: CALLOUTS.map((c, i) => ({ el: calloutRefs.current[i]!, anchor: c.anchor })),
          calloutWindow: CALLOUT_WINDOW,
          progressBar: progress.current,
          onReady: () => setReady(true),
          onFail: () => onFail(),
        });
      })
      .catch(() => onFail());
    return () => {
      cancelled = true;
      dispose?.();
    };
  }, [onFail]);

  const poster = renderSrc('story-hero', 'landscape');

  return (
    <section
      id="story"
      ref={trigger}
      aria-label="The Nocturne Polo, from silhouette to stitch"
      className="relative h-[760svh] md:h-[820svh]"
    >
      {STORY_ANCHORS.map((a) => (
        <div
          key={a.id}
          id={a.id}
          aria-hidden
          className="pointer-events-none absolute left-0 h-px w-px"
          style={{ top: `calc((100% - 100svh) * ${a.at})` }}
        />
      ))}

      <div className="sticky top-0 h-svh overflow-hidden">
        <img
          src={poster.src}
          srcSet={poster.srcSet}
          sizes="100vw"
          alt=""
          aria-hidden
          fetchPriority="high"
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${ready ? 'opacity-0' : 'opacity-100'}`}
        />
        <div ref={host} className="pointer-events-none absolute inset-0" />
        {/* legibility vignettes; never intercept taps */}
        <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-ink via-ink/40 to-transparent md:h-1/3" />
        <div aria-hidden className="pointer-events-none absolute inset-y-0 left-0 hidden w-1/2 bg-gradient-to-r from-ink/70 to-transparent md:block" />

        <div className="pointer-events-none absolute inset-0">
          {CHAPTERS.map((c, i) => (
            <div
              key={c.id}
              ref={(el) => {
                chapterRefs.current[i] = el;
              }}
              aria-hidden={c.layout !== 'hero' || undefined}
              className="absolute inset-0 will-change-[opacity,transform]"
              style={{ opacity: i === 0 ? 1 : 0, visibility: i === 0 ? 'visible' : 'hidden' }}
            >
              <ChapterOverlay chapter={c} />
            </div>
          ))}
        </div>

        <div aria-hidden className="pointer-events-none absolute inset-0">
          {CALLOUTS.map((c, i) => (
            <div
              key={c.anchor}
              ref={(el) => {
                calloutRefs.current[i] = el;
              }}
              className={`group absolute left-0 top-0 ${c.mobile ? '' : 'hidden md:block'}`}
              style={{ visibility: 'hidden' }}
            >
              <span className="absolute -left-[3px] -top-[3px] h-[7px] w-[7px] rounded-full bg-gold shadow-[0_0_0_4px_rgba(216,192,142,0.18)]" />
              <span className="absolute top-0 left-2 h-px w-5 bg-gold/60 group-data-[side=left]:left-auto group-data-[side=left]:right-2 md:w-8" />
              <span data-label className="label absolute -top-[0.55rem] left-8 w-max max-w-[8.5rem] text-[0.625rem] leading-snug text-ivory group-data-[side=left]:left-auto group-data-[side=left]:right-8 group-data-[side=left]:text-right md:left-12 md:max-w-none md:whitespace-nowrap md:text-[0.6875rem] md:group-data-[side=left]:right-12">
                {c.label}
              </span>
            </div>
          ))}
        </div>

        {/* progress rail */}
        <div aria-hidden className="pointer-events-none absolute right-5 top-1/2 hidden h-[34vh] -translate-y-1/2 md:block">
          <div className="relative h-full w-px bg-line">
            <div ref={progress} className="absolute inset-0 origin-top bg-gold" style={{ transform: 'scaleY(0)' }} />
          </div>
        </div>
      </div>

      <div className="sr-only">
        {CHAPTERS.slice(1).map((c) => (
          <div key={c.id}>
            <h3>{c.kicker}: {c.title}</h3>
            {c.body && <p>{c.body}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

function ChapterOverlay({ chapter: c }: { chapter: Chapter }) {
  if (c.layout === 'hero') return <HeroOverlay chapter={c} />;
  if (c.layout === 'finale') {
    return (
      <div className="absolute inset-x-0 bottom-[9svh] px-6 sm:px-10 md:bottom-auto md:left-[6vw] md:top-1/2 md:right-auto md:max-w-[46vw] md:-translate-y-1/2 md:px-0">
        <p className="label mb-5 text-gold">{c.kicker}</p>
        <h2 className="display text-[clamp(2.9rem,7.4vw,7.6rem)] text-ivory">
          Nothing loud.
          <br />
          <em className="font-normal italic text-ivory/80">Everything considered.</em>
        </h2>
        <div className="pointer-events-auto mt-9 flex flex-wrap gap-3">
          <a href="#reserve" tabIndex={-1} className="btn-gold">
            Reserve · {formatPrice(flagship.price)}
          </a>
          <a href="#collection" tabIndex={-1} className="btn-ghost">
            The collection
          </a>
        </div>
      </div>
    );
  }
  const right = c.layout === 'right';
  return (
    <div
      className={`absolute inset-x-0 bottom-[7svh] isolate px-6 sm:px-10 md:bottom-auto md:top-1/2 md:w-[min(30rem,34vw)] md:-translate-y-1/2 md:px-0 ${
        right ? 'md:left-auto md:right-[7vw]' : 'md:left-[6vw] md:right-auto'
      }`}
    >
      {/* soft pool of darkness so copy stays legible over macro texture */}
      <div aria-hidden className="absolute -inset-x-10 -inset-y-12 -z-10 bg-[radial-gradient(closest-side,rgba(10,10,11,0.82),rgba(10,10,11,0.5)_60%,transparent)] md:-inset-x-24 md:-inset-y-24" />
      <p className="label mb-4 text-gold">{c.kicker}</p>
      <h2 className="display text-[clamp(2.2rem,4.6vw,4.4rem)] text-ivory">{c.title}</h2>
      {c.body && <p className="mt-5 max-w-md text-[0.95rem] leading-relaxed text-muted md:text-base">{c.body}</p>}
    </div>
  );
}

function HeroOverlay({ chapter: c }: { chapter: Chapter }) {
  return (
    <>
      <div className="absolute inset-x-0 top-[17svh] text-center md:top-[15svh]">
        <p className="label text-smoke">
          Twelve Clothing <span className="mx-3 text-gold">·</span> {c.kicker}
        </p>
      </div>
      <h1 className="display absolute inset-x-0 top-[23svh] text-center text-[clamp(4.6rem,15vw,13.5rem)] tracking-[0.02em] text-ivory/95 [text-shadow:0_2px_40px_rgba(0,0,0,0.6)] md:top-[21svh]">
        {c.title}
      </h1>
      <p className="label absolute left-6 top-1/2 hidden -translate-y-1/2 text-smoke md:left-[6vw] md:block">Black piqué polo</p>
      <p className="label absolute right-6 top-1/2 hidden -translate-y-1/2 text-smoke md:right-[6vw] md:block">No. XII — 01</p>

      <div className="absolute inset-x-0 bottom-[6svh] flex flex-col items-center gap-6 px-6 text-center">
        <p className="font-serif text-2xl italic text-ivory md:text-3xl">{c.body}</p>
        <div className="pointer-events-auto flex flex-wrap justify-center gap-3">
          <a href="#reserve" className="btn-gold">
            Reserve · {formatPrice(flagship.price)}
          </a>
          <a href="#silhouette" className="btn-ghost">
            Explore <ArrowDownIcon size={16} />
          </a>
        </div>
        <span className="label flex items-center gap-3 text-[0.625rem] text-smoke">
          <span className="relative block h-8 w-px overflow-hidden bg-line">
            <span className="absolute inset-x-0 top-0 h-3 animate-[cue_2.4s_var(--ease-cinema)_infinite] bg-gold" />
          </span>
          Scroll
        </span>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ still

function StillStory({ onEnableMotion }: { onEnableMotion?: () => void }) {
  const [hero, silhouette, construction, ...rest] = CHAPTERS;
  const details = rest.filter((c) => c.layout !== 'finale');
  const heroImg = renderSrc(hero.still, 'landscape');
  return (
    <section id="story" aria-label="The Nocturne Polo, from silhouette to stitch">
      <div className="relative flex min-h-svh flex-col justify-between overflow-hidden pb-[6svh] pt-[15svh]">
        <img
          src={heroImg.src}
          srcSet={heroImg.srcSet}
          sizes="100vw"
          width={heroImg.width}
          height={heroImg.height}
          alt={hero.stillAlt}
          fetchPriority="high"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div aria-hidden className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-ink to-transparent" />
        <div className="relative px-6 text-center">
          <p className="label text-smoke">
            Twelve Clothing <span className="mx-3 text-gold">·</span> {hero.kicker}
          </p>
          <h1 className="display mt-4 text-[clamp(4.6rem,15vw,13.5rem)] text-ivory/95 [text-shadow:0_2px_40px_rgba(0,0,0,0.6)]">{hero.title}</h1>
        </div>
        <div className="relative px-6 text-center">
          <p className="font-serif text-2xl italic md:text-3xl">{hero.body}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href="#reserve" className="btn-gold">
              Reserve · {formatPrice(flagship.price)}
            </a>
            <a href="#silhouette" className="btn-ghost">
              Explore <ArrowDownIcon size={16} />
            </a>
          </div>
          {onEnableMotion && (
            <button type="button" onClick={onEnableMotion} className="label link-line mt-8 py-2 text-smoke hover:text-ivory">
              Still images shown · Turn on 3D motion
            </button>
          )}
        </div>
      </div>

      {[silhouette, construction].map((c, i) => {
        const img = renderSrc(c.still, 'landscape');
        return (
          <article key={c.id} id={c.id} className="grid items-center gap-10 px-6 py-20 sm:px-10 md:grid-cols-12 md:py-28">
            <img
              src={img.src}
              srcSet={img.srcSet}
              sizes="(min-width: 768px) 60vw, 100vw"
              width={img.width}
              height={img.height}
              loading="lazy"
              alt={c.stillAlt}
              className={`w-full md:col-span-7 ${i % 2 ? 'md:order-2' : ''}`}
            />
            <div className={`md:col-span-5 ${i % 2 ? 'md:order-1' : ''}`}>
              <p className="label mb-4 text-gold">{c.kicker}</p>
              <h2 className="display text-[clamp(2.4rem,4.6vw,4.4rem)]">{c.title}</h2>
              <p className="mt-5 max-w-md text-muted">{c.body}</p>
              {c.id === 'construction' && (
                <ul className="mt-8 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {CALLOUTS.map((co) => (
                    <li key={co.anchor} className="label flex items-center gap-3 text-[0.625rem] text-ivory">
                      <span className="h-1.5 w-1.5 rounded-full bg-gold" aria-hidden />
                      {co.label}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </article>
        );
      })}

      <div id="details" className="px-6 pb-24 sm:px-10">
        <div className="grid gap-x-10 gap-y-16 md:grid-cols-2">
          {details.map((c) => {
            const img = renderSrc(c.still, 'landscape');
            return (
              <article key={c.id}>
                <img
                  src={img.src}
                  srcSet={img.srcSet}
                  sizes="(min-width: 768px) 50vw, 100vw"
                  width={img.width}
                  height={img.height}
                  loading="lazy"
                  alt={c.stillAlt}
                  className="w-full"
                />
                <p className="label mb-3 mt-6 text-gold">{c.kicker}</p>
                <h3 className="display text-[clamp(2rem,3.2vw,3rem)]">{c.title}</h3>
                <p className="mt-4 max-w-md text-muted">{c.body}</p>
              </article>
            );
          })}
        </div>
        <div className="mt-24 border-t border-line pt-16">
          <p className="display text-[clamp(2.9rem,7.4vw,7.6rem)]">
            Nothing loud.
            <br />
            <em className="font-normal italic text-ivory/80">Everything considered.</em>
          </p>
          <a href="#reserve" className="btn-gold mt-9">
            Reserve · {formatPrice(flagship.price)} <ArrowRightIcon size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
