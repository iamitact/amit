import { publicUrl } from '../site/paths';

/**
 * Lightweight drifting mist for the still (no-WebGL) experience: three layers
 * of one pre-rendered translucent WebP, moved only with compositor-friendly
 * transforms. It never runs full-screen: it sits in the lower part of a hero.
 * Hidden under reduced motion (see .mist rules in index.css).
 */
export function Mist({ className = '' }: { className?: string }) {
  const url = `url("${publicUrl('fx/mist.webp')}")`;
  return (
    <div aria-hidden className={`mist pointer-events-none absolute inset-x-0 bottom-0 h-[55%] overflow-hidden ${className}`}>
      <div className="mist-layer mist-a" style={{ backgroundImage: url }} />
      <div className="mist-layer mist-b" style={{ backgroundImage: url }} />
      <div className="mist-layer mist-c" style={{ backgroundImage: url }} />
    </div>
  );
}
