import { useCallback, useEffect, useLayoutEffect, useState } from 'react';

export type MotionChoice = 'system' | 'full' | 'reduced';
const KEY = 'twelve-motion';

function readChoice(): MotionChoice {
  try {
    const v = localStorage.getItem(KEY);
    return v === 'full' || v === 'reduced' ? v : 'system';
  } catch {
    return 'system';
  }
}

/**
 * Motion preference: the OS setting unless the visitor overrides it in the
 * footer. When reduced, the site shows the still, fully readable story instead
 * of the scroll-driven 3D sequence.
 */
export function useMotion() {
  const query = '(prefers-reduced-motion: reduce)';
  const [systemReduced, setSystemReduced] = useState(() => window.matchMedia(query).matches);
  const [choice, setChoiceState] = useState<MotionChoice>(readChoice);

  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setSystemReduced(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const setChoice = useCallback((c: MotionChoice) => {
    setChoiceState(c);
    try {
      if (c === 'system') localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, c);
    } catch {
      /* ignore */
    }
  }, []);

  const reduced = choice === 'reduced' || (choice === 'system' && systemReduced);
  // mirrored on <html> so CSS-driven motion (mist, parallax, reveals, page
  // transitions) follows the same preference as the 3D scenes
  useLayoutEffect(() => {
    document.documentElement.dataset.motion = reduced ? 'reduced' : 'full';
  }, [reduced]);
  return { reduced, choice, setChoice, systemReduced };
}

/** True when a WebGL context can be created (checked once). */
let webglCache: boolean | null = null;
export function hasWebGL() {
  if (webglCache !== null) return webglCache;
  // ?webgl=0 previews the fallback experience
  if (new URLSearchParams(location.search).get('webgl') === '0') return (webglCache = false);
  try {
    const c = document.createElement('canvas');
    webglCache = !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    webglCache = false;
  }
  return webglCache;
}
