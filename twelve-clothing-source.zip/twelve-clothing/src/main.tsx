import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './fonts/fonts.css';
import './index.css';
import App from './App';
import { currentPage } from './site/paths';

const page = currentPage();
// keeps titles right in development, where every URL is served by one index.html
document.title = page.title;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App page={page} />
  </StrictMode>,
);
