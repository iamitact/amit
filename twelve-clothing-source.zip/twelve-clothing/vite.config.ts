import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { allPages, type PageDef } from './src/site/pages';

/**
 * Public URL of the deployed site. Used only for absolute links that must be
 * absolute (canonical, Open Graph, sitemap) and for the 404 page, which GitHub
 * Pages serves at arbitrary depths. Override when the repository or domain changes:
 *   SITE_URL=https://example.com/ npm run build
 */
const SITE_URL = (process.env.SITE_URL ?? 'https://iamitact.github.io/amit/').replace(/\/?$/, '/');
const SITE_BASE = new URL(SITE_URL).pathname; // '/amit/'

const escapeAttr = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

function withPageMeta(html: string, page: PageDef, rootRef: string, assetPrefix: string) {
  const url = SITE_URL + page.path;
  let out = html
    .replace(/(src|href)="\.\//g, `$1="${assetPrefix}`)
    .replace(/<title>[^<]*<\/title>/, `<title>${escapeAttr(page.title)}</title>`)
    .replace(/<meta name="description" content="[^"]*"/, `<meta name="description" content="${escapeAttr(page.description)}"`)
    .replace(/<meta property="og:title" content="[^"]*"/, `<meta property="og:title" content="${escapeAttr(page.title)}"`)
    .replace(/<meta property="og:description" content="[^"]*"/, `<meta property="og:description" content="${escapeAttr(page.description)}"`)
    .replace(/<meta property="og:image" content="[^"]*"/, `<meta property="og:image" content="${SITE_URL}renders/story-hero-1600.webp"`);
  // the hero poster is only worth preloading where the 3D hero appears
  if (page.route !== 'home' && page.route !== 'story') out = out.replace(/\s*<link rel="preload" as="image"[^>]*>/, '');
  const head = [
    `<meta name="twelve-root" content="${rootRef}" />`,
    page.route === 'notfound' ? '<meta name="robots" content="noindex" />' : `<link rel="canonical" href="${url}" />`,
    page.route === 'notfound' ? '' : `<meta property="og:url" content="${url}" />`,
  ].join('\n    ');
  return out.replace('</head>', `    ${head}\n  </head>`);
}

/**
 * Writes one real index.html per page (shop/, shop/<slug>/, about/, …) so every
 * URL loads directly and survives a refresh on static hosting, plus 404.html,
 * sitemap.xml and robots.txt. Asset URLs stay relative (base './').
 */
function staticPages(): Plugin {
  return {
    name: 'twelve-static-pages',
    apply: 'build',
    enforce: 'post',
    generateBundle(_options, bundle) {
      const index = bundle['index.html'];
      if (!index || index.type !== 'asset') return;
      const template = String(index.source);
      for (const page of allPages()) {
        const depth = page.path.split('/').filter(Boolean).length;
        const up = depth ? '../'.repeat(depth) : './';
        const html = withPageMeta(template, page, up, up);
        if (page.path === '') index.source = html;
        else this.emitFile({ type: 'asset', fileName: `${page.path}index.html`, source: html });
      }
      const notFound = withPageMeta(
        template,
        { path: '404.html', route: 'notfound', title: 'Page not found — Twelve Clothing', description: 'This page does not exist.' },
        SITE_BASE,
        SITE_BASE,
      ).replace('<html lang="en">', `<html lang="en" data-root="${SITE_BASE}" data-page="404">`);
      this.emitFile({ type: 'asset', fileName: '404.html', source: notFound });

      const urls = allPages()
        .filter((p) => p.route !== 'bag')
        .map((p) => `  <url><loc>${SITE_URL}${p.path}</loc></url>`)
        .join('\n');
      this.emitFile({
        type: 'asset',
        fileName: 'sitemap.xml',
        source: `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`,
      });
      this.emitFile({ type: 'asset', fileName: 'robots.txt', source: `User-agent: *\nAllow: /\nSitemap: ${SITE_URL}sitemap.xml\n` });
    },
  };
}

// Production uses relative asset URLs ('./'), rewritten per page depth by
// staticPages(); development serves from '/'.
export default defineConfig(({ command }) => ({
  base: command === 'build' ? './' : '/',
  plugins: [react(), tailwindcss(), staticPages()],
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 900,
  },
}));
