/**
 * Renders public/fx/mist.webp: a translucent, horizontally tileable band of soft
 * mist used by the still (no-WebGL) hero. Drawn with the 2D canvas in a headless
 * browser so the output is identical on every machine (seeded randomness).
 *
 *   npm run render:fx            (uses installed Microsoft Edge)
 */
import { chromium } from 'playwright-core';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const browser = await chromium.launch({ channel: process.env.BROWSER_CHANNEL || 'msedge' });
const page = await browser.newPage();
const dataUrl = await page.evaluate(() => {
  const W = 1200;
  const H = 320;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const ctx = c.getContext('2d');
  let seed = 1212;
  const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  // puffs are drawn three times (x - W, x, x + W) so the band tiles seamlessly
  for (let i = 0; i < 200; i++) {
    const x = rand() * W;
    const band = Math.pow(rand(), 0.55); // denser towards the floor
    const y = H - band * H * 0.8;
    const r = 30 + rand() * 110 * (0.4 + band);
    const a = 0.035 + rand() * 0.06 * (1.2 - band * 0.6);
    for (const dx of [-W, 0, W]) {
      const g = ctx.createRadialGradient(x + dx, y, 0, x + dx, y, r);
      g.addColorStop(0, `rgba(170,176,186,${a})`);
      g.addColorStop(1, 'rgba(170,176,186,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(x + dx, y, r * 1.8, r, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  // fade the top edge so the band dissolves upward
  const fade = ctx.createLinearGradient(0, 0, 0, H);
  fade.addColorStop(0, 'rgba(0,0,0,1)');
  fade.addColorStop(0.45, 'rgba(0,0,0,0)');
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = fade;
  ctx.fillRect(0, 0, W, H);
  return c.toDataURL('image/webp', 0.7);
});
await mkdir(path.join(root, 'public', 'fx'), { recursive: true });
await writeFile(path.join(root, 'public', 'fx', 'mist.webp'), Buffer.from(dataUrl.split(',')[1], 'base64'));
console.log('wrote public/fx/mist.webp');
await browser.close();
