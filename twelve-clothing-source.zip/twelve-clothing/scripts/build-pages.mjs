/**
 * Builds the site and publishes the static files into the parent folder, the
 * repository root, so GitHub Pages can serve them directly with its default
 * "Deploy from a branch → main → / (root)" setting.
 *
 * Repository layout this expects:
 *   index.html, assets/, renders/, favicon.svg, .nojekyll   ← built site (generated)
 *   source/                                                ← this project
 *
 * Usage (from the source/ folder):  npm run build:pages
 */
import { execSync } from 'node:child_process';
import { cp, rm, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const repoRoot = path.dirname(project);

// safety: only write into the parent when this project lives in a folder named "source"
if (path.basename(project) !== 'source') {
  console.error(
    `build:pages writes the built site into the parent folder, so it only runs when this project is in a folder named "source".\n` +
      `Current folder: ${project}\nUse "npm run build" instead and upload dist/ yourself.`,
  );
  process.exit(1);
}

execSync('npm run build', { cwd: project, stdio: 'inherit' });

const dist = path.join(project, 'dist');
// remove the previous build output from the repo root (only generated names)
for (const name of ['index.html', 'assets', 'renders', 'favicon.svg', '.nojekyll']) {
  await rm(path.join(repoRoot, name), { recursive: true, force: true });
}
for (const name of await readdir(dist)) {
  await cp(path.join(dist, name), path.join(repoRoot, name), { recursive: true });
}
// tell GitHub Pages not to run Jekyll over the files
await writeFile(path.join(repoRoot, '.nojekyll'), '');
console.log(`\nPublished the built site to ${repoRoot}\nCommit and push the repository to update GitHub Pages.`);
