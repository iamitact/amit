/**
 * Builds the site and publishes the static files into the parent folder — the
 * GitHub Pages repository root — so Pages can serve them directly with its
 * default "Deploy from a branch → main → / (root)" setting.
 *
 * Repository layout this expects:
 *   index.html, 404.html, shop/, about/, …, assets/, renders/   ← built site (generated)
 *   source/                                                     ← this project
 *
 * Usage (inside source/):  npm run build:pages
 * For another repository or domain:  SITE_URL=https://user.github.io/repo/ npm run build:pages
 */
import { execSync } from 'node:child_process';
import { cp, readdir, rm, writeFile, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const repoRoot = path.dirname(project);

// safety: only write into the parent when this project lives in a folder named "source"
if (path.basename(project) !== 'source') {
  console.error(
    `build:pages writes the built site into the parent folder, so it only runs when this project is in a folder named "source".\n` +
      `Current folder: ${project}\nUse "npm run build" instead and upload the contents of dist/ yourself.`,
  );
  process.exit(1);
}

execSync('npm run build', { cwd: project, stdio: 'inherit' });

const dist = path.join(project, 'dist');
const generated = await readdir(dist);
// remember what the previous publish wrote, so removed pages don't linger
const ledger = path.join(repoRoot, '.pages-files.json');
const previous = await readFile(ledger, 'utf8').then(JSON.parse, () => []);
const keep = new Set(['source', '.git', '.github', 'README.md', '.nojekyll', '.pages-files.json', 'twelve-clothing-source.zip']);
for (const name of new Set([...previous, ...generated])) {
  if (keep.has(name)) continue;
  await rm(path.join(repoRoot, name), { recursive: true, force: true });
}
for (const name of generated) {
  await cp(path.join(dist, name), path.join(repoRoot, name), { recursive: true });
}
await writeFile(path.join(repoRoot, '.nojekyll'), '');
await writeFile(ledger, JSON.stringify(generated, null, 2) + '\n');
console.log(`\nPublished ${generated.length} top-level entries to ${repoRoot}\nCommit and push the repository to update GitHub Pages.`);
