/**
 * Renders the static images in public/renders/ from the real Three.js garment.
 * They are used for the no-WebGL / reduced-motion story, the lookbook, the
 * collection and the product gallery. The output is committed, so this only
 * needs to run when the garment, lighting or shots change.
 *
 *   npm run render:stills                 # uses installed Microsoft Edge
 *   BROWSER_CHANNEL=chrome npm run render:stills
 */
import { createServer } from 'vite';
import { chromium } from 'playwright-core';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'public', 'renders');
const only = process.argv.slice(2);

const L = { w: 1600, h: 1000, widths: [1600, 800] };
const P = { w: 1000, h: 1250, widths: [1000, 500] };
const jobs = [
  // story stills (fallback + editorial)
  { name: 'story-hero', variant: 'nocturne-black', shot: 'hero', ...L },
  { name: 'story-silhouette', variant: 'nocturne-black', shot: 'silhouette', ...L },
  { name: 'story-exploded', variant: 'nocturne-black', shot: 'exploded', ...L },
  { name: 'detail-collar', variant: 'nocturne-black', shot: 'collar', ...L },
  { name: 'detail-buttons', variant: 'nocturne-black', shot: 'buttons', ...L },
  { name: 'detail-emblem', variant: 'nocturne-black', shot: 'emblem', ...L },
  { name: 'detail-hem', variant: 'nocturne-black', shot: 'hem', ...L },
  // products (portrait)
  { name: 'product-nocturne-black', variant: 'nocturne-black', shot: 'product', ...P },
  { name: 'product-nocturne-ivory', variant: 'nocturne-ivory', shot: 'product', ...P },
  { name: 'product-vesper-slate', variant: 'vesper-slate', shot: 'product', ...P },
  { name: 'product-hour-tee', variant: 'hour-tee', shot: 'product', ...P },
  // lookbook
  { name: 'look-nocturne-portrait', variant: 'nocturne-black', shot: 'portrait', ...P },
  { name: 'look-nocturne-back', variant: 'nocturne-black', shot: 'back', ...P },
  { name: 'look-ivory-side', variant: 'nocturne-ivory', shot: 'side', ...P },
  { name: 'look-vesper-portrait', variant: 'vesper-slate', shot: 'portrait', ...P },
].filter((j) => only.length === 0 || only.includes(j.name));

const port = 5199;
const server = await createServer({ root, logLevel: 'error', server: { port, strictPort: true } });
await server.listen();
const browser = await chromium.launch({
  channel: process.env.BROWSER_CHANNEL || 'msedge',
  args: ['--enable-webgl', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1700, height: 1300 } });
page.on('console', (m) => m.type() === 'error' && console.error('[page]', m.text()));
await mkdir(out, { recursive: true });

try {
  for (const j of jobs) {
    const url = `http://localhost:${port}/studio.html?variant=${j.variant}&shot=${j.shot}&w=${j.w}&h=${j.h}`;
    await page.goto(url);
    await page.waitForFunction(() => window.__ready === true, null, { timeout: 60000 });
    const urls = await page.evaluate((ws) => window.__capture(ws), j.widths);
    for (let i = 0; i < urls.length; i++) {
      const file = path.join(out, `${j.name}-${j.widths[i]}.webp`);
      await writeFile(file, Buffer.from(urls[i].split(',')[1], 'base64'));
    }
    console.log('rendered', j.name);
  }
} finally {
  await browser.close();
  await server.close();
}
