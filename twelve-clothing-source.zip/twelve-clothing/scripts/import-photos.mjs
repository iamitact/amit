/**
 * Client photo pipeline:  npm run photos
 *
 * 1. Put original photographs in assets-reference/ (any of .jpg .jpeg .png .webp .tif .heic*).
 * 2. List them in assets-reference/manifest.json, e.g.
 *      {
 *        "photos": [
 *          { "file": "shop-interior.jpg", "id": "shop-interior", "alt": "Inside the Twelve Clothing shop on …", "slot": "about.interior" },
 *          { "file": "nocturne-front.jpg", "id": "nocturne-black-front", "alt": "Nocturne polo in black, front", "product": "nocturne-polo-black", "view": "front" }
 *        ]
 *      }
 *    - "slot" fills a page slot from src/data/photos.json (home.campaign, about.interior, lookbook.1 …)
 *    - "product" + "view" (front | back | detail) fills that product's gallery in src/data/catalog.json
 * 3. Run `npm run photos`.
 *
 * Output: public/photos/<id>-<width>.{avif,webp,jpg}, and the manifest entries in
 * src/data/photos.json → images. Originals are never modified. Images are only
 * resized, auto-rotated from EXIF and converted to sRGB — never cropped,
 * retouched or colour-shifted — so faces and product colour/shape stay true.
 * (*HEIC requires a libvips build with HEIF support; export to JPEG if it fails.)
 */
import sharp from 'sharp';
import { mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const srcDir = path.join(root, 'assets-reference');
const outDir = path.join(root, 'public', 'photos');
const photosJson = path.join(root, 'src', 'data', 'photos.json');
const catalogJson = path.join(root, 'src', 'data', 'catalog.json');
const WIDTHS = [480, 960, 1440, 2048];

const exists = (p) => access(p).then(() => true, () => false);
if (!(await exists(path.join(srcDir, 'manifest.json')))) {
  console.error('No assets-reference/manifest.json found. See the header of scripts/import-photos.mjs.');
  process.exit(1);
}
const manifest = JSON.parse(await readFile(path.join(srcDir, 'manifest.json'), 'utf8'));
const photos = JSON.parse(await readFile(photosJson, 'utf8'));
const catalog = JSON.parse(await readFile(catalogJson, 'utf8'));
await mkdir(outDir, { recursive: true });

for (const entry of manifest.photos ?? []) {
  const { file, id, alt } = entry;
  if (!file || !id || !/^[a-z0-9-]+$/.test(id) || !alt) {
    throw new Error(`Each photo needs file, a lowercase-dash id and alt text: ${JSON.stringify(entry)}`);
  }
  const input = sharp(path.join(srcDir, file), { failOn: 'error' }).rotate(); // apply EXIF orientation
  const meta = await input.metadata();
  const oriented = meta.orientation && meta.orientation >= 5 ? { width: meta.height, height: meta.width } : { width: meta.width, height: meta.height };
  const widths = WIDTHS.filter((w) => w <= oriented.width);
  if (widths.length === 0 || widths[widths.length - 1] < oriented.width) widths.push(Math.min(oriented.width, 2560));
  for (const w of widths) {
    const base = input.clone().resize({ width: w, withoutEnlargement: true }).toColourspace('srgb');
    await base.clone().avif({ quality: 55, effort: 5 }).toFile(path.join(outDir, `${id}-${w}.avif`));
    await base.clone().webp({ quality: 78 }).toFile(path.join(outDir, `${id}-${w}.webp`));
    await base.clone().jpeg({ quality: 82, mozjpeg: true }).toFile(path.join(outDir, `${id}-${w}.jpg`));
  }
  photos.images[id] = { widths, width: oriented.width, height: oriented.height, formats: ['avif', 'webp', 'jpg'], alt };
  if (entry.slot) {
    if (!photos.slots[entry.slot]) throw new Error(`Unknown slot ${entry.slot}`);
    photos.slots[entry.slot].image = `photo:${id}`;
  }
  if (entry.product) {
    const product = catalog.products.find((p) => p.slug === entry.product);
    if (!product) throw new Error(`Unknown product ${entry.product}`);
    const ref = `photo:${id}`;
    if (entry.view === 'front') product.images.front = ref;
    else if (entry.view === 'back') product.images.back = ref;
    else if (!product.images.details.includes(ref)) product.images.details = [...product.images.details.filter((d) => !d.startsWith('render:')), ref];
  }
  console.log(`✓ ${file} → ${id} (${widths.join(', ')} px)`);
}
if (manifest.logo) photos.logo = manifest.logo;
await writeFile(photosJson, JSON.stringify(photos, null, 2) + '\n');
await writeFile(catalogJson, JSON.stringify(catalog, null, 2) + '\n');
console.log('Updated src/data/photos.json and src/data/catalog.json');
