# Twelve Clothing — website source

A multi-page storefront for **Twelve Clothing** with a cinematic 3D editorial story. Every page is a real static page (`/shop/`, `/shop/<product>/`, `/about/`, …) that loads directly and survives a refresh on GitHub Pages.

> **Not finalised.** Products are 3D concept renders with prices, sizes and availability marked *to be confirmed*; business details are pending; online payment is not active. See [`docs/CLIENT-CHECKLIST.md`](docs/CLIENT-CHECKLIST.md) for what the client must supply and [`docs/CHECKOUT.md`](docs/CHECKOUT.md) for the payment plan.

## Pages

| URL | Page |
|-----|------|
| `/` | Home — 3D hero with drifting mist, featured pieces, campaign photo, story and visit teasers |
| `/shop/` | Collection grid; category and colour filters and sort (shareable via the URL) |
| `/shop/<slug>/` | Product — gallery, sizes, size guide, price, availability, add to bag, buy now |
| `/story/` | The pinned, scroll-driven 3D construction story |
| `/lookbook/` | Editorial lookbook |
| `/about/` | Store and brand story |
| `/contact/` | Address, hours, phone, email, social, map link, newsletter (not connected) |
| `/bag/` | Bag and honest checkout status |
| `404.html` | Not-found page for any unknown URL |

## Quick start

Requires **Node.js 20.19+ or 22.12+**.

```bash
npm ci
npm run dev          # http://localhost:5173  (all routes work in dev)
npm run build        # typecheck + build to dist/ (one index.html per page, 404.html, sitemap.xml)
npm run preview      # serve dist/ at http://localhost:4173
npm run lint
npm run test:server  # checkout server tests
```

Useful while testing: `?webgl=0` shows the no-WebGL version; the footer **Motion** control switches between Auto, Full motion and Reduced; `/story/?perf` exposes the renderer and timeline for profiling.

## Where content lives (edit these, not the components)

| File | What |
|------|------|
| `src/data/catalog.json` | Products, categories, currency, sizes, size guide. `null` = pending. `sample: true` = concept piece. The checkout server reads the same file. |
| `src/data/business.json` | Address, hours, phone, email, social, policies, story. `null` = shown as "to be confirmed". |
| `src/data/photos.json` | Photo slots per page (the asset manifest) and processed photo metadata. |
| `src/data/commerce.json` | Payment provider + checkout server URL (both `null` until verified). |

### Adding the client's photos

1. Put originals in `assets-reference/` and describe them in `assets-reference/manifest.json` (format in `scripts/import-photos.mjs`), mapping each file to a page slot (e.g. `about.interior`) or a product view (front / back / detail).
2. `npm run photos`: writes responsive AVIF, WebP and JPEG to `public/photos/` and updates the data files. Photos are only resized, auto-rotated and converted to sRGB. They are never cropped, retouched or colour-shifted.
3. Rebuild. Placeholders and concept renders are replaced automatically, and dimensions are recorded so nothing shifts on load.

## Publish on GitHub Pages

The repository root holds the **built site** so Pages can serve it with its default settings; the editable project lives in `source/` (the ZIP contains it as `twelve-clothing-source.zip`; extract it into a folder named `source`).

```bash
cd source
npm ci
npm run build:pages        # builds and replaces the generated site in the repository root
cd ..
git add -A && git commit -m "Update site" && git push
```

**Settings → Pages → Deploy from a branch → `main` → `/ (root)`.**

Paths: asset URLs are relative, and each page records its distance to the site root, so the build works under any repository name. Only absolute URLs (canonical, Open Graph, sitemap and `404.html`, which GitHub serves at any depth) use `SITE_URL`, which defaults to `https://iamitact.github.io/amit/`. For another repository or domain:

```bash
SITE_URL=https://<user>.github.io/<repo>/ npm run build:pages
```

## Architecture notes

- **Static multi-page build.** `src/site/pages.ts` lists every page, and it's shared by the browser and by a Vite plugin in `vite.config.ts` that writes one `index.html` per page with its own title, description, canonical URL and relative paths, plus `404.html`, `sitemap.xml` and `robots.txt`. Each page loads only its own code chunk; Three.js is loaded only by Home and Story.
- **3D** (`src/three/`). One optimised stage is used by the Home hero and the Story:
  - The mist is instanced and animated on the GPU (one draw call).
  - A contact shadow replaces the real-time shadow map.
  - The small hardware meshes are merged.
  - Pixel ratio is capped (1.5 on capable devices, 1.0 on low-power ones) and adapts with hysteresis.
  - Shaders are compiled before the first frame.
  - Rendering pauses off-screen or in a hidden tab, and a lost context is recovered.
  
  Measurements are in [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md).
- **Motion:** image reveals, card entrances, scroll-driven CSS parallax on a few photographs, a gallery crossfade, a page-entrance fade, and a CSS mist for browsers without WebGL. All of it is off under reduced motion (OS setting or the footer toggle).
- **Honesty rules:** concept renders are always captioned as renders. Unknown facts render as "to be confirmed". The newsletter says it isn't connected. Checkout never takes an order or reports a payment until a verified provider integration exists.

## Scripts

| Script | Purpose |
|--------|---------|
| `npm run photos` | Process client photos from `assets-reference/` |
| `npm run render:stills` | Re-render the concept stills in `public/renders/` from the 3D model (uses installed Edge) |
| `npm run render:fx` | Re-render the mist texture `public/fx/mist.webp` |
| `npm run build:pages` | Build and publish into the repository root (run inside `source/`) |
| `npm run server` | Start the checkout API (see `docs/CHECKOUT.md`; no provider configured yet) |

## Credits and licences

- Brand copy, the procedural 3D garment, the Dial emblem and all renders are original to this project. The 3D polo is a **concept model**, not a representation of a product for sale.
- Three.js (MIT), GSAP (free standard licence), React (MIT), Tailwind CSS (MIT), Vite (MIT), sharp (Apache-2.0, dev only), playwright-core (Apache-2.0, dev only).
- Cormorant and Montserrat: SIL Open Font License 1.1, licence texts in `src/fonts/`.
- Design direction and UX rules came from the **UI UX Pro Max** skill. The Shop filter layout adapts the 21st.dev "Ecommerce Category Page" (hirael, MIT). The footer adapts "Footer with Suite", and the size guide and gallery follow the "Size Guide Table" and "Thumbnail Slider" patterns. All were rewritten for this design.
