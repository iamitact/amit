# Twelve Clothing — The Nocturne Polo

An immersive, scroll-driven 3D product story and demo storefront for **Twelve Clothing**. A single black piqué polo, the *Nocturne*, floats under an overhead spotlight. As you scroll it turns, separates into twelve pieces, reassembles, and then the camera moves in on the collar, buttons, emblem and knit before the page moves on to the lookbook, collection and reserve sections.

> **Demo storefront.** The products, prices, stock and contact address are illustrative. Checkout and the newsletter clearly say that they are not connected to anything.

## Quick start

Requires **Node.js 20.19+ or 22.12+** and npm.

```bash
npm ci            # install exact versions from package-lock.json
npm run dev       # http://localhost:5173
```

```bash
npm run typecheck # TypeScript, no emit
npm run lint      # ESLint
npm run build     # typecheck + production build to dist/
npm run preview   # serve dist/ at http://localhost:4173
```

Useful URLs while testing:

- `?webgl=0` previews the still (no-WebGL) version of the story.
- The footer's **Motion** control switches between Auto (follows the OS reduced-motion setting), 3D motion and Still.

## Publish on GitHub Pages

The repository is laid out so GitHub Pages can serve it with its **default settings and no build step**:

```
index.html  assets/  renders/  favicon.svg  .nojekyll   ← the built website (generated)
source/                                               ← this editable project
```

Why not just upload the source? The source `index.html` loads `/src/main.tsx`, which a browser can't run until Vite compiles it. Served directly by GitHub Pages it shows a **blank page**. Only the built files at the top level work without a build.

**First publish:** follow the top-level README of the GitHub-ready ZIP. It uploads the built site, with this project packed as `twelve-clothing-source.zip`. To use `build:pages`, extract that ZIP into a folder named `source` inside the repository.

**After you edit the source:** rebuild the top-level site, then commit and push:

```bash
cd source
npm ci                 # first time only
npm run build:pages    # builds and replaces index.html, assets/, renders/ in the repository root
cd ..
git add -A && git commit -m "Update site" && git push
```

`build:pages` only runs when this project sits in a folder named `source` (so it never deletes files elsewhere). For any other host, run `npm run build` and upload the contents of `dist/`.

**Base path:** `vite.config.ts` sets `base: './'`, so every asset URL is relative. The same build works under any repository name, at a user/organisation site root, or on a custom domain, so you don't need to edit anything when you rename the repo. The site is a single page with hash links (`#reserve` and so on), so no SPA 404 fallback is needed.

## Stack

- **React 19 + TypeScript + Vite 8**, **Tailwind CSS 4** (design tokens in `src/index.css`).
- **Three.js r186** for the garment and stage; **GSAP ScrollTrigger** scrubs the camera/explode timeline. Both load in a lazy chunk behind a poster image.
- Fonts: **Cormorant** and **Montserrat**, Latin woff2 files self-hosted in `src/fonts/`. No external requests at runtime.

## Project structure

```
src/
  three/
    garment.ts     procedural polo: 12 separable parts, stitching, buttons, Dial emblem, camera anchors
    materials.ts   knit materials (sheen, piqué / rib normal maps), thread, buttons
    textures.ts    runtime-generated piqué + rib normal maps, collar tipping, smoke
    stage.ts       renderer, lights, fog, floor, smoke, camera rig and named shots
    story.ts       ScrollTrigger timeline, chapter/callout sync, render loop + cleanup
    variants.ts    colourways and cuts (black / ivory / slate long-sleeve / crew tee)
  components/      Header, Story (live + still), Campaign, Collection, Reserve, House, Footer, cart, dialogs
  content/         story chapters + callouts, demo product catalogue (edit prices here)
  state/cart.tsx   cart context, persisted to localStorage (validated on load)
  hooks/useMotion  reduced-motion preference + WebGL detection
public/renders/    still images rendered from the same 3D model (fallback, lookbook, products)
scripts/render-stills.mjs   re-renders public/renders/ from the live scene
studio.html        development-only still renderer used by that script (not in the production build)
```

## Editing content

- **Prices, names, descriptions:** `src/content/products.ts`
- **Story copy and timing:** `src/content/story.ts` (`at`/`span` are scroll positions 0–1)
- **Camera shots:** `computeShots()` in `src/three/stage.ts`; timeline in `src/three/story.ts`
- **Colours / type:** tokens at the top of `src/index.css`

After changing the garment, lighting or shots, regenerate the stills (this uses your installed Microsoft Edge, or set `BROWSER_CHANNEL=chrome`):

```bash
npm run render:stills
```

## 3D, accessibility and performance notes

- The garment is an **original procedural model**, not a scanned or downloaded asset. Its body is superellipse half-shells with fold displacement, the collar is a swept rib profile with pointed fronts, and there's a placket, dished buttons with cross-stitch, instanced stitch dashes and a raised twelve-mark emblem. The camera close-ups target anchors on the real geometry.
- The same garment stays on screen through the reveal, the exploded view and the close-ups. Pieces move on separate vectors with staggered easing, so they don't clip, and reverse scroll reassembles them exactly.
- The canvas has `pointer-events: none` and never captures scroll or taps. Pointer parallax is subtle and only applies with fine pointers.
- Pixel ratio is capped at 1.75 (1.25 on low-power devices), and there are fewer smoke sprites and smaller shadow maps on low-power devices. Rendering pauses when the story is off-screen or the tab is hidden, and every GSAP/Three resource is disposed on unmount.
- With **reduced motion** or **no WebGL** the story renders as a readable still sequence built from the same renders. A WebGL context loss falls back automatically.
- Semantic landmarks, a skip link, visible focus rings, native `<dialog>` for the bag/product/checkout, and a native radio group for sizes. Text contrast on the dark background is at least 6:1.

## Known limitations

- The garment is a **stylised procedural model**, not a photogrammetry scan. It has convincing construction detail up close, but it isn't photo-real cloth. To use a real garment, replace `buildGarment()` with a GLB loaded via `GLTFLoader`, keep the part names, and re-point the anchors.
- No commerce or email backend is included. Connect one (for example Shopify, Stripe Checkout, Buttondown) where the demo notices are.

## Credits and licences

- Brand, copy, garment model, emblem and all images are original to this project.
- Three.js (MIT), GSAP (GreenSock standard licence, free), React (MIT), Tailwind CSS (MIT), Vite (MIT).
- Cormorant and Montserrat: SIL Open Font License 1.1 (licence texts in `src/fonts/`).
- UI direction was informed by the *UI UX Pro Max* design-system search (Cormorant/Montserrat pairing, luxury dark + gold palette, scroll-storytelling and reduced-motion rules). The footer and collection list adapt patterns from two 21st.dev components ("Footer with Suite", "lumina-interactive-list"), rewritten for this design, with no copied scripts or assets.
