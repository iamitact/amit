import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CatalogError, loadCatalog, priceBag } from '../src/catalog.mjs';
import { Checkout } from '../src/checkout.mjs';
import { OrderStore } from '../src/orders.mjs';
import { createSandboxProvider } from '../src/providers/sandbox.mjs';
import { createApp } from '../src/server.mjs';

// A fully priced test catalogue (the real one is still pending client data).
const catalog = {
  currency: 'BDT',
  products: [
    { slug: 'test-polo', sample: false, name: 'Test Polo', colour: 'Black', price: 2500, sizes: ['M', 'L'], sizesConfirmed: true, availability: 'in_stock' },
    { slug: 'sold-out', sample: false, name: 'Sold', colour: 'Black', price: 900, sizes: ['M'], sizesConfirmed: true, availability: 'sold_out' },
  ],
};
const customer = { name: 'Test Customer', email: 'test@example.com' };
const urls = { success: 'https://site.test/bag/?paid=1', fail: 'https://site.test/bag/?failed=1', cancel: 'https://site.test/bag/?cancelled=1', notify: 'https://api.test/api/payments' };

function setup() {
  const sandbox = createSandboxProvider();
  const store = new OrderStore();
  const checkout = new Checkout({ catalog, store, providers: { sandbox }, urls });
  const order = async (qty = 2) => checkout.createOrder({ lines: [{ slug: 'test-polo', size: 'M', qty, price: 1 }], customer }, 'sandbox');
  const refOf = (id) => store.get(id).providerRef;
  return { sandbox, store, checkout, order, refOf };
}

test('the real catalogue cannot be sold yet (prices and currency pending)', () => {
  const real = loadCatalog();
  assert.throws(() => priceBag(real, [{ slug: real.products[0].slug, size: 'M', qty: 1 }]), (e) => e instanceof CatalogError && e.code === 'catalogue_not_ready');
});

test('order amount comes from the server catalogue, not the client', async () => {
  const { order, store } = setup();
  const created = await order(2);
  assert.equal(created.amountMinor, 2 * 2500 * 100);
  assert.equal(store.get(created.orderId).status, 'pending_payment');
});

test('successful payment marks the order paid', async () => {
  const { sandbox, checkout, order, refOf, store } = setup();
  const { orderId } = await order();
  const r = await checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid'));
  assert.deepEqual(r, { outcome: 'applied', status: 'paid' });
  assert.equal(store.get(orderId).status, 'paid');
});

test('failed and cancelled payments', async () => {
  const s = setup();
  const a = await s.order();
  assert.equal((await s.checkout.handleNotification('sandbox', s.sandbox.simulate(s.refOf(a.orderId), 'failed'))).status, 'failed');
  const b = await s.order();
  assert.equal((await s.checkout.handleNotification('sandbox', s.sandbox.simulate(s.refOf(b.orderId), 'cancelled'))).status, 'cancelled');
});

test('duplicate notifications are idempotent', async () => {
  const { sandbox, checkout, order, refOf, store } = setup();
  const { orderId } = await order();
  const n = sandbox.simulate(refOf(orderId), 'paid', { eventId: 'EVT-1' });
  await checkout.handleNotification('sandbox', n);
  assert.deepEqual(await checkout.handleNotification('sandbox', n), { outcome: 'duplicate' });
  // same status via a different event id changes nothing either
  const again = await checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid'));
  assert.equal(again.outcome, 'unchanged');
  assert.equal(store.get(orderId).history.filter((h) => h.status === 'paid').length, 1);
});

test('a late failure after payment does not undo the payment', async () => {
  const { sandbox, checkout, order, refOf, store } = setup();
  const { orderId } = await order();
  await checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid'));
  const n = JSON.parse(sandbox.simulate(refOf(orderId), 'paid').body);
  // forge a 'failed' event with a valid signature for the same payment
  const forged = sandbox.simulate(refOf(orderId), 'failed', { eventId: `${n.eventId}-late` });
  const r = await checkout.handleNotification('sandbox', forged);
  assert.equal(store.get(orderId).status, 'paid');
  assert.ok(['ignored', 'unchanged'].includes(r.outcome));
});

test('amount mismatch goes to review, never to paid', async () => {
  const { sandbox, checkout, order, refOf, store } = setup();
  const { orderId } = await order();
  const r = await checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid', { amountMinor: 100 }));
  assert.equal(r.status, 'review');
  assert.equal(store.get(orderId).status, 'review');
});

test('bad signatures are rejected', async () => {
  const { sandbox, checkout, order, refOf } = setup();
  const { orderId } = await order();
  await assert.rejects(checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid', { signature: 'nope' })), { code: 'bad_signature' });
});

test('fulfilment and refund states', async () => {
  const { sandbox, checkout, order, refOf, store } = setup();
  const { orderId } = await order();
  await assert.rejects(checkout.refund(orderId), { code: 'invalid_transition' }); // not paid yet
  await assert.rejects(checkout.fulfil(orderId), { code: 'invalid_transition' });
  await checkout.handleNotification('sandbox', sandbox.simulate(refOf(orderId), 'paid'));
  await checkout.fulfil(orderId);
  assert.equal(store.get(orderId).status, 'fulfilled');
  await checkout.refund(orderId);
  assert.equal(store.get(orderId).status, 'refunded');
});

test('unsellable lines are refused', async () => {
  const { checkout } = setup();
  await assert.rejects(checkout.createOrder({ lines: [{ slug: 'sold-out', size: 'M', qty: 1 }], customer }, 'sandbox'), { code: 'unavailable' });
  await assert.rejects(checkout.createOrder({ lines: [{ slug: 'test-polo', size: 'XS', qty: 1 }], customer }, 'sandbox'), { code: 'invalid_size' });
  await assert.rejects(checkout.createOrder({ lines: [{ slug: 'nope', size: 'M', qty: 1 }], customer }, 'sandbox'), { code: 'unknown_product' });
  await assert.rejects(checkout.createOrder({ lines: [{ slug: 'test-polo', size: 'M', qty: 1 }], customer: { name: '' } }, 'sandbox'), { code: 'invalid_customer' });
});

test('sandbox provider refuses to run in production', () => {
  const prev = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try {
    assert.throws(() => createSandboxProvider(), /never run in production/);
  } finally {
    process.env.NODE_ENV = prev;
  }
});

test('HTTP API: create order, notify, read status, admin auth', async () => {
  const { sandbox, checkout, refOf } = setup();
  const server = createApp({ checkout, siteOrigin: 'https://site.test', adminToken: 'secret' }).listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    let r = await fetch(`${base}/api/orders`, { method: 'POST', body: JSON.stringify({ provider: 'sandbox', lines: [{ slug: 'test-polo', size: 'L', qty: 1 }], customer }) });
    assert.equal(r.status, 201);
    const { orderId } = await r.json();
    const n = sandbox.simulate(refOf(orderId), 'paid');
    r = await fetch(`${base}/api/payments/sandbox/notify`, { method: 'POST', body: n.body, headers: { 'x-signature': n.signature } });
    assert.deepEqual(await r.json(), { outcome: 'applied', status: 'paid' });
    r = await fetch(`${base}/api/orders/${orderId}`);
    assert.equal((await r.json()).status, 'paid');
    r = await fetch(`${base}/api/admin/orders/${orderId}/fulfil`, { method: 'POST' });
    assert.equal(r.status, 401);
    r = await fetch(`${base}/api/admin/orders/${orderId}/fulfil`, { method: 'POST', headers: { authorization: 'Bearer secret' } });
    assert.equal((await r.json()).status, 'fulfilled');
    r = await fetch(`${base}/api/orders`, { method: 'POST', body: '{bad json' });
    assert.equal(r.status, 400);
  } finally {
    server.close();
  }
});
