/**
 * Payment provider registry.
 *
 * No real provider is registered yet: the merchant has not confirmed which
 * payment/commerce account they hold. When they do, add an adapter file here
 * (implementing createPayment / verify / refund — see ../checkout.mjs) that
 * reads its credentials from environment variables, and register it below.
 * Test against the provider's sandbox first; production activation needs the
 * merchant's live account and approval.
 */
export async function loadProviders(env) {
  const providers = {};
  if (env.ENABLE_SANDBOX_PROVIDER === '1') {
    const { createSandboxProvider } = await import('./sandbox.mjs');
    providers.sandbox = createSandboxProvider({ secret: env.SANDBOX_SECRET });
  }
  return providers;
}
