import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';

/**
 * LOCAL TEST PROVIDER ONLY. It simulates a hosted payment page and signed
 * notifications so the order flow can be tested end to end without a merchant
 * account. It takes no money and refuses to load when NODE_ENV=production.
 * Replace it with the merchant's real provider adapter (see server/README.md).
 */
export function createSandboxProvider({ secret = 'sandbox-secret' } = {}) {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('The sandbox payment provider must never run in production.');
  }
  const payments = new Map(); // providerRef → { orderId, amountMinor, currency, status }
  const sign = (body) => createHmac('sha256', secret).update(body).digest('hex');

  return {
    name: 'sandbox',
    async createPayment(order, urls) {
      const providerRef = `SBX-${randomUUID()}`;
      payments.set(providerRef, { orderId: order.id, amountMinor: order.amountMinor, currency: order.currency, status: 'initiated' });
      return { providerRef, redirectUrl: `${urls.success.replace(/\/[^/]*$/, '')}/sandbox-pay?ref=${providerRef}` };
    },

    /** Test helper: what the provider would POST to the notify URL. */
    simulate(providerRef, status, overrides = {}) {
      const p = payments.get(providerRef);
      if (!p) throw new Error('unknown sandbox payment');
      if (status === 'paid' || status === 'failed' || status === 'cancelled') p.status = status;
      const body = JSON.stringify({ eventId: overrides.eventId ?? `EVT-${randomUUID()}`, providerRef, status, amountMinor: overrides.amountMinor ?? p.amountMinor, currency: overrides.currency ?? p.currency, orderId: p.orderId });
      return { body, signature: overrides.signature ?? sign(body) };
    },

    /** Verifies the signature AND re-checks the payment record (stands in for a server-to-server validation call). */
    async verify({ body, signature }) {
      const expected = Buffer.from(sign(body));
      const given = Buffer.from(String(signature ?? ''));
      if (expected.length !== given.length || !timingSafeEqual(expected, given)) throw Object.assign(new Error('Invalid signature'), { code: 'bad_signature' });
      const n = JSON.parse(body);
      const record = payments.get(n.providerRef);
      if (!record || record.orderId !== n.orderId) throw Object.assign(new Error('Unknown transaction'), { code: 'unknown_transaction' });
      // report what the provider's own record says for status, but the notified amount (so tampering is detectable)
      return { eventId: n.eventId, orderId: n.orderId, providerRef: n.providerRef, status: record.status === 'initiated' ? n.status : record.status, amountMinor: n.amountMinor, currency: n.currency };
    },

    async refund(order) {
      const record = payments.get(order.providerRef);
      if (!record || record.status !== 'paid') throw new Error('Nothing to refund');
      record.status = 'refunded';
      return { refundRef: `SBX-RF-${randomUUID()}` };
    },
  };
}
