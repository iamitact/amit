import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

/**
 * Server-side catalogue. Prices are ALWAYS taken from here, never from the
 * browser. It reads the same src/data/catalog.json the website uses, so there
 * is one source of truth (or pass another object in tests).
 */
export function loadCatalog(file = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../src/data/catalog.json')) {
  return JSON.parse(readFileSync(file, 'utf8'));
}

/** Currencies quoted in minor units with 2 decimals; extend if the provider uses others. */
const MINOR = { BDT: 100, USD: 100, EUR: 100, GBP: 100, INR: 100 };

export class CatalogError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

/**
 * Prices a bag. Throws CatalogError when anything is not sellable, including
 * the current state where prices/currency are still pending.
 * @returns {{ currency: string, amountMinor: number, lines: {slug:string,size:string,qty:number,unitMinor:number,name:string}[] }}
 */
export function priceBag(catalog, requested) {
  if (!catalog.currency) throw new CatalogError('catalogue_not_ready', 'Currency is not configured.');
  const factor = MINOR[catalog.currency];
  if (!factor) throw new CatalogError('unsupported_currency', `Currency ${catalog.currency} is not supported.`);
  if (!Array.isArray(requested) || requested.length === 0 || requested.length > 20) {
    throw new CatalogError('invalid_bag', 'The bag must contain between 1 and 20 lines.');
  }
  const lines = requested.map((l) => {
    const product = catalog.products.find((p) => p.slug === l?.slug);
    if (!product) throw new CatalogError('unknown_product', `Unknown product ${l?.slug}.`);
    if (product.sample) throw new CatalogError('not_for_sale', `${product.slug} is a sample, not a product for sale.`);
    if (product.price === null || typeof product.price !== 'number') throw new CatalogError('catalogue_not_ready', `${product.slug} has no confirmed price.`);
    if (!product.sizesConfirmed || !product.sizes.includes(l.size)) throw new CatalogError('invalid_size', `Size ${l.size} is not available for ${product.slug}.`);
    if (product.availability !== 'in_stock' && product.availability !== 'made_to_order') {
      throw new CatalogError('unavailable', `${product.slug} is not available to order.`);
    }
    const qty = Number(l.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 9) throw new CatalogError('invalid_quantity', 'Quantity must be 1–9.');
    return { slug: product.slug, size: l.size, qty, unitMinor: Math.round(product.price * factor), name: `${product.name}, ${product.colour}` };
  });
  const amountMinor = lines.reduce((sum, l) => sum + l.unitMinor * l.qty, 0);
  return { currency: catalog.currency, amountMinor, lines };
}
