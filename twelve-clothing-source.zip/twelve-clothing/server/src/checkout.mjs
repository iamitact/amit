import { priceBag } from './catalog.mjs';
import { OrderError } from './orders.mjs';

/**
 * Checkout service: creates orders from server-verified prices and applies
 * payment notifications only after re-verifying them with the provider.
 *
 * A provider adapter implements:
 *   createPayment(order, urls)  → { redirectUrl, providerRef }
 *   verify(notification)        → { eventId, orderId, providerRef, status: 'paid'|'failed'|'cancelled', amountMinor, currency }
 *                                  MUST confirm the transaction with the provider's server-to-server
 *                                  validation API — never trust the notification body alone.
 *   refund(order)               → { refundRef }
 */
export class Checkout {
  constructor({ catalog, store, providers, urls }) {
    this.catalog = catalog;
    this.store = store;
    this.providers = providers;
    this.urls = urls; // { success, fail, cancel, notify } — absolute URLs for the provider
  }

  provider(name) {
    const p = this.providers[name];
    if (!p) throw new OrderError('unknown_provider', `Payment provider ${name} is not configured.`);
    return p;
  }

  /** Client sends only slug/size/qty and customer details; prices come from the catalogue. */
  async createOrder({ lines, customer }, providerName) {
    const priced = priceBag(this.catalog, lines);
    const provider = this.provider(providerName);
    const order = await this.store.create({ ...priced, customer: sanitiseCustomer(customer), provider: providerName });
    const { redirectUrl, providerRef } = await provider.createPayment(order, this.urls);
    order.providerRef = providerRef;
    await this.store.persist();
    return { orderId: order.id, redirectUrl, amountMinor: order.amountMinor, currency: order.currency };
  }

  /**
   * Handles a provider callback/webhook. Idempotent: a repeated event id, or a
   * status the order already has, changes nothing. Amount/currency/reference
   * mismatches move the order to 'review' instead of 'paid'.
   */
  async handleNotification(providerName, notification) {
    const provider = this.provider(providerName);
    const v = await provider.verify(notification);
    if (this.store.seen(v.eventId)) return { outcome: 'duplicate' };
    const order = this.store.get(v.orderId);
    if (!order) throw new OrderError('unknown_order', `Order ${v.orderId} not found.`);

    let target = v.status;
    let note = `provider ${providerName} event ${v.eventId}`;
    if (v.status === 'paid' && (v.amountMinor !== order.amountMinor || v.currency !== order.currency || (order.providerRef && v.providerRef !== order.providerRef))) {
      target = 'review';
      note += ` — mismatch: expected ${order.amountMinor} ${order.currency} ref ${order.providerRef}, got ${v.amountMinor} ${v.currency} ref ${v.providerRef}`;
    }
    let result;
    try {
      result = await this.store.transition(order.id, target, note);
    } catch (err) {
      // e.g. a late 'failed' after 'paid': record the event, keep the order as is
      if (err.code === 'invalid_transition') {
        await this.store.markSeen(v.eventId);
        return { outcome: 'ignored', status: order.status };
      }
      throw err;
    }
    await this.store.markSeen(v.eventId);
    return { outcome: result.changed ? 'applied' : 'unchanged', status: result.order.status };
  }

  async fulfil(orderId, note = 'fulfilled') {
    return (await this.store.transition(orderId, 'fulfilled', note)).order;
  }

  async refund(orderId) {
    const order = this.store.get(orderId);
    if (!order) throw new OrderError('unknown_order', `Order ${orderId} not found.`);
    if (!['paid', 'fulfilled'].includes(order.status)) throw new OrderError('invalid_transition', `Cannot refund an order that is ${order.status}.`);
    const { refundRef } = await this.provider(order.provider).refund(order);
    return (await this.store.transition(orderId, 'refunded', `refund ${refundRef}`)).order;
  }
}

function sanitiseCustomer(c = {}) {
  const s = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
  const customer = { name: s(c.name, 120), email: s(c.email, 200), phone: s(c.phone, 40), address: s(c.address, 400) };
  if (!customer.name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
    throw new OrderError('invalid_customer', 'A name and a valid email are required.');
  }
  return customer;
}
