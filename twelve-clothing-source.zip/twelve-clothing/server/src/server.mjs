import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { CatalogError, loadCatalog } from './catalog.mjs';
import { Checkout } from './checkout.mjs';
import { OrderError, OrderStore } from './orders.mjs';

/**
 * Checkout API (runs on a separate server — never on GitHub Pages).
 *
 *   POST /api/orders                       { provider, lines:[{slug,size,qty}], customer } → { orderId, redirectUrl }
 *   GET  /api/orders/:id                   → { id, status }          (for the return page)
 *   POST /api/payments/:provider/notify    provider callback / webhook (raw body + signature header)
 *   POST /api/admin/orders/:id/fulfil      Authorization: Bearer $ADMIN_TOKEN
 *   POST /api/admin/orders/:id/refund      Authorization: Bearer $ADMIN_TOKEN
 *
 * Configuration comes from environment variables only (see .env.example).
 * No provider is enabled until one is registered in ./providers/index.mjs.
 */
export function createApp({ checkout, siteOrigin, adminToken }) {
  const json = (res, status, body) => {
    res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify(body));
  };
  const readBody = (req, limit = 64 * 1024) =>
    new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > limit) {
          reject(Object.assign(new Error('Body too large'), { code: 'too_large' }));
          req.destroy();
        } else chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });

  return http.createServer(async (req, res) => {
    // CORS only for the storefront origin, only for the public endpoints
    if (siteOrigin && req.headers.origin === siteOrigin) {
      res.setHeader('access-control-allow-origin', siteOrigin);
      res.setHeader('vary', 'origin');
      res.setHeader('access-control-allow-headers', 'content-type');
    }
    if (req.method === 'OPTIONS') return json(res, 204, {});
    const url = new URL(req.url, 'http://api');
    try {
      if (req.method === 'POST' && url.pathname === '/api/orders') {
        const body = JSON.parse(await readBody(req));
        return json(res, 201, await checkout.createOrder(body, body.provider));
      }
      let m = url.pathname.match(/^\/api\/orders\/(TW-[\w-]+)$/);
      if (req.method === 'GET' && m) {
        const order = checkout.store.get(m[1]);
        return order ? json(res, 200, { id: order.id, status: order.status }) : json(res, 404, { error: 'unknown_order' });
      }
      m = url.pathname.match(/^\/api\/payments\/([\w-]+)\/notify$/);
      if (req.method === 'POST' && m) {
        const body = await readBody(req);
        const signature = req.headers['x-signature'] ?? req.headers['x-provider-signature'];
        return json(res, 200, await checkout.handleNotification(m[1], { body, signature, headers: req.headers }));
      }
      m = url.pathname.match(/^\/api\/admin\/orders\/(TW-[\w-]+)\/(fulfil|refund)$/);
      if (req.method === 'POST' && m) {
        if (!adminToken || req.headers.authorization !== `Bearer ${adminToken}`) return json(res, 401, { error: 'unauthorised' });
        const order = m[2] === 'fulfil' ? await checkout.fulfil(m[1]) : await checkout.refund(m[1]);
        return json(res, 200, { id: order.id, status: order.status });
      }
      return json(res, 404, { error: 'not_found' });
    } catch (err) {
      const known = err instanceof CatalogError || err instanceof OrderError || err.code === 'bad_signature' || err.code === 'unknown_transaction';
      if (!known && !(err instanceof SyntaxError)) console.error(err);
      return json(res, known ? (err.code === 'unknown_order' ? 404 : err.code === 'bad_signature' ? 401 : 409) : err instanceof SyntaxError ? 400 : 500, {
        error: known ? err.code : err instanceof SyntaxError ? 'invalid_json' : 'server_error',
        message: known ? err.message : undefined,
      });
    }
  });
}

// `node server/src/server.mjs` starts the API with the configured providers
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { loadProviders } = await import('./providers/index.mjs');
  const store = await new OrderStore(process.env.ORDERS_FILE ?? 'server/data/orders.json').load();
  const publicUrl = process.env.API_PUBLIC_URL ?? 'http://localhost:8787';
  const site = (process.env.SITE_URL ?? 'http://localhost:5173/').replace(/\/?$/, '/');
  const checkout = new Checkout({
    catalog: loadCatalog(),
    store,
    providers: await loadProviders(process.env),
    urls: { success: `${site}bag/?paid=1`, fail: `${site}bag/?failed=1`, cancel: `${site}bag/?cancelled=1`, notify: `${publicUrl}/api/payments` },
  });
  const port = Number(process.env.PORT ?? 8787);
  createApp({ checkout, siteOrigin: process.env.SITE_ORIGIN, adminToken: process.env.ADMIN_TOKEN }).listen(port, () =>
    console.log(`Twelve checkout API on :${port} — providers: ${Object.keys(checkout.providers).join(', ') || 'none configured'}`),
  );
}
