import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

/**
 * Order state machine. A transition not listed here is refused, which is what
 * makes duplicate or out-of-order payment notifications harmless.
 *
 *   pending_payment → paid | failed | cancelled | expired | review
 *   paid            → fulfilled | refunded
 *   fulfilled       → refunded
 *   review          → paid | cancelled          (manual decision after an anomaly)
 */
export const TRANSITIONS = {
  pending_payment: ['paid', 'failed', 'cancelled', 'expired', 'review'],
  paid: ['fulfilled', 'refunded'],
  fulfilled: ['refunded'],
  review: ['paid', 'cancelled'],
  failed: [],
  cancelled: [],
  expired: [],
  refunded: [],
};

export class OrderError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

/** Order store. In-memory by default; pass a file path to persist as JSON (replace with a database in production). */
export class OrderStore {
  constructor(file = null) {
    this.file = file;
    this.orders = new Map();
    this.events = new Set(); // provider event ids already processed (idempotency)
    this.queue = Promise.resolve();
  }

  async load() {
    if (!this.file) return this;
    try {
      const data = JSON.parse(await readFile(this.file, 'utf8'));
      for (const o of data.orders ?? []) this.orders.set(o.id, o);
      for (const e of data.events ?? []) this.events.add(e);
    } catch (err) {
      if (err.code !== 'ENOENT') throw err;
    }
    return this;
  }

  /** Serialises writes and replaces the file atomically. */
  persist() {
    if (!this.file) return Promise.resolve();
    this.queue = this.queue.then(async () => {
      await mkdir(path.dirname(this.file), { recursive: true });
      const tmp = `${this.file}.${process.pid}.tmp`;
      await writeFile(tmp, JSON.stringify({ orders: [...this.orders.values()], events: [...this.events] }, null, 2));
      await rename(tmp, this.file);
    });
    return this.queue;
  }

  async create({ currency, amountMinor, lines, customer, provider }) {
    const now = new Date().toISOString();
    const order = {
      id: `TW-${randomUUID()}`,
      status: 'pending_payment',
      currency,
      amountMinor,
      lines,
      customer,
      provider,
      providerRef: null,
      history: [{ at: now, status: 'pending_payment', note: 'created' }],
      createdAt: now,
    };
    this.orders.set(order.id, order);
    await this.persist();
    return order;
  }

  get(id) {
    return this.orders.get(id) ?? null;
  }

  async transition(id, to, note) {
    const order = this.orders.get(id);
    if (!order) throw new OrderError('unknown_order', `Order ${id} not found.`);
    if (order.status === to) return { order, changed: false };
    if (!TRANSITIONS[order.status]?.includes(to)) {
      throw new OrderError('invalid_transition', `Cannot move order from ${order.status} to ${to}.`);
    }
    order.status = to;
    order.history.push({ at: new Date().toISOString(), status: to, note });
    await this.persist();
    return { order, changed: true };
  }

  seen(eventId) {
    return this.events.has(eventId);
  }

  async markSeen(eventId) {
    this.events.add(eventId);
    await this.persist();
  }
}
